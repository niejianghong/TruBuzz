package com.TruBuzz.Fragments;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.net.http.SslError;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.SslErrorHandler;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.TruBuzz.Activity.ComposeShareActivity;
import com.TruBuzz.Activity.MainUIActivity;
import com.TruBuzz.Activity.ProfileActivity;
import com.TruBuzz.Adapter.TBMsgAdapter;
import com.TruBuzz.TBBeans.TBMessage;
import com.TruBuzz.TBBeans.TBMessageList;
import com.TruBuzz.TBBeans.TBPushMessage;
import com.TruBuzz.TBCommon.TBConfigUtils;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;
import com.TruBuzz.TBNetwork.TBCircleConnPool;
import com.TruBuzz.TBNetwork.TBMsgConnPool;
import com.TruBuzz.TBNetwork.TBNetworkResult;
import com.TruBuzz.TBNetwork.TBStockRiverConnPool;
import com.TruBuzz.TruBuzz.R;
import com.TruBuzz.TruBuzz.TBApplication;
import com.TruBuzz.View.RefreshableView;
import com.TruBuzz.View.RefreshableView.PullToRefreshListener;

@SuppressLint("ValidFragment")
public class TBMsgWallFragment extends TBBaseFragment implements
        PullToRefreshListener {
    private Button circleBtn = null;
    private TextView tvStockName = null;
    private Button editBtn = null;
    private Button msgWallBtn = null;
    private Button stockRiverBtn = null;
    private Button settingsBtn = null;
    private TBMsgAdapter mAdapter = null;
    private ListView listView = null;
    private WebView mWebView = null;
    private LinearLayout ll_msg_wall = null;
    private LinearLayout ll_settings = null;
    private LinearLayout ll_account = null;
    private EditText etApiUrl = null;
    private EditText etStockRiverId = null;
    private boolean isNeedSaveSettings = false;
    private RefreshableView refreshableView = null;
    private boolean loading = false;

    public TBMsgWallFragment() {
        super();
    }

    public TBMsgWallFragment(MainUIActivity activity, int listMode) {
        super();
        this.listMode = listMode;
    }

    public TBMsgWallFragment(MainUIActivity activity, TBPushMessage pushData) {
        super();
        if (null == pushData) {
            this.listMode = TBBaseFragment.TB_MSG_MODE;
            return;
        }
        if (TBPushMessage.MSG_TYPE_CIRCLE.equals(pushData.msgType)) {
            this.listMode = TBBaseFragment.TB_CIRCLE_MODE;
            id = pushData.fromId + "";
        } else if (TBPushMessage.MSG_TYPE_STOCK.equals(pushData.msgType)) {
            this.listMode = TBBaseFragment.TB_STOCK_MODE;
            this.id = pushData.fromId + "";
        } else if (TBPushMessage.MSG_TYPE_PUB_WALL.equals(pushData.msgType)) {
            this.listMode = TBBaseFragment.TB_MSG_MODE;
        }
    }

    @Override
    public void setArguments(Bundle bundle) {
        id = bundle.getString(TB_ID);
    }

    private void setMsgList(TBMessageList msgList) {
        mAdapter = new TBMsgAdapter(this, msgList);
        listView.setAdapter(mAdapter);
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    private void saveSettings() {
        if (isNeedSaveSettings) {
            isNeedSaveSettings = false;
            TBConfigUtils.setApiUrl(TBApplication.mGlobalContext, etApiUrl
                    .getText().toString());
            TBConfigUtils.setStockID(TBApplication.mGlobalContext,
                    etStockRiverId.getText().toString());
        }
    }

    private void refreshMsgWall() {
        if (null == mAdapter) {
            if (TB_MSG_MODE == listMode) {
                TBMsgConnPool.getMessage(TBConstDef.CB_GET_MSG_LIST + "");
            } else if (TB_CIRCLE_MODE == listMode) {
                TBCircleConnPool.getCircle(id, TBConstDef.CB_GET_CIRCLE_MSG
                        + "");
            } else {
                TBStockRiverConnPool.getStockRiver(
                        TBConfigUtils.getStockID(mActivity),
                        TBConstDef.CB_GET_STOCK_RIVER + "");
            }
            refreshableView.finishRefreshing();
        } else {
            if (TB_MSG_MODE == listMode) {
                TBMsgConnPool.getNewestMsg(mAdapter.getNewstMsgId(),
                        TBConstDef.CB_GET_NEWEST_MSG_LIST + "");
            } else if (TB_CIRCLE_MODE == listMode) {
                TBCircleConnPool.getNewestMsg(id, mAdapter.getNewstMsgId(),
                        TBConstDef.CB_GET_NEWEST_CIRCLE_MSG_LIST + "");
            } else {
                TBStockRiverConnPool.getNewestStockRiver(
                        TBConfigUtils.getStockID(TBApplication.mGlobalContext),
                        mAdapter.getNewstMsgId(),
                        TBConstDef.CB_GET_NEWEST_STOCK_RIVER + "");
            }
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        super.TAG = "MsgWallFragment";
        View rootView = inflater.inflate(R.layout.main_ui, null);

        ll_msg_wall = (LinearLayout) rootView
                .findViewById(R.id.ll_msg_stock_list);
        ll_settings = (LinearLayout) rootView.findViewById(R.id.ll_settings);
        ll_account = (LinearLayout) rootView.findViewById(R.id.ll_account);

        ll_account.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                saveSettings();
                Intent i = new Intent(mActivity, ProfileActivity.class);
                mActivity.startActivity(i);

            }
        });
        refreshableView = (RefreshableView) rootView
                .findViewById(R.id.refreshable_view);
        refreshableView.setOnRefreshListener(new PullToRefreshListener() {
            @Override
            public void onRefresh() {
                refreshMsgWall();
            }
        }, 0);

        etApiUrl = (EditText) rootView.findViewById(R.id.et_api_url);
        etApiUrl.setText(TBConfigUtils.getApiUrl(TBApplication.mGlobalContext));
        etStockRiverId = (EditText) rootView.findViewById(R.id.et_stock_id);
        etStockRiverId.setText(TBConfigUtils
                .getStockID(TBApplication.mGlobalContext));

        editBtn = (Button) rootView.findViewById(R.id.btn_compose);
        editBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                Intent i = new Intent(mActivity, ComposeShareActivity.class);
                mActivity.startActivity(i);
            }
        });
        tvStockName = (TextView) rootView.findViewById(R.id.tv_stock_name);
        circleBtn = (Button) rootView.findViewById(R.id.img_circle);
        circleBtn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {

                if (listMode != TB_STOCK_MODE) {
                    ((MainUIActivity) mActivity).switchMenu();
                } else {
                    if (mWebView.getVisibility() != View.GONE) {
                        mWebView.setVisibility(View.GONE);
                    } else {
                        mWebView.setVisibility(View.VISIBLE);
                    }
                }
            }
        });
        msgWallBtn = (Button) rootView.findViewById(R.id.btn_msg_wall);
        msgWallBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                showProgressDialog(R.string.loading_msg, true);
                TBMsgConnPool.getMessage(TBConstDef.CB_GET_MSG_LIST + "");
                listMode = TB_MSG_MODE;
                mWebView.setVisibility(View.GONE);
                ll_msg_wall.setVisibility(View.VISIBLE);
                ll_settings.setVisibility(View.GONE);
                tvStockName.setText(R.string.app_name);
                saveSettings();
            }
        });
        stockRiverBtn = (Button) rootView.findViewById(R.id.btn_stock_river);
        stockRiverBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO jhnie, open this url just a demo
                mWebView.postUrl("http://dev.trubuzz.com/home/test_chart/",
                        null);
                showProgressDialog(R.string.loading_msg, true);
                TBStockRiverConnPool.getStockRiver(
                        TBConfigUtils.getStockID(mActivity),
                        TBConstDef.CB_GET_STOCK_RIVER + "");
                listMode = TB_STOCK_MODE;
                mWebView.setVisibility(View.VISIBLE);
                ll_msg_wall.setVisibility(View.VISIBLE);
                ll_settings.setVisibility(View.GONE);
                // TODO jhnie, show the stock name
                tvStockName.setText("Show the stock name at here");
                saveSettings();
            }
        });
        settingsBtn = (Button) rootView.findViewById(R.id.btn_settings);
        settingsBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                isNeedSaveSettings = true;
                ll_msg_wall.setVisibility(View.GONE);
                ll_settings.setVisibility(View.VISIBLE);

            }
        });
        listView = (ListView) rootView.findViewById(android.R.id.list);
        listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            boolean isLastRow = false;

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                // 判断是否滚到最后一行
                // 当滚到最后一行且停止滚动时，执行加载
                if (isLastRow
                        && scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    // 加载元素
                    isLastRow = false;
                    if (!loading) {
                        if (null != mAdapter) {
                            loading = true;
                            if (TB_MSG_MODE == listMode) {
                                TBMsgConnPool.getOldestMsg(
                                        mAdapter.getOldestMsgId(),
                                        TBConstDef.CB_GET_OLDEST_MSG_LIST + "");
                            } else if (TB_CIRCLE_MODE == listMode) {
                                TBCircleConnPool.getOldestMsg(
                                        id,
                                        mAdapter.getOldestMsgId(),
                                        TBConstDef.CB_GET_OLDEST_CIRCLE_MSG_LIST
                                                + "");
                            } else {
                                TBStockRiverConnPool.getOldestStockRiver(
                                        TBConfigUtils
                                                .getStockID(TBApplication.mGlobalContext),
                                        mAdapter.getOldestMsgId(),
                                        TBConstDef.CB_GET_OLDEST_STOCK_RIVER
                                                + "");
                            }
                        } else {
                            if (TB_MSG_MODE == listMode) {
                                TBMsgConnPool
                                        .getMessage(TBConstDef.CB_GET_MSG_LIST
                                                + "");
                            } else if (TB_CIRCLE_MODE == listMode) {
                                TBCircleConnPool.getCircle(id,
                                        TBConstDef.CB_GET_CIRCLE_MSG + "");
                            } else {
                                TBStockRiverConnPool.getStockRiver(
                                        TBConfigUtils.getStockID(mActivity),
                                        TBConstDef.CB_GET_STOCK_RIVER + "");
                            }
                            refreshableView.finishRefreshing();
                        }
                    }
                    showToast(R.string.loading_old, Toast.LENGTH_SHORT);
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem,
                    int visibleItemCount, int totalItemCount) {
                if (firstVisibleItem + visibleItemCount == totalItemCount
                        && totalItemCount > 0) {
                    isLastRow = true;
                }
            }
        });
        mWebView = (WebView) rootView.findViewById(R.id.wb_stock);

        mWebView.getSettings().setJavaScriptEnabled(true);
        mWebView.getSettings().setUseWideViewPort(true);
        mWebView.getSettings().setLoadWithOverviewMode(true);
        mWebView.clearCache(true);

        mWebView.setWebViewClient(new WebViewClient() {

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
            }

            public void onReceivedSslError(WebView view,
                    SslErrorHandler handler, SslError error) {
                // handler.cancel(); // Android默认的处理方式
                handler.proceed(); // 接受所有网站的证书
                // handleMessage(Message msg); // 进行其他处理
            }
        });
        if (TB_STOCK_MODE == listMode) {
            mWebView.postUrl("http://dev.trubuzz.com/home/test_chart/", null);
            mWebView.setVisibility(View.VISIBLE);
        } else {
            mWebView.setVisibility(View.GONE);
        }
        mWebView.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);

        showProgressDialog(R.string.loading_msg, true);
        if (TB_MSG_MODE == listMode) {
            TBMsgConnPool.getMessage(TBConstDef.CB_GET_MSG_LIST + "");
        } else if (TB_CIRCLE_MODE == listMode) {
            TBCircleConnPool.getCircle(id, TBConstDef.CB_GET_CIRCLE_MSG + "");
        } else {
            TBStockRiverConnPool.getStockRiver(
                    TBConfigUtils.getStockID(mActivity),
                    TBConstDef.CB_GET_STOCK_RIVER + "");
        }
        return rootView;
    }

    protected void processBrodcast(int actionID, TBNetworkResult netResult) {
        switch (actionID) {
        case TBConstDef.CB_GET_MSG_LIST:
        case TBConstDef.CB_GET_CIRCLE_MSG:
            stopProgressDialog();
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                setMsgList((TBMessageList) netResult);
            }
            break;
        case TBConstDef.CB_GET_STOCK_RIVER:
            stopProgressDialog();
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                setMsgList((TBMessageList) netResult);
            }
            break;
        case TBConstDef.CB_BUZZ_MSG:
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                mAdapter.buzzedMsg((TBMessage) netResult);
            }
            stopProgressDialog();
            break;
        case TBConstDef.CB_BULL_MSG:
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                mAdapter.bullMsg((TBMessage) netResult);
            }
            stopProgressDialog();
            break;
        case TBConstDef.CB_BEAR_MSG:
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                mAdapter.bearMsg((TBMessage) netResult);
            }
            stopProgressDialog();
            break;
        case TBConstDef.CB_DELETE_MSG:
            stopProgressDialog();
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                mAdapter.deletedMsg((TBMessage) netResult);
            }
            break;
        case TBConstDef.CB_GET_NEWEST_MSG_LIST:
            refreshableView.finishRefreshing();
            loading = false;
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                if (TB_MSG_MODE == listMode) {
                    mAdapter.addNewstMsg((TBMessageList) netResult);
                }
            }

            break;
        case TBConstDef.CB_GET_OLDEST_MSG_LIST:
            refreshableView.finishRefreshing();
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                if (TB_MSG_MODE == listMode) {
                    mAdapter.addOldestMsg((TBMessageList) netResult);
                }
            }
            loading = false;
            break;
        case TBConstDef.CB_GET_NEWEST_STOCK_RIVER:
            refreshableView.finishRefreshing();
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                if (TB_STOCK_MODE == listMode) {
                    mAdapter.addNewstMsg((TBMessageList) netResult);
                }
            }
            loading = false;
            break;
        case TBConstDef.CB_GET_OLDEST_STOCK_RIVER:
            refreshableView.finishRefreshing();
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                if (TB_STOCK_MODE == listMode) {
                    mAdapter.addOldestMsg((TBMessageList) netResult);
                }
            }
            loading = false;
            break;
        case TBConstDef.CB_GET_NEWEST_CIRCLE_MSG_LIST:
            refreshableView.finishRefreshing();
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                if (TB_CIRCLE_MODE == listMode) {
                    mAdapter.addNewstMsg((TBMessageList) netResult);
                }
            }
            loading = false;
            break;
        case TBConstDef.CB_GET_OLDEST_CIRCLE_MSG_LIST:
            refreshableView.finishRefreshing();
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                if (TB_CIRCLE_MODE == listMode) {
                    mAdapter.addOldestMsg((TBMessageList) netResult);
                }
            }
            loading = false;
            break;
        case TBConstDef.CB_GET_SHARE_MSG:
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                mAdapter.setSharedMsgContent((TBMessage) netResult);

            }
            break;
        default:
            TBLog.e(TAG, "fatal error: unknown network callback function id: "
                    + actionID);
            break;
        }

    }

    @Override
    protected void regTBRecver() {
        mReceiver = new TBReciver();
        IntentFilter filter = new IntentFilter();
        filter.addAction(TBConstDef.CB_GET_MSG_LIST + "");
        filter.addAction(TBConstDef.CB_GET_CIRCLE_MSG + "");
        filter.addAction(TBConstDef.CB_BUZZ_MSG + "");
        filter.addAction(TBConstDef.CB_BULL_MSG + "");
        filter.addAction(TBConstDef.CB_BEAR_MSG + "");
        filter.addAction(TBConstDef.CB_DELETE_MSG + "");
        filter.addAction(TBConstDef.CB_GET_STOCK_RIVER + "");
        filter.addAction(TBConstDef.CB_GET_NEWEST_MSG_LIST + "");
        filter.addAction(TBConstDef.CB_GET_OLDEST_MSG_LIST + "");
        filter.addAction(TBConstDef.CB_GET_NEWEST_STOCK_RIVER + "");
        filter.addAction(TBConstDef.CB_GET_OLDEST_STOCK_RIVER + "");
        filter.addAction(TBConstDef.CB_GET_NEWEST_CIRCLE_MSG_LIST + "");
        filter.addAction(TBConstDef.CB_GET_OLDEST_CIRCLE_MSG_LIST + "");
        filter.addAction(TBConstDef.CB_GET_SHARE_MSG + "");

        mActivity.registerReceiver(mReceiver, filter);
    }

    @Override
    public void onRefresh() {
        // TODO Auto-generated method stub

    }

    // @Override
    // public void onResume() {
    // super.onResume();
    // refreshMsgWall();
    // }

}
