package com.TruBuzz.Fragments;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;
import com.TruBuzz.TBNetwork.TBNetworkResult;

public abstract class TBBaseFragment extends Fragment {
    public static int TB_MSG_MODE = 0;
    public static int TB_CIRCLE_MODE = 1;
    public static int TB_STOCK_MODE = 2;
    public static String TB_LIST_MODE = "tb_list_mode";
    public static String TB_ID = "tb_id";
    protected String id = "0"; // circle id or stock id
    public int listMode = -1;

    private ProgressDialog loadingBar = null;
    protected TBReciver mReceiver = null;
    protected String TAG = "";
    public Activity mActivity = null;

    protected abstract void processBrodcast(int actionID,
            TBNetworkResult netResult);

    protected abstract void regTBRecver();

    public TBBaseFragment() {
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        regTBRecver();
        return null;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mActivity = activity;
        TBLog.e(TAG, "onAttach "+activity.toString());
    }

    @Override
    public void onDestroy() {
        if (null != mReceiver) {
            mActivity.unregisterReceiver(mReceiver);
        }
        super.onDestroy();
    }

    public void showProgressDialog(String msg, boolean isCancel) {
        if (loadingBar == null) {
            loadingBar = ProgressDialog.show(mActivity, null, msg);
        } else {
            loadingBar.show();
        }
    }

    public void showProgressDialog(int resId, boolean isCancel) {
        if (loadingBar == null) {
            loadingBar = ProgressDialog.show(mActivity, null,
                    this.getString(resId));
        } else {
            loadingBar.show();
        }
    }

    public void stopProgressDialog() {
        if (loadingBar != null) {
            loadingBar.dismiss();
        }
        loadingBar = null;
    }

    public void showToast(String msg, int time) {
        Toast.makeText(mActivity, msg, time).show();
    }

    public void showToast(int resId, int time) {
        Toast.makeText(mActivity, resId, time).show();
    }

    public class TBReciver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            TBLog.d(TAG, "network callback: " + action);
            int actionId = Integer.parseInt(action);
            TBNetworkResult netResult = (TBNetworkResult) intent
                    .getSerializableExtra(TBConstDef.NET_RESULT);
            processBrodcast(actionId, netResult);
        }

    }
}
