package com.TruBuzz.Fragments;

import android.annotation.SuppressLint;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.TruBuzz.Activity.MainUIActivity;
import com.TruBuzz.Adapter.TBCircleAdapter;
import com.TruBuzz.TBBeans.TBCircle;
import com.TruBuzz.TBBeans.TBCircleList;
import com.TruBuzz.TBCommon.TBConfigUtils;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;
import com.TruBuzz.TBDataBase.TBDBUtils;
import com.TruBuzz.TBNetwork.TBCircleConnPool;
import com.TruBuzz.TBNetwork.TBNetworkResult;
import com.TruBuzz.TruBuzz.R;
import com.TruBuzz.TruBuzz.TBApplication;

@SuppressLint("ValidFragment")
public class TBCircleMenuFragment extends TBBaseFragment {
    private EditText searchContent = null;
    private Button deleteBtn = null;
    private ListView listView = null;
    private TBCircleAdapter mAdapter = null;
    private TBCircleAdapter searchAdp = null;

    public TBCircleMenuFragment() {
    }

    public TBCircleMenuFragment(MainUIActivity activity, int mode) {
        super();
        listMode = mode;
    }

    public void setArguments(Bundle bundle) {

    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        super.TAG = "CircleMenuFragment";
        View rootView = inflater.inflate(R.layout.circle_list, null);
        listView = (ListView) rootView.findViewById(android.R.id.list);
        TBCircleList list = TBDBUtils.getInstance(
                TBApplication.mGlobalContext).getCircleListFromDB();
        setCircleList((TBCircleList) list);
        searchContent = (EditText) rootView.findViewById(R.id.et_searchcontent);
        searchContent.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence arg0, int arg1, int arg2,
                    int arg3) {
                if ("".equals(arg0.toString())) {
                    setCircleList(mAdapter.getCircleList());
                } else {
                    setSearchResult(mAdapter.getSearchResult(arg0.toString()));
                }

            }

            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1,
                    int arg2, int arg3) {
            }

            @Override
            public void afterTextChanged(Editable arg0) {
            }
        });
        deleteBtn = (Button) rootView.findViewById(R.id.btn_delete);
        deleteBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                searchContent.setText("");

            }
        });
        if (TB_MSG_MODE == listMode || TB_CIRCLE_MODE == listMode) {
            TBCircleConnPool.getCircleList(TBConstDef.CB_GET_CIRCLE_LIST + "");
        } else {
            // TODO jhnie replace this action with get stock river list
            TBCircleConnPool.getCircleList(TBConstDef.CB_GET_CIRCLE_LIST + "");
        }
        return rootView;
    }

    private void setSearchResult(TBCircleList circleList) {
        searchAdp = new TBCircleAdapter(mActivity, circleList);
        listView.setAdapter(searchAdp);
        listView.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                    long arg3) {
                TBMsgWallFragment content = null;
                if (TB_STOCK_MODE == listMode) {
                    // TOD jhnie add set stock river ID and mode at here
                     content = new TBMsgWallFragment(
                     (MainUIActivity) mActivity, TB_STOCK_MODE);
                     Bundle param = new Bundle();
                     param.putString(TB_ID, TBConfigUtils.getStockID(mActivity) + "");
                     content.setArguments(param);
                } else {
                    TBCircle circle = (TBCircle) searchAdp.getItem(arg2);
                    if (arg2 > 0) {
                        content = new TBMsgWallFragment(
                                (MainUIActivity) mActivity, TB_CIRCLE_MODE);
                        Bundle param = new Bundle();
                        param.putString(TB_ID, circle.id + "");
                        content.setArguments(param);
                    } else {
                        content = new TBMsgWallFragment(
                                (MainUIActivity) mActivity, TB_MSG_MODE);
                    }
                }

                switchFragment(content);
            }
        });
    }

    public void setCircleList(TBCircleList circleList) {
        mAdapter = new TBCircleAdapter(mActivity, circleList);
        listView.setAdapter(mAdapter);
        listView.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                    long arg3) {
                TBMsgWallFragment content = null;
                if (TB_STOCK_MODE == listMode) {
                    // TOD jhnie add set stock river ID and mode at here
                    // content = new TBMsgWallFragment(
                    // (MainUIActivity) mActivity, TB_STOCK_MODE);
                    // Bundle param = new Bundle();
                    // param.putString(TB_ID, circle.id + "");
                    // content.setArguments(param);
                } else {
                    TBCircle circle = (TBCircle) mAdapter.getItem(arg2);
                    if (arg2 > 0) {
                        content = new TBMsgWallFragment(
                                (MainUIActivity) mActivity, TB_CIRCLE_MODE);
                        Bundle param = new Bundle();
                        param.putString(TB_ID, circle.id + "");
                        content.setArguments(param);
                    } else {
                        content = new TBMsgWallFragment(
                                (MainUIActivity) mActivity, TB_MSG_MODE);
                    }
                }

                switchFragment(content);
            }
        });
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        // String[] birds = getResources().getStringArray(R.array.birds);
        // ArrayAdapter<String> colorAdapter = new
        // ArrayAdapter<String>(getActivity(),
        // android.R.layout.simple_list_item_1, android.R.id.text1, birds);
        // setListAdapter(colorAdapter);
    }

    //
    // @Override
    // public void onListItemClick(ListView lv, View v, int position, long id) {
    // Fragment newContent = new MsgWallFragment();
    // if (newContent != null)
    // switchFragment(newContent);
    // }

    // the meat of switching the above fragment
    private void switchFragment(Fragment fragment) {
        if (super.getActivity() == null)
            return;

        if (getActivity() instanceof MainUIActivity) {
            MainUIActivity ra = (MainUIActivity) getActivity();
            ra.switchContent(fragment);
        }
    }

    protected void processBrodcast(int actionID, TBNetworkResult netResult) {
        switch (actionID) {
        case TBConstDef.CB_GET_CIRCLE_LIST:
            stopProgressDialog();
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                TBDBUtils.getInstance(TBApplication.mGlobalContext)
                        .insertCircleList2DB((TBCircleList) netResult);
            }
            TBCircleList list = TBDBUtils.getInstance(
                    TBApplication.mGlobalContext).getCircleListFromDB();
            setCircleList((TBCircleList) list);

            break;

        default:
            TBLog.e(TAG, "fatal error: unknown network callback function id: "
                    + actionID);
            break;
        }

    }

    @Override
    protected void regTBRecver() {
        mReceiver = new TBReciver();
        IntentFilter filter = new IntentFilter();
        if (TB_MSG_MODE == listMode || TB_CIRCLE_MODE == listMode) {
            filter.addAction(TBConstDef.CB_GET_CIRCLE_LIST + "");
        } else {
            // TODO jhnie replace this action with get stock river list
            filter.addAction(TBConstDef.CB_GET_CIRCLE_LIST + "");
        }

        mActivity.registerReceiver(mReceiver, filter);
    }
}
