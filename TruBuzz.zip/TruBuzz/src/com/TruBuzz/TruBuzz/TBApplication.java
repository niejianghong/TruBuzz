package com.TruBuzz.TruBuzz;

import java.util.LinkedList;
import java.util.List;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.text.TextUtils;

import com.TruBuzz.TBBeans.TBUserInfo;
import com.TruBuzz.TBCommon.TBCatchCrash;
import com.TruBuzz.TBCommon.TBConfigUtils;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;

/**
 * TruBuzz Application 类，初始化所有全局变量
 * 
 * @author jhnie
 * 
 */
public class TBApplication extends Application {

    public static Context mGlobalContext = null;
    private TBCatchCrash catchCrashHandler = null;
    public static String session_key = null;
    public static String chat_handle = null;
    // public static String mWooshPushAppId = "4FC89B6D14A655.46488481";
    // public static String mWosshPushSenderID = "60756016005";
    public static String mWooshPushAppId = "4CFD4-736C6";
    public static String mWosshPushSenderID = "56846469641"; // this ID from
                                                             // google GCM, it
                                                             // has another
                                                             // name:project
                                                             // Number
    private static String push_token = null;
    public static String screenSize = null;
    public static String phoneNumber = null;
    public static String imei = null;
    public static TBUserInfo userInfo = null;
    private static List<Activity> activityList = new LinkedList<Activity>();

    // 添加Activity 到容器中
    public static void addActivity(Activity activity) {
        activityList.add(activity);
    }

    // 遍历所有Activity 并finish
    public static void exit() {

        for (Activity activity : activityList) {
            activity.finish();
        }
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(0);
    }

    public static void setPushToken(String token) {
        push_token = token;
        TBConfigUtils.setPushToken(mGlobalContext, token);
    }

    public static String getPushToken() {
        if (TextUtils.isEmpty(push_token)) {
            push_token = TBConfigUtils.getPushToken(mGlobalContext);
        }
        return push_token;
    }

    public void onCreate() {
        super.onCreate();
        mGlobalContext = this.getApplicationContext();
        TBLog.init(mGlobalContext);
        TBConstDef.HOST_NAME = "http://"
                + TBConfigUtils.getApiUrl(mGlobalContext);
        catchCrashHandler = TBCatchCrash.getInstance();
        catchCrashHandler.init(this);
    }
}
