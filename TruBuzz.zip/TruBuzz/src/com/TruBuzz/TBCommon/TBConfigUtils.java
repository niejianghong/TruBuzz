package com.TruBuzz.TBCommon;

import java.io.File;

import android.content.Context;
import android.preference.PreferenceManager;
import android.text.TextUtils;

public class TBConfigUtils {
    /**
     * 读取用户账号名
     */
    public static void setAccountName(Context context,String accountName){
        PreferenceManager.getDefaultSharedPreferences(context).edit().putString("accountName",accountName ).commit();
    }
    
    public static String getAcountName(Context context){
        String accountName=PreferenceManager.getDefaultSharedPreferences(context).getString("accountName", "");
        return accountName;
    }
    
    public static void setPushToken(Context context,String pushToken){
        PreferenceManager.getDefaultSharedPreferences(context).edit().putString("push_token", pushToken).commit();
    }
    
    public static String getPushToken(Context context){
        String token=PreferenceManager.getDefaultSharedPreferences(context).getString("push_token", "");
        return token;
    }
    
    /**
     * 读取用户密码
     */
    public static void setAccountPassword(Context context,String accountPassword){
        PreferenceManager.getDefaultSharedPreferences(context).edit().putString("password",accountPassword).commit();
    }
    
    public static String getAcountPassword(Context context){
        String accountPassword=PreferenceManager.getDefaultSharedPreferences(context).getString("password", "");
        return accountPassword;
    }
    
    
    /**
     * 读取API URL
     */
    public static void setApiUrl(Context context,String url){
        PreferenceManager.getDefaultSharedPreferences(context).edit().putString("api_url",url).commit();
    }
    
    public static String getApiUrl(Context context){
        String url=PreferenceManager.getDefaultSharedPreferences(context).getString("api_url", "dev.trubuzz.cn");
        return url;
    }
    
    /**
     * 读取StockID
     */
    public static void setStockID(Context context,String id){
        PreferenceManager.getDefaultSharedPreferences(context).edit().putString("stock_id",id).commit();
    }
    
    public static String getStockID(Context context){
        String url=PreferenceManager.getDefaultSharedPreferences(context).getString("stock_id", "108569");
        return url;
    }
    
    /**
     * 自动登录
     */
    public static boolean getAutoLoginFlag(Context context){
        return PreferenceManager.getDefaultSharedPreferences(context).getBoolean("auto_login",true);
    }
    
    public static void setAutoLoginFlag(Context context, boolean flag){
        PreferenceManager.getDefaultSharedPreferences(context).edit().putBoolean("auto_login", flag).commit();
    }
    
    public static boolean isExistsFile(String filepath) {
        try {
            if (TextUtils.isEmpty(filepath)) {
                return false;
            }
            File file = new File(filepath);
            return file.exists();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
 
}
