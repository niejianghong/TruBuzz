package com.TruBuzz.TBCommon;

import android.text.TextUtils;

import com.TruBuzz.TruBuzz.TBApplication;


/**
 * 常量定义的静态类
 * 
 * @author jhnie
 * 
 */
public class TBConstDef {
    
    private static String getHostUrl(){
        if(TextUtils.isEmpty(HOST_NAME)){
            HOST_NAME = "http://"+TBConfigUtils.getApiUrl(TBApplication.mGlobalContext);;
        }
        return HOST_NAME;
    }

    public static String HOST_NAME = null;
    public static String REST_API = getHostUrl() + "/api?";
    public static String USER_REG = getHostUrl() + "/api/user/?";
    public static String USER_LOGIN = getHostUrl() + "/api/user/login/?";
    public static String UPLOAD_INFO = getHostUrl() + "/api/device/?";

    public static String DELETE_MSG = getHostUrl() + "/api/message/%d?";
    public static String POST_GET_MSG = getHostUrl() + "/api/message/?";
    public static String GET_NEWEST_MSG = getHostUrl() + "/api/message/new/%d?";
    public static String GET_OLDEST_MSG = getHostUrl() + "/api/message/old/%d?";
    public static String BULL_MSG = getHostUrl() + "/api/bull/%d?";
    public static String BEAR_MSG = getHostUrl() + "/api/bear/%d?";

    public static String DELETE_REPLY_MSG = getHostUrl() + "/api/reply/%d?";
    public static String POST_GET_REPLY_MSG = getHostUrl() + "/api/message/%d/reply/?";
    public static String GET_OLDEST_REPLY_MSG = getHostUrl() + "/api/message/%d/reply/old/%d?";
    public static String GET_NEWEST_REPLY_MSG = getHostUrl() + "/api/message/%d/reply/new/%d?";

    public static String GET_PERSONAL_MSG_LIST = getHostUrl() + "/api/personal/%d?";
    public static String GET_OLDEST_PERSONAL_MSG = getHostUrl() + "/api/personal/%d/old/%d?";
    public static String GET_NEWEST_PERSONAL_MSG = getHostUrl() + "/api/personal/%d/new/%d?";

    public static String GET_POST_CIRCLE = getHostUrl() + "/api/circle/%s?";
    public static String GET_OLDEST_CIRCLE = getHostUrl() + "/api/circle/%s/old/%d?";
    public static String GET_NEWEST_CIRCLE = getHostUrl() + "/api/circle/%s/new/%d?";
    public static String GET_CIRCLE_LIST = getHostUrl() + "/api/circle/list/?";
    public static String GET_CIRCLE_MEMBERS = getHostUrl() + "/api/circle/%d/member_list/?";

    public static String BUZZ_MSG = getHostUrl() + "/api/buzz/message/%d?";
    public static String BUZZ_REPLY_MSG = getHostUrl() + "/api/buzz/reply/%d?";

    public static String GET_STOCK_RIVER = getHostUrl() + "/api/stock_message/%s?";
    public static String GET_NEWEST_STOCK_RIVER = getHostUrl() + "/api/stock_message/%s/new/%d?";
    public static String GET_OLDEST_STOCK_RIVER = getHostUrl() + "/api/stock_message/%s/old/%d?";

    public static String GET_NOTICE = getHostUrl() + "/api/notice/?";
    public static String GET_NEWEST_NOTICE = getHostUrl() + "/api/notice/new/%d?";
    public static String GET_OLDEST_NOTICE = getHostUrl() + "/api/notice/old/%d?";
    public static String SET_NOTICE_READ = getHostUrl() + "/api/notice/read_till/%d?";
    public static String DELETE_NOTICE = getHostUrl() + "/api/notice/%d?";

    public static String GET_ANNOUNCEMENT = getHostUrl() + "/api/announcement/?";
    public static String GET_OLDEST_ANNOUNCEMENT = getHostUrl() + "/api/announcement/old/%d?";
    public static String GET_NEWEST_ANNOUNCEMENT = getHostUrl() + "/api/announcement/new/%d?";
    
    
    public static String POST_SHARE_MSG = getHostUrl() + "/api/share/?";
    public static String GET_SHARE_MSG = getHostUrl() + "/api/share/%d/%d?";
    
    public static String GET_FRIENDS_LIST = getHostUrl() + "/api/friend?";
    
    

    /**
     * JSON 关键字定义
     */
    public static final String ACCOUNT = "account";
    public static final String PASSWORD = "password";
    public static final String AUTH_KEY = "authentication_key";
    public static final String EMAIL = "email";
    public static final String NICKNAME = "nickname";
    public static final String HWID = "hwid";
    public static final String PUSH_TOKEN = "push_token";
    public static final String DEVICE_SPEC = "device_spec";

    public static final String MSG_CONTET = "content";
    public static final String MSG_ID = "message_id";
    
    public static final String SHARE_MSG_ID = "share_message_id";
    public static final String SHARE_TYPE = "type";
    public static final String SHARE_ACCOUNT = "account";
    public static final String SHARE_COMMENT = "comment";
    public static final String SHARE_CIRCLE_ID = "circle";
    
    

    /**
     * 网络部分定义
     * 
     * */
    public static final String NET_RESULT = "TBNetConnectionResult";

    /**
     * 网络请求回调名称
     * 
     */
    public static final int CB_GET_AUTH_KEY = 1;
    public static final int CB_DELETE_AUTH_KEY = 2;
    
    public static final int CB_REG_NEW_USER = 21;
    public static final int CB_USER_LOGIN = 22;
    public static final int CB_GET_USER_INFO = 23;
    public static final int CB_GET_USER_AVATAR = 24;
    public static final int CB_UPLOAD_DEVICE_INFO = 25;
    
    public static final int CB_GET_MSG_LIST = 31;
    public static final int CB_POST_MSG = 32;
    public static final int CB_GET_NEWEST_MSG_LIST = 33;
    public static final int CB_GET_OLDEST_MSG_LIST = 34;
    public static final int CB_DELETE_MSG = 35;
    public static final int CB_POST_REPLY_MSG = 36;
    public static final int CB_GET_REPLY_MSG = 37;
    public static final int CB_GET_OLDEST_REPLY_MSG = 38;
    public static final int CB_GET_NEWEST_REPLY_MSG = 39;
    public static final int CB_DELETE_REPLY_MSG = 40;

    public static final int CB_GET_PERSONAL_MSG = 51;
    public static final int CB_GET_NEWEST_PERSONAL_MSG = 52;
    public static final int CB_GET_OLDEST_PERSONAL_MSG = 53;
    
    public static final int CB_POST_CIRCLE_MSG = 60;
    public static final int CB_GET_CIRCLE_MSG = 61;
    public static final int CB_GET_OLDEST_CIRCLE_MSG_LIST = 62;
    public static final int CB_GET_NEWEST_CIRCLE_MSG_LIST = 63;
    public static final int CB_GET_CIRCLE_LIST = 64;
    public static final int CB_GET_CIRCLE_MEMBERS = 65;
    
    public static final int CB_BUZZ_REPLY_MSG = 71;
    public static final int CB_BUZZ_MSG = 72;
    
    public static final int CB_GET_STOCK_RIVER = 81;
    public static final int CB_GET_NEWEST_STOCK_RIVER = 82;
    public static final int CB_GET_OLDEST_STOCK_RIVER = 83;
    
    public static final int CB_BULL_MSG = 91;
    public static final int CB_BEAR_MSG = 92;
    
    public static final int CB_GET_NOTICE_LIST = 101;
    public static final int CB_GET_NEWEST_NOTICE = 102;
    public static final int CB_GET_OLDEST_NOTICE = 103;
    public static final int CB_SET_NOTICE_READ = 104;
    public static final int CB_DELETE_NOTICE = 105;
    
    public static final int CB_GET_ANNOUNCEMENT = 111;
    public static final int CB_GET_NEWEST_ANNOUNCEMENT = 112;
    public static final int CB_GET_OLDEST_ANNOUNCEMENT =113;
    
    public static final int CB_POST_SHARE_MSG = 132;
    public static final int CB_GET_SHARE_MSG =133;
    
    public static final int CB_GET_FRIENDS_LIST = 150;
    public static final int CB_MAX = 151;

}
