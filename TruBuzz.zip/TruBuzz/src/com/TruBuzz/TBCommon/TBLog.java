package com.TruBuzz.TBCommon;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;

public final class TBLog {

    public static final int LOG_TRACE = 0;
    public static final int LOG_WARNING = 1;
    public static final int LOG_ERROR = 2;
    public static final int LOG_KEYPATH = 3;
    public static final int LOG_NO_LOG = 4;
    private static int LOG_LEVEL = LOG_TRACE;
    public static boolean isRelease = false;
    public static final SimpleDateFormat SDF2 = new SimpleDateFormat("MM-dd HH:mm:ss");
    public static File file = null;
    public static FileWriter fWriter = null;
    public static final String logpath = File.separator + "TruBuzzLog/";
    public static Context mContext = null;
    
    public static String getSDCardPath(Context c) {
        File sdDir = null;
        String sdStatus = Environment.getExternalStorageState();

        if (TextUtils.isEmpty(sdStatus)) {
            return c.getFilesDir().getAbsolutePath();
        }

        boolean sdCardExist = sdStatus.equals(android.os.Environment.MEDIA_MOUNTED);

        if (sdCardExist) {
            sdDir = Environment.getExternalStorageDirectory();
            return sdDir.toString();
        }

        return c.getFilesDir().getAbsolutePath();
    }

    public synchronized static void init(Context c) {
        mContext = c;
        isRelease = (0 == (c.getApplicationInfo().flags &= ApplicationInfo.FLAG_DEBUGGABLE));

        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            try {
                String newLog = getSDCardPath(c) + logpath + "TBLog.log";
                String bakLog = getSDCardPath(c) + logpath + "TBlog-bak.log";
                file = new File(newLog);
                if (!file.getParentFile().exists()) {
                    file.getParentFile().mkdirs();
                }

                if (!file.exists()) {
                    file.createNewFile();
                } else {
                    File file_bak = new File(bakLog);
                    if (file_bak.exists())
                        file_bak.delete();
                    file.renameTo(file_bak);
                    file = null;
                    file = new File(newLog);
                    file.createNewFile();
                }
                if(fWriter != null){
                    fWriter.close();
                }
                fWriter = new FileWriter(file);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static void destroy() {
    	file = null;
    }

    public static String nnGetStactTrace(Exception e) {
        if (null == e)
            return null;
        String ret = e.toString();
        StackTraceElement[] stack = e.getStackTrace();
        for (int i = 0; stack != null && i < stack.length; ++i) {
            ret += "\n" + stack[i].toString();
        }
        return ret;
    }

    public static void nnPrintStackTrace(Exception e) {
        if (null == e)
            return;
        e("nnGlobal", "Exception: " + e.toString());
        StackTraceElement[] stack = e.getStackTrace();
        for (int i = 0; stack != null && i < stack.length; ++i) {
            e("nnGlobal", stack[i].toString());
        }
    }

    public static void e(String tag, String msg) {
        if (LOG_LEVEL <= LOG_ERROR) {
            Log.e(tag, "thread Id: " + Thread.currentThread().getId() + "  " + msg);
            if (file == null || !file.exists()) {
                return;
            }
            appendLog(file, tag + "\t" + "thread Id: " + Thread.currentThread().getId() + "  "
                    + msg, 0);
        }
    }

    public static void d(String tag, String msg) {
        if (LOG_LEVEL <= LOG_TRACE) {
            Log.i(tag, "thread Id: " + Thread.currentThread().getId() + "  " + msg);
            if (file == null || !file.exists()) {
                return;
            }
            appendLog(file, tag + "\t" + "thread Id: " + Thread.currentThread().getId() + "  "
                    + msg, 1);
        }
    }

    public static void w(String tag, String msg) {
        if (LOG_LEVEL <= LOG_WARNING) {
            Log.w(tag, "thread Id: " + Thread.currentThread().getId() + "  " + msg);
            if (file == null || !file.exists()) {
                return;
            }
            appendLog(file, tag + "\t" + "thread Id: " + Thread.currentThread().getId() + "  "
                    + msg, 2);
        }
    }

    public static void appendLog(File file, String content, int level) {
        try {
            if (file == null || !file.exists()) {
                return;
            }
            StringBuffer sb = new StringBuffer();
            sb.append(SDF2.format(new Date()));
            sb.append("\t ");
            sb.append(level == 1 ? "i" : level == 2 ? "w" : "e");
            sb.append("\t");
            sb.append(content);
            sb.append("\r\n");
            fWriter.write(sb.toString());
            fWriter.flush();
        } catch (Exception e) {
            Log.e("nnGlobal", "log output exception,maybe the log file is not exists,"
                    + nnGetStactTrace(e));
        } finally {
                if (file != null && file.length() >= 1024*1024*3) {
                    init(mContext);
                    return;
                }
        }
    }

}
