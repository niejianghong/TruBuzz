package com.TruBuzz.TBNetwork;

import java.io.Serializable;

import org.json.JSONException;
import org.json.JSONObject;

import com.TruBuzz.TBCommon.TBLog;


/**
 * 连接错误类
 * 
 * @author jhnie
 * 
 */
public class TBNetworkResult implements Serializable{
    
    /**
     * 
     */
    private static final long serialVersionUID = 8883314413973997746L;
    private static final String TAG = "TBUserList";
    public int errorCode = -1;
    public String errorMsg = "default error";
    
    public static int SUCCESS = 0;
    public static int ERROR = -1;
    
    public TBNetworkResult(int errorCode, String errorMsg){
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
    }
    
    @Override
    public boolean equals(Object result){
        return false;
    }
    

    
    public TBNetworkResult(JSONObject obj){
        try {
            if(null == obj){
                return;
            }
            this.errorCode = obj.getInt("error_code");
            this.errorMsg = obj.getString("error_message");
        } catch (JSONException e) {
            TBLog.e(TAG, e.getMessage());
        }

    }

    public TBNetworkResult() {
        // TODO Auto-generated constructor stub
    }

}
