package com.TruBuzz.TBNetwork;

import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.TruBuzz.TBBeans.TBMessageList;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;

/**
 * 连接请求池，所有StockRiver相关的通信全部写在这里
 * 
 * @author jhnie
 * 
 */
public class TBStockRiverConnPool extends TBConnection {
    private static String TAG = "TBStockRiverConnPool";

    public static void getStockRiver(final String stockId, final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = TBConnection.sendHttpGetRequest(String.format(
                            TBConstDef.GET_STOCK_RIVER, stockId)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result && "200".equalsIgnoreCase(result.getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get stock river is null");
                            notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get stock river is null"), callbackName);
                            return;
                        }

                        TBMessageList resultMsg = new TBMessageList();
                        resultMsg.minimumMessageId = resource.getLong("minimumMessageId");
                        resultMsg.newestMessageId = resource.getLong("newestMessageId");
                        resultMsg.oldestMessageId = resource.getLong("oldestMessageId");

                        JSONArray messages = resource.getJSONArray("messages");
                        resultMsg.setMsgList(messages);

                        notifyNetworkResult(resultMsg, callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "get stock river return error.");
                            notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get stock river return error."), callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(
                                    result.getJSONObject("error"));
                            TBLog.e(TAG, "get stock river return error:" + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                            "get stock river is exception" + e.getMessage()), callbackName);
                }
            }
        }).start();
    }

    public static void getNewestStockRiver(final String stockid, final long newestMsgId,
            final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();
                    JSONObject result = TBConnection.sendHttpGetRequest(String.format(
                            TBConstDef.GET_NEWEST_STOCK_RIVER, stockid, newestMsgId)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result && "200".equalsIgnoreCase(result.getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get newest stock river is null");
                            notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get newest stock river is null"), callbackName);
                            return;
                        }

                        TBMessageList resultMsg = new TBMessageList();
                        resultMsg.newestMessageId = resource.getLong("newestMessageId");

                        JSONArray messages = resource.getJSONArray("messages");
                        resultMsg.setMsgList(messages);

                        notifyNetworkResult(resultMsg, callbackName);

                    } else {
                        notifyNetworkResult(
                                new TBNetworkResult(TBNetworkResult.ERROR,
                                        "no centent to refresh"), callbackName);
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                            "get newest stock river is exception" + e.getMessage()), callbackName);
                }
            }
        }).start();
    }

    public static void getOldestStockRiver(final String string, final long oldestMsgId,
            final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = TBConnection.sendHttpGetRequest(String.format(
                            TBConstDef.GET_OLDEST_STOCK_RIVER, string, oldestMsgId)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result && "200".equalsIgnoreCase(result.getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get oldest stock river is null");
                            notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get oldest stock river is null"), callbackName);
                            return;
                        }

                        TBMessageList resultMsg = new TBMessageList();
                        resultMsg.oldestMessageId = resource.getLong("oldestMessageId");

                        JSONArray messages = resource.getJSONArray("messages");
                        resultMsg.setMsgList(messages);

                        notifyNetworkResult(resultMsg, callbackName);

                    }  else {
                        notifyNetworkResult(
                                new TBNetworkResult(TBNetworkResult.ERROR,
                                        "no centent to refresh"), callbackName);
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                            "get oldest stock river is exception" + e.getMessage()), callbackName);
                }
            }
        }).start();
    }

}
