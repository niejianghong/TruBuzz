package com.TruBuzz.TBNetwork;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.TextUtils;

import com.TruBuzz.TBBeans.TBUserInfo;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;
import com.TruBuzz.TruBuzz.TBApplication;

/**
 * 连接请求池，所有跟用户相关的通信全部写在这个类里
 * 
 * @author jhnie
 * 
 */
public class TBUserConnPool extends TBConnection {
    private static String TAG = "TBUserConnPool";

    public static void getSessionKey(final String callbackName) {

        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    JSONObject result = sendHttpGetRequest(TBConstDef.REST_API);
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get authentication_key is null");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "get authentication_key is null"),
                                    callbackName);
                            return;
                        } else {
                            String auth_key = resource
                                    .getString("authentication_key");
                            TBApplication.session_key = auth_key;
                            TBApplication.chat_handle = resource.getString("chat_handle");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.SUCCESS, ""), callbackName);
                        }

                    } else {
                        TBLog.e(TAG, "get authentication_key is return error.");
                        notifyNetworkResult(new TBNetworkResult(
                                result != null ? result.getJSONObject("error")
                                        : null), callbackName);
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(
                            new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get authentication_key is exception"
                                            + e.getMessage()), callbackName);
                }
            }
        }).start();

    }

    public static void regNewUser(final String account, final String password,
            final String eMail, final String nickName, final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();
                    params.add(new BasicNameValuePair(TBConstDef.ACCOUNT,
                            account));
                    params.add(new BasicNameValuePair(TBConstDef.PASSWORD,
                            password));
                    params.add(new BasicNameValuePair(TBConstDef.EMAIL, eMail));
                    params.add(new BasicNameValuePair(TBConstDef.NICKNAME,
                            nickName));

                    JSONObject result = sendHttpPostRequest(
                            TBConstDef.USER_REG, params);
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        if (result.has("error")) {
                            try {
                                TBNetworkResult error = new TBNetworkResult(
                                        result.getJSONObject("error"));
                                TBLog.e(TAG, "new user reg return error."
                                        + error.errorMsg);
                                notifyNetworkResult(error, callbackName);
                                return;
                            } catch (Exception e) {

                            }
                        }
                        TBLog.e(TAG, "new user reg success: " + account);
                        notifyNetworkResult(new TBNetworkResult(
                                TBNetworkResult.SUCCESS,
                                "new user reg success: " + account),
                                callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "new user reg return error.");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "new user reg return error."), callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(result
                                    .getJSONObject("error"));
                            TBLog.e(TAG, "new user reg return error."
                                    + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(
                            TBNetworkResult.ERROR, "regToServer is exception"
                                    + e.getMessage()), callbackName);
                }
            }
        }).start();
    }

    public static void login(final String account, final String password,
            final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();
                    params.add(new BasicNameValuePair(TBConstDef.ACCOUNT,
                            account));
                    params.add(new BasicNameValuePair(TBConstDef.PASSWORD,
                            password));
                    params.add(new BasicNameValuePair(TBConstDef.HWID,
                            TBApplication.imei));
                    params.add(new BasicNameValuePair(TBConstDef.PUSH_TOKEN,
                            TBApplication.getPushToken()));
                    params.add(new BasicNameValuePair(TBConstDef.DEVICE_SPEC,
                            TBApplication.screenSize + "|"
                                    + android.os.Build.MODEL + "|"
                                    + TBApplication.phoneNumber));

                    JSONObject result = sendHttpPostRequest(
                            TBConstDef.USER_LOGIN, params);
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        if (result.has("error")) {
                            try {
                                TBNetworkResult error = new TBNetworkResult(
                                        result.getJSONObject("error"));
                                TBLog.e(TAG, "new user reg return error."
                                        + error.errorMsg);
                                notifyNetworkResult(error, callbackName);
                                return;
                            } catch (Exception e) {

                            }
                        }
                        TBLog.e(TAG, "user login success: " + account);
                        notifyNetworkResult(new TBNetworkResult(
                                TBNetworkResult.SUCCESS, "user login success: "
                                        + account), callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "user login return error.");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "user login return error."), callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(
                                    result.getJSONObject("error"));
                            TBLog.e(TAG, "user login return error."
                                    + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(
                            new TBNetworkResult(TBNetworkResult.ERROR,
                                    "login is exception" + e.getMessage()),
                            callbackName);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public static void uploadDeviceInfo(final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();
                    params.add(new BasicNameValuePair(TBConstDef.HWID,
                            TBApplication.imei));
                    params.add(new BasicNameValuePair(TBConstDef.PUSH_TOKEN,
                            TBApplication.getPushToken()));
                    params.add(new BasicNameValuePair(TBConstDef.DEVICE_SPEC,
                            TBApplication.screenSize + "|"
                                    + android.os.Build.MODEL + "|"
                                    + TBApplication.phoneNumber));

                    JSONObject result = sendHttpPutRequest(
                            TBConstDef.UPLOAD_INFO, params);
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        if (result.has("error")) {
                            try {
                                TBNetworkResult error = new TBNetworkResult(
                                        result.getJSONObject("error"));
                                TBLog.e(TAG,
                                        "upload device information return error."
                                                + error.errorMsg);
                                notifyNetworkResult(error, callbackName);
                                return;
                            } catch (Exception e) {

                            }
                        }
                        TBLog.e(TAG, "upload device information success: "
                                + TBApplication.getPushToken());
                        notifyNetworkResult(new TBNetworkResult(
                                TBNetworkResult.SUCCESS, ""), callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "upload device information return error.");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "upload device information return error."), callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(
                                    result.getJSONObject("error"));
                            TBLog.e(TAG, "upload device information return error."
                                    + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(
                            new TBNetworkResult(TBNetworkResult.ERROR,
                                    "upload device information has exception" + e.getMessage()),
                            callbackName);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public static void deleteSessionKey(final String callbackName) {

        new Thread(new Runnable() {

            @Override
            public void run() {
                try {

                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = sendHttpDeleteRequest(TBConstDef.REST_API
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        TBApplication.session_key = null;
                        TBLog.e(TAG, "delete session_key from server success.");
                        notifyNetworkResult(new TBNetworkResult(
                                TBNetworkResult.SUCCESS,
                                "delete session_key from server success."),
                                callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG,
                                    "delete session_key from server return error.");
                            notifyNetworkResult(
                                    new TBNetworkResult(TBNetworkResult.ERROR,
                                            "delete session_key from server return error."),
                                    callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(result
                                    .getJSONObject("error"));
                            TBLog.e(TAG,
                                    "delete session_key from server return error: "
                                            + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(
                            new TBNetworkResult(TBNetworkResult.ERROR,
                                    "delte sesstion_key is exception"
                                            + e.getMessage()), callbackName);
                }
            }
        }).start();

    }

    /**
     * Get image from newwork
     * 
     * @param path
     *            The path of image
     * @return InputStream
     * @throws Exception
     */
    private static InputStream getImageStream(String path) throws Exception {
        URL url = new URL(path);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(5 * 1000);
        conn.setRequestMethod("GET");
        if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
            return conn.getInputStream();
        }
        return null;
    }

    /**
     * 保存文件
     * 
     * @param bm
     * @param fileName
     * @throws IOException
     */
    private static boolean saveFile(Bitmap bm, String fileName)
            throws IOException {
        File file = new File(fileName);
        try {
            if (!file.getParentFile().exists()) {
                file.getParentFile().mkdirs();
            }

            if (!file.exists()) {
                file.createNewFile();
            } else {
                file.delete();
                file = null;
                file = new File(fileName);
                file.createNewFile();
            }
            BufferedOutputStream bos = new BufferedOutputStream(
                    new FileOutputStream(file));
            bm.compress(Bitmap.CompressFormat.JPEG, 80, bos);
            bos.flush();
            bos.close();
            return true;
        } catch (IOException e) {
            TBLog.e(TAG, e.getMessage());
            return false;
        }
    }

    public static void getUserAvatar(final String url, final String path,
            final String callbackName) {
        if (TextUtils.isEmpty(url)) {
            TBLog.e(TAG, "avatar url is null.");
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {

                    Bitmap mBitmap = BitmapFactory
                            .decodeStream(getImageStream(url));
                    if (saveFile(mBitmap, path)) {
                        notifyNetworkResult(new TBNetworkResult(
                                TBNetworkResult.SUCCESS, ""), callbackName);
                    } else {
                        notifyNetworkResult(
                                new TBNetworkResult(TBNetworkResult.ERROR,
                                        "get user avatar faild."), callbackName);
                    }
                } catch (Exception e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(
                            TBNetworkResult.ERROR, "get user avatar exception"
                                    + e.getMessage()), callbackName);
                }
            }

        }).start();
    }

    public static void getUserInfo(final String callbackName) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = sendHttpGetRequest(TBConstDef.USER_REG
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {

                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get user info is null");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "get user info is null"), callbackName);
                            return;
                        }

                        TBUserInfo userInfo = new TBUserInfo(
                                resource.getJSONObject("user"));

                        notifyNetworkResult(userInfo, callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "get user info return error.");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "get user info error."), callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(
                                    result.getJSONObject("error"));
                            TBLog.e(TAG, "get user info return error."
                                    + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(
                            TBNetworkResult.ERROR,
                            "get user info return exception" + e.getMessage()),
                            callbackName);
                }
            }
        }).start();
    }

    public static void test() {

        String Uri = TBConstDef.HOST_NAME + "/api/test?";
        List<NameValuePair> keyValue = getParamKeyValue();
        JSONObject result = sendHttpGetRequest(Uri
                + URLEncodedUtils.format(keyValue, "UTF-8"));
        try {
            if (null != result
                    && "200".equalsIgnoreCase(result.getString("status"))) {
                TBLog.e(TAG, "test error: ");

            } else {

            }
        } catch (JSONException e) {
            TBLog.e(TAG, e.getMessage());
        }

    }

}
