package com.TruBuzz.TBNetwork;

import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.TruBuzz.TBBeans.TBMessage;
import com.TruBuzz.TBBeans.TBMessageList;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;

/**
 * 连接请求池，所有Message相关的通信全部写在这里
 * 
 * @author jhnie
 * 
 */
public class TBMsgConnPool extends TBConnection {
    private static String TAG = "TBMsgConnectionPool";

    public static void postMessage(final String msgContent,
            final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();
                    params.add(new BasicNameValuePair(TBConstDef.MSG_CONTET,
                            msgContent));

                    JSONObject result = TBConnection.sendHttpPostRequest(
                            TBConstDef.POST_GET_MSG, params);
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        notifyNetworkResult(new TBNetworkResult(
                                TBNetworkResult.SUCCESS,
                                "post message success: " + msgContent),
                                callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "post message return error.");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "post message return error."), callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(result
                                    .getJSONObject("error"));
                            TBLog.e(TAG, "post message return error:"
                                    + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(
                            new TBNetworkResult(TBNetworkResult.ERROR,
                                    "post msg is exception" + e.getMessage()),
                            callbackName);
                }
            }
        }).start();
    }

    public static void getMessage(final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = TBConnection
                            .sendHttpGetRequest(TBConstDef.POST_GET_MSG
                                    + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get message is null");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "get message is null"), callbackName);
                            return;
                        }

                        TBMessageList resultMsg = new TBMessageList();
                        resultMsg.minimumMessageId = resource
                                .getLong("minimumMessageId");
                        resultMsg.newestMessageId = resource
                                .getLong("newestMessageId");
                        resultMsg.oldestMessageId = resource
                                .getLong("oldestMessageId");

                        JSONArray messages = resource.getJSONArray("messages");
                        resultMsg.setMsgList(messages);

                        notifyNetworkResult(resultMsg, callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "get message return error.");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "get message return error."), callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(result
                                    .getJSONObject("error"));
                            TBLog.e(TAG, "get message return error:"
                                    + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(
                            new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get msg is exception" + e.getMessage()),
                            callbackName);
                }
            }
        }).start();
    }

    public static void getNewestMsg(final long newestMsgId,
            final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();
                    JSONObject result = TBConnection.sendHttpGetRequest(String
                            .format(TBConstDef.GET_NEWEST_MSG, newestMsgId)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get newest msg is null");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "get newest msg is null"), callbackName);
                            return;
                        }

                        TBMessageList resultMsg = new TBMessageList();
                        resultMsg.newestMessageId = resource
                                .getLong("newestMessageId");

                        JSONArray messages = resource.getJSONArray("messages");
                        resultMsg.setMsgList(messages);

                        notifyNetworkResult(resultMsg, callbackName);

                    } else {
                        notifyNetworkResult(
                                new TBNetworkResult(TBNetworkResult.ERROR,
                                        "no centent to refresh"), callbackName);
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(
                            TBNetworkResult.ERROR,
                            "get newest msg is exception" + e.getMessage()),
                            callbackName);
                }
            }
        }).start();
    }

    public static void getOldestMsg(final long oldestMsgId,
            final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = TBConnection.sendHttpGetRequest(String
                            .format(TBConstDef.GET_OLDEST_MSG, oldestMsgId)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get oldest msg is null");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "get oldest msg is null"), callbackName);
                            return;
                        }

                        TBMessageList resultMsg = new TBMessageList();
                        resultMsg.oldestMessageId = resource
                                .getLong("oldestMessageId");

                        JSONArray messages = resource.getJSONArray("messages");
                        resultMsg.setMsgList(messages);

                        notifyNetworkResult(resultMsg, callbackName);

                    } else {
                        notifyNetworkResult(
                                new TBNetworkResult(TBNetworkResult.ERROR,
                                        "no centent to refresh"), callbackName);
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(
                            TBNetworkResult.ERROR,
                            "get oldest msg is exception" + e.getMessage()),
                            callbackName);
                }
            }
        }).start();
    }

    public static void deleteMsg(final TBMessage msg, final String callbackName) {

        new Thread(new Runnable() {

            @Override
            public void run() {
                try {

                    List<NameValuePair> params = getParamKeyValue();
                    TBMessage ret = msg;
                    ret.resetStatus();
                    JSONObject result = TBConnection
                            .sendHttpDeleteRequest(String.format(
                                    TBConstDef.DELETE_MSG, ret.id)
                                    + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        TBLog.e(TAG, "delete msg from server success.");
                        notifyNetworkResult(ret, callbackName);

                    } else {
                        if (null == result) {
                            ret.errorCode = TBNetworkResult.ERROR;
                            ret.errorMsg = "delete msg from server return error.";
                            TBLog.e(TAG, "delete msg from server return error.");
                            notifyNetworkResult(ret, callbackName);
                        } else {
                            try {
                                ret.errorCode = Integer.valueOf(result
                                        .getJSONObject("error").getInt(
                                                "error_code"));
                                ret.errorMsg = result.getJSONObject("error")
                                        .getString("error_message");
                            } catch (Exception e) {

                            }
                            TBLog.e(TAG, "post bull message return error:"
                                    + ret.errorMsg);
                            notifyNetworkResult(ret, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    TBMessage ret = msg;
                    ret.resetStatus();
                    ret.errorCode = TBNetworkResult.ERROR;
                    ret.errorMsg = e.getMessage();
                    notifyNetworkResult(ret, callbackName);
                }
            }
        }).start();
    }

    public static void postBuzzMessage(final TBMessage msg,
            final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();
                    TBMessage ret = msg;
                    ret.resetStatus();
                    JSONObject result = TBConnection.sendHttpPostRequest(
                            String.format(TBConstDef.BUZZ_MSG, msg.id), params);
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        if (result.has("error")) {
                            try {
                                ret.errorCode = Integer.valueOf(result
                                        .getJSONObject("error").getInt(
                                                "error_code"));
                                ret.errorMsg = result.getJSONObject("error")
                                        .getString("error_message");
                            } catch (Exception e) {

                            }
                        }

                        notifyNetworkResult(msg, callbackName);

                    } else {
                        if (null == result) {
                            ret.errorCode = TBNetworkResult.ERROR;
                            ret.errorMsg = "net exception.";
                            TBLog.e(TAG, "buzz message return error.");
                            notifyNetworkResult(ret, callbackName);
                        } else {
                            try {
                                ret.errorCode = Integer.valueOf(result
                                        .getJSONObject("error").getInt(
                                                "error_code"));
                                ret.errorMsg = result.getJSONObject("error")
                                        .getString("error_message");
                            } catch (Exception e) {

                            }
                            TBLog.e(TAG, "buzz message return error:"
                                    + ret.errorMsg);
                            notifyNetworkResult(ret, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    TBMessage ret = msg;
                    ret.resetStatus();
                    ret.errorCode = TBNetworkResult.ERROR;
                    ret.errorMsg = e.getMessage();
                    notifyNetworkResult(ret, callbackName);
                }
            }
        }).start();
    }

    public static void postBullMessage(final TBMessage msg,
            final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();
                    TBMessage ret = msg;
                    ret.resetStatus();
                    JSONObject result = TBConnection.sendHttpPostRequest(
                            String.format(TBConstDef.BULL_MSG, msg.id), params);
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        if (result.has("error")) {
                            try {
                                ret.errorCode = Integer.valueOf(result
                                        .getJSONObject("error").getInt(
                                                "error_code"));
                                ret.errorMsg = result.getJSONObject("error")
                                        .getString("error_message");
                            } catch (Exception e) {

                            }
                        }

                        notifyNetworkResult(msg, callbackName);

                    } else {
                        if (null == result) {
                            ret.errorCode = TBNetworkResult.ERROR;
                            ret.errorMsg = "net exception.";
                            TBLog.e(TAG, "post bull message return error.");
                            notifyNetworkResult(ret, callbackName);
                        } else {
                            try {
                                ret.errorCode = Integer.valueOf(result
                                        .getJSONObject("error").getInt(
                                                "error_code"));
                                ret.errorMsg = result.getJSONObject("error")
                                        .getString("error_message");
                            } catch (Exception e) {

                            }
                            TBLog.e(TAG, "post bull message return error:"
                                    + ret.errorMsg);
                            notifyNetworkResult(ret, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    TBMessage ret = msg;
                    ret.resetStatus();
                    ret.errorCode = TBNetworkResult.ERROR;
                    ret.errorMsg = e.getMessage();
                    notifyNetworkResult(ret, callbackName);
                }
            }
        }).start();
    }

    public static void postBearMessage(final TBMessage msg,
            final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();
                    TBMessage ret = msg;
                    ret.resetStatus();
                    JSONObject result = TBConnection.sendHttpPostRequest(
                            String.format(TBConstDef.BEAR_MSG, msg.id), params);
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        if (result.has("error")) {
                            try {
                                ret.errorCode = Integer.valueOf(result
                                        .getJSONObject("error").getInt(
                                                "error_code"));
                                ret.errorMsg = result.getJSONObject("error")
                                        .getString("error_message");
                            } catch (Exception e) {

                            }
                        }

                        notifyNetworkResult(msg, callbackName);

                    } else {
                        if (null == result) {
                            ret.errorCode = TBNetworkResult.ERROR;
                            ret.errorMsg = "net exception.";
                            TBLog.e(TAG, "post bear message return error.");
                            notifyNetworkResult(ret, callbackName);
                        } else {
                            try {
                                ret.errorCode = Integer.valueOf(result
                                        .getJSONObject("error").getInt(
                                                "error_code"));
                                ret.errorMsg = result.getJSONObject("error")
                                        .getString("error_message");
                            } catch (Exception e) {

                            }
                            TBLog.e(TAG, "post bear message return error:"
                                    + ret.errorMsg);
                            notifyNetworkResult(ret, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    TBMessage ret = msg;
                    ret.resetStatus();
                    ret.errorCode = TBNetworkResult.ERROR;
                    ret.errorMsg = e.getMessage();
                    notifyNetworkResult(ret, callbackName);
                }
            }
        }).start();
    }
}
