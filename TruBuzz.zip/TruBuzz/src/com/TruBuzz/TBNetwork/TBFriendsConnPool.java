package com.TruBuzz.TBNetwork;

import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.TruBuzz.TBBeans.TBUserList;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;

/**
 * 连接请求池，所有Friends相关的通信全部写在这里
 * 
 * @author jhnie
 * 
 */
public class TBFriendsConnPool extends TBConnection {
    private static String TAG = "TBFriendsConnPool";

    public static void getFriendsList(final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = sendHttpGetRequest(TBConstDef.GET_FRIENDS_LIST
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        JSONArray resource = result.getJSONArray("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get friends list is null");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "get friends list is null"), callbackName);
                            return;
                        }

                        TBUserList resultMsg = new TBUserList();

                        //JSONArray messages = resource.getJSONArray("members");
                        resultMsg.setUserList(resource);

                        notifyNetworkResult(resultMsg, callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "get friends list return error.");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "get friends list return error."),
                                    callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(result
                                    .getJSONObject("error"));
                            TBLog.e(TAG, "get friends list return error:"
                                    + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(
                            new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get friends list is exception"
                                            + e.getMessage()), callbackName);
                }
            }
        }).start();
    }


}
