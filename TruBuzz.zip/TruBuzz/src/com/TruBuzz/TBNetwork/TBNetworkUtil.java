package com.TruBuzz.TBNetwork;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.TruBuzz.TBCommon.TBLog;

/**
 * 网络连接工具类
 * @author jhnie
 *
 */
public class TBNetworkUtil {
	
	private static String TAG = "networkUtils";
	
	/**
	 * 当前是否正在使用wap连接网络
	 * @return
	 */
	public static boolean isUsingCmwap(Context context){
         if(getAccessPoint(context)==4) {
        	 return true;
         }else {
        	 return false;
         }
	}
	
	/**
	 * 获取网络接入点,0,=unknown(未知)，1=gprs，2=3g，3=wifi,4 wap
	 */
	public static int getAccessPoint(Context context) {
		try {
			ConnectivityManager cwjManager = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
			
			NetworkInfo info = cwjManager.getActiveNetworkInfo();
			if(info!=null) {
				int type=info.getType();
				if(type==1) {
					//WIFI
					return 3;
				}else if(type==0) {
					//MOBILE
					String typeName=info.getTypeName();
					if(typeName.contains("cmwap")||typeName.contains("CMWAP")) {
						return 4;//cmwap
					}
					return 1;
				}else {
					TBLog.e(TAG, "getAccessPoint netName:"+info.getTypeName()+"Type:"+type);
					return 0;
				}
			}else {
			    TBLog.d(TAG, "Can't connect to internect!");
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			TBLog.e(TAG, "When get the accessPoint error:"+e.toString());
		}
		return 0;
	}
	
	/**
	 * 当前是否可以连接到互联网
	 * @return
	 */
	public static boolean isConnectingInternet(Context context){
		if(getAccessPoint(context)>0) {
			return true;
		}else {
			return false;
		}
	}
	
}
