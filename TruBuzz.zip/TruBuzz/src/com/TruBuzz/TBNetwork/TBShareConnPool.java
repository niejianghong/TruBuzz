package com.TruBuzz.TBNetwork;

import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import com.TruBuzz.Activity.ComposeShareActivity;
import com.TruBuzz.TBBeans.TBMessage;
import com.TruBuzz.TBBeans.TBSharedMessage;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;

/**
 * 连接请求池，所有Share相关的通信全部写在这里
 * 
 * @author jhnie
 * 
 */
public class TBShareConnPool extends TBConnection {
    private static String TAG = "TBShareConnPool";

    public static void shareMessage(final TBMessage msg, final String comment,
            final int type, final String account, final String circleName,
            final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    TBMessage ret = msg;
                    ret.resetStatus();
                    List<NameValuePair> params = getParamKeyValue();
                    params.add(new BasicNameValuePair(TBConstDef.SHARE_MSG_ID,
                            ret.id + ""));
                    params.add(new BasicNameValuePair(TBConstDef.SHARE_TYPE,
                            type + ""));
                    params.add(new BasicNameValuePair(TBConstDef.SHARE_COMMENT,
                            comment));
                    if (ComposeShareActivity.SHARE_TO_FRIENDS == type) {
                        params.add(new BasicNameValuePair(
                                TBConstDef.SHARE_ACCOUNT, account));
                    }
                    if (ComposeShareActivity.SHARE_TO_CIRCLE == type) {
                        params.add(new BasicNameValuePair(
                                TBConstDef.SHARE_CIRCLE_ID, circleName + ""));
                    }

                    JSONObject result = TBConnection.sendHttpPostRequest(
                            TBConstDef.POST_SHARE_MSG, params);
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        if (result.has("error")) {
                            try {
                                ret.errorCode = Integer.valueOf(result
                                        .getJSONObject("error").getInt(
                                                "error_code"));
                                ret.errorMsg = result.getJSONObject("error")
                                        .getString("error_message");
                            } catch (Exception e) {

                            }
                        }
                        notifyNetworkResult(ret, callbackName);

                    } else {
                        if (null == result) {
                            ret.errorCode = TBNetworkResult.ERROR;
                            ret.errorMsg = "post share message return error.";
                            TBLog.e(TAG,
                                    "post share message return error error.");
                            notifyNetworkResult(ret, callbackName);
                        } else {
                            try {
                                ret.errorCode = Integer.valueOf(result
                                        .getJSONObject("error").getInt(
                                                "error_code"));
                                ret.errorMsg = result.getJSONObject("error")
                                        .getString("error_message");
                            } catch (Exception e) {

                            }
                            TBLog.e(TAG, "post share message return error:"
                                    + ret.errorMsg);
                            notifyNetworkResult(ret, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    TBMessage ret = msg;
                    ret.resetStatus();
                    ret.errorCode = TBNetworkResult.ERROR;
                    ret.errorMsg = e.getMessage();
                    notifyNetworkResult(ret, callbackName);
                }
            }
        }).start();
    }

    public static void getShareMessage(final TBMessage msg, final long shareMsgId,
            final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = TBConnection.sendHttpGetRequest(String
                            .format(TBConstDef.GET_SHARE_MSG, msg.id, shareMsgId)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get shared message is null");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "get shared message is null"), callbackName);
                            return;
                        }

                        TBSharedMessage msgResult = new TBSharedMessage(
                                resource);
                        msg.sharedMsg = msgResult;
                        notifyNetworkResult(msg, callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "get message return error.");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "get message return error."), callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(result
                                    .getJSONObject("error"));
                            TBLog.e(TAG, "get message return error:"
                                    + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(
                            new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get msg is exception" + e.getMessage()),
                            callbackName);
                }
            }
        }).start();
    }

}
