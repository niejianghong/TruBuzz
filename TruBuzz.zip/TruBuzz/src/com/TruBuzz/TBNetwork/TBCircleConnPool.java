package com.TruBuzz.TBNetwork;

import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.TruBuzz.TBBeans.TBCircleList;
import com.TruBuzz.TBBeans.TBMessageList;
import com.TruBuzz.TBBeans.TBUserList;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;

/**
 * 连接请求池，所有Circle相关的通信全部写在这里
 * 
 * @author jhnie
 * 
 */
public class TBCircleConnPool extends TBConnection {
    private static String TAG = "TBCircleConnPool";

    public static void postCircle(final String circleId,
            final String msgContent, final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();
                    params.add(new BasicNameValuePair(TBConstDef.MSG_CONTET,
                            msgContent));

                    JSONObject result = TBConnection.sendHttpPostRequest(
                            String.format(TBConstDef.GET_POST_CIRCLE, circleId),
                            params);
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        notifyNetworkResult(new TBNetworkResult(
                                TBNetworkResult.SUCCESS,
                                "post circle success: " + msgContent),
                                callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "post circle return error.");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "post circle return error."), callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(result
                                    .getJSONObject("error"));
                            TBLog.e(TAG, "post circle return error:"
                                    + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(
                            TBNetworkResult.ERROR, "post circle is exception"
                                    + e.getMessage()), callbackName);
                }
            }
        }).start();
    }

    public static void getCircle(final String circleId, final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = TBConnection.sendHttpGetRequest(String
                            .format(TBConstDef.GET_POST_CIRCLE, circleId)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get circle is null");
                            notifyNetworkResult(
                                    new TBNetworkResult(TBNetworkResult.ERROR,
                                            "get circle is null"), callbackName);
                            return;
                        }

                        TBMessageList resultMsg = new TBMessageList();
                        resultMsg.minimumMessageId = resource
                                .getLong("minimumMessageId");
                        resultMsg.newestMessageId = resource
                                .getLong("newestMessageId");
                        resultMsg.oldestMessageId = resource
                                .getLong("oldestMessageId");

                        JSONArray messages = resource.getJSONArray("messages");
                        resultMsg.setMsgList(messages);

                        notifyNetworkResult(resultMsg, callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "get circle return error.");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "get circle return error."), callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(result
                                    .getJSONObject("error"));
                            TBLog.e(TAG, "get circle return error:"
                                    + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(
                            TBNetworkResult.ERROR, "get circle is exception"
                                    + e.getMessage()), callbackName);
                }
            }
        }).start();
    }

    public static void getNewestMsg(final String id, final long newestMsgId,
            final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();
                    JSONObject result = TBConnection.sendHttpGetRequest(String
                            .format(TBConstDef.GET_NEWEST_CIRCLE, id,
                                    newestMsgId)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get newest circle is null");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "get newest circle is null"), callbackName);
                            return;
                        }

                        TBMessageList resultMsg = new TBMessageList();
                        resultMsg.newestMessageId = resource
                                .getLong("newestMessageId");

                        JSONArray messages = resource.getJSONArray("messages");
                        resultMsg.setMsgList(messages);

                        notifyNetworkResult(resultMsg, callbackName);

                    } else {
                        notifyNetworkResult(
                                new TBNetworkResult(TBNetworkResult.ERROR,
                                        "no centent to refresh"), callbackName);
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(
                            TBNetworkResult.ERROR,
                            "get newest circle is exception" + e.getMessage()),
                            callbackName);
                }
            }
        }).start();
    }

    public static void getOldestMsg(final String id, final long oldestMsgId,
            final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = TBConnection.sendHttpGetRequest(String
                            .format(TBConstDef.GET_OLDEST_CIRCLE, id,
                                    oldestMsgId)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get oldest circle is null");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "get oldest circle is null"), callbackName);
                            return;
                        }

                        TBMessageList resultMsg = new TBMessageList();
                        resultMsg.oldestMessageId = resource
                                .getLong("oldestMessageId");

                        JSONArray messages = resource.getJSONArray("messages");
                        resultMsg.setMsgList(messages);

                        notifyNetworkResult(resultMsg, callbackName);

                    } else {
                        notifyNetworkResult(
                                new TBNetworkResult(TBNetworkResult.ERROR,
                                        "no centent to refresh"), callbackName);
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(
                            TBNetworkResult.ERROR,
                            "get oldest circle is exception" + e.getMessage()),
                            callbackName);
                }
            }
        }).start();
    }

    public static void getCircleList(final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = TBConnection.sendHttpGetRequest(String
                            .format(TBConstDef.GET_CIRCLE_LIST)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get circle list is null");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "get circle list resourceis null"),
                                    callbackName);
                            return;
                        }

                        TBCircleList resultMsg = new TBCircleList();
                        JSONArray circles = resource.getJSONArray("cricles");
                        if (null == circles) {
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "get circle list is null"), callbackName);
                            return;
                        }
                        resultMsg.setCircleList(circles);
                        notifyNetworkResult(resultMsg, callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "get circle list return error.");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "get circle list return error."),
                                    callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(
                                    result.getJSONObject("error"));
                            TBLog.e(TAG, "get circle list return error:"
                                    + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(
                            TBNetworkResult.ERROR,
                            "get circle list is exception" + e.getMessage()),
                            callbackName);
                }
            }
        }).start();
    }

    public static void getCircleMembers(final long circleId,
            final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = TBConnection.sendHttpGetRequest(String
                            .format(TBConstDef.GET_CIRCLE_MEMBERS, circleId)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get circle members is null");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "get circle members is null"), callbackName);
                            return;
                        }

                        TBUserList resultMsg = new TBUserList();

                        JSONArray messages = resource.getJSONArray("members");
                        resultMsg.setUserList(messages);

                        notifyNetworkResult(resultMsg, callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "get circle members return error.");
                            notifyNetworkResult(new TBNetworkResult(
                                    TBNetworkResult.ERROR,
                                    "get circle members return error."),
                                    callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(result
                                    .getJSONObject("error"));
                            TBLog.e(TAG, "get circle members return error:"
                                    + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(
                            new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get circle members is exception"
                                            + e.getMessage()), callbackName);
                }
            }
        }).start();
    }
}
