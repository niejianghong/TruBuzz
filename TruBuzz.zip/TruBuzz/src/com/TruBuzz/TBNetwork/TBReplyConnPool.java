package com.TruBuzz.TBNetwork;

import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.TruBuzz.TBBeans.TBMessage;
import com.TruBuzz.TBBeans.TBReplyMessage;
import com.TruBuzz.TBBeans.TBReplyMessageList;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;

/**
 * 连接请求池，所有Reply相关的通信全部写在这里
 * 
 * @author jhnie
 * 
 */
public class TBReplyConnPool extends TBConnection {
    private static String TAG = "TBReplyConnPool";

    public static void postReplyMessage(final long msgId,
            final String msgContent, final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();
                    params.add(new BasicNameValuePair(TBConstDef.MSG_CONTET,
                            msgContent));

                    JSONObject result = TBConnection.sendHttpPostRequest(
                            String.format(TBConstDef.POST_GET_REPLY_MSG, msgId),
                            params);
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "post reply message return is null");
                            notifyNetworkResult(
                                    new TBNetworkResult(
                                            TBNetworkResult.ERROR,
                                            String.format(
                                                    "post reply message success: %s, msgId:%l",
                                                    msgContent, msgId)),
                                    callbackName);
                            return;
                        }

                        notifyNetworkResult(new TBNetworkResult(
                                TBNetworkResult.SUCCESS,
                                "post reply message success: " + msgContent),
                                callbackName);

                        // TBGetReplyMessageResult msgResult = new
                        // TBGetReplyMessageResult();
                        // msgResult.totalReplies =
                        // resource.getInt("totalReplies");
                        // msgResult.messageId = resource.getInt("messageId");
                        //
                        // notifyNetworkResult(msgResult, callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "post reply message return error.");
                            notifyNetworkResult(
                                    new TBNetworkResult(
                                            TBNetworkResult.ERROR,
                                            String.format(
                                                    "post reply message error: %s, msgId:%l",
                                                    msgContent, msgId)),
                                    callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(result
                                    .getJSONObject("error"));
                            TBLog.e(TAG, "post reply message return error:"
                                    + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(
                            TBNetworkResult.ERROR,
                            "post reply msg is exception" + e.getMessage()),
                            callbackName);
                }
            }
        }).start();
    }

    public static void getReplyMessageList(final long msgId,
            final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = TBConnection.sendHttpGetRequest(String
                            .format(TBConstDef.POST_GET_REPLY_MSG, msgId)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get reply message return is null");
                            notifyNetworkResult(
                                    new TBNetworkResult(
                                            TBNetworkResult.ERROR,
                                            String.format(
                                                    "get reply message success, msgId:%l",
                                                    msgId)), callbackName);
                            return;
                        }

                        TBReplyMessageList msgResult = new TBReplyMessageList();
                        msgResult.totalReplies = resource
                                .getInt("totalReplies");
                        msgResult.newestReplyId = resource
                                .getInt("newestReplyId");
                        msgResult.oldestReplyId = resource
                                .getInt("oldestReplyId");
                        msgResult.messageId = resource.getInt("messageId");
                        msgResult.minimumReplyId = resource
                                .getInt("minimumReplyId");

                        JSONArray replies = resource.getJSONArray("replies");
                        msgResult.setReplyMsgList(replies);

                        notifyNetworkResult(msgResult, callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "get reply message return error.");
                            notifyNetworkResult(
                                    new TBNetworkResult(
                                            TBNetworkResult.ERROR,
                                            String.format(
                                                    "get reply message error, msgId:%d",
                                                    msgId)), callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(result
                                    .getJSONObject("error"));
                            TBLog.e(TAG, "get reply message return error:"
                                    + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(
                            TBNetworkResult.ERROR, "get reply msg is exception"
                                    + e.getMessage()), callbackName);
                }
            }
        }).start();
    }

    public static void getOldestReplyMessage(final long msgId,
            final long oldestMsgId, final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = TBConnection.sendHttpGetRequest(String
                            .format(TBConstDef.GET_OLDEST_REPLY_MSG, msgId,
                                    oldestMsgId)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG,
                                    "get oldest reply message return is null");
                            notifyNetworkResult(
                                    new TBNetworkResult(
                                            TBNetworkResult.ERROR,
                                            String.format(
                                                    "get oldest reply message success: msgId:%l, oldestMsgId: %d",
                                                    msgId, oldestMsgId)),
                                    callbackName);
                            return;
                        }

                        TBReplyMessageList msgResult = new TBReplyMessageList();
                        msgResult.totalReplies = resource
                                .getInt("totalReplies");
                        msgResult.newestReplyId = resource
                                .getInt("newestReplyId");
                        msgResult.messageId = resource.getInt("messageId");

                        JSONArray replies = resource.getJSONArray("replies");
                        msgResult.setReplyMsgList(replies);

                        notifyNetworkResult(msgResult, callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG,
                                    "get oldest reply message return error.");
                            notifyNetworkResult(
                                    new TBNetworkResult(
                                            TBNetworkResult.ERROR,
                                            String.format(
                                                    "get oldest reply message error, msgId:%l, oldMsgId: %d",
                                                    msgId, oldestMsgId)),
                                    callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(result
                                    .getJSONObject("error"));
                            TBLog.e(TAG,
                                    "get oldest reply message return error:"
                                            + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(
                            new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get oldest reply msg is exception"
                                            + e.getMessage()), callbackName);
                }
            }
        }).start();
    }

    public static void getNewestReplyMessage(final long msgId,
            final long newestMsgId, final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = TBConnection.sendHttpGetRequest(String
                            .format(TBConstDef.GET_NEWEST_REPLY_MSG, msgId,
                                    newestMsgId)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG,
                                    "get newest reply message return is null");
                            notifyNetworkResult(
                                    new TBNetworkResult(
                                            TBNetworkResult.ERROR,
                                            String.format(
                                                    "get newest reply message success: msgId:%l, newestMsgId: %d",
                                                    msgId, newestMsgId)),
                                    callbackName);
                            return;
                        }

                        TBReplyMessageList msgResult = new TBReplyMessageList();
                        msgResult.oldestReplyId = resource
                                .getInt("oldestReplyId");
                        msgResult.messageId = resource.getInt("messageId");

                        JSONArray replies = resource.getJSONArray("replies");
                        msgResult.setReplyMsgList(replies);

                        notifyNetworkResult(msgResult, callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG,
                                    "get newest reply message return error.");
                            notifyNetworkResult(
                                    new TBNetworkResult(
                                            TBNetworkResult.ERROR,
                                            String.format(
                                                    "get newest reply message error, msgId:%l, newestMsgId: %d",
                                                    msgId, newestMsgId)),
                                    callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(result
                                    .getJSONObject("error"));
                            TBLog.e(TAG,
                                    "get newest reply message return error:"
                                            + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(
                            new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get newest reply msg is exception"
                                            + e.getMessage()), callbackName);
                }
            }
        }).start();
    }

    public static void deleteReplyMsg(final TBReplyMessage replyMsg,
            final String callbackName) {

        new Thread(new Runnable() {

            @Override
            public void run() {
                try {

                    List<NameValuePair> params = getParamKeyValue();
                    TBReplyMessage ret = replyMsg;

                    JSONObject result = TBConnection
                            .sendHttpDeleteRequest(String.format(
                                    TBConstDef.DELETE_REPLY_MSG, ret.id)
                                    + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        if (result.has("error")) {
                            try {
                                ret.errorCode = Integer.valueOf(result
                                        .getJSONObject("error").getInt(
                                                "error_code"));
                                ret.errorMsg = result.getJSONObject("error")
                                        .getString("error_message");
                            } catch (Exception e) {

                            }
                        }
                        notifyNetworkResult(ret, callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG,
                                    "delete reply msg from server return error.");
                            ret.errorCode = TBNetworkResult.ERROR;
                            ret.errorMsg = "delete msg from server return error.";
                            notifyNetworkResult(ret, callbackName);
                        } else {
                            try {
                                ret.errorCode = Integer.valueOf(result
                                        .getJSONObject("error").getInt(
                                                "error_code"));
                                ret.errorMsg = result.getJSONObject("error")
                                        .getString("error_message");
                            } catch (Exception e) {

                            }
                            notifyNetworkResult(ret, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    TBReplyMessage ret = replyMsg;
                    ret.errorCode = TBNetworkResult.ERROR;
                    ret.errorMsg = e.getMessage();
                    notifyNetworkResult(ret, callbackName);
                }
            }
        }).start();
    }

    public static void postBuzzReplyMessage(final TBMessage msg,
            final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();
                    TBMessage ret = msg;
                    ret.resetStatus();
                    JSONObject result = TBConnection.sendHttpPostRequest(
                            String.format(TBConstDef.BUZZ_REPLY_MSG, msg.id),
                            params);
                    if (null != result
                            && "200".equalsIgnoreCase(result
                                    .getString("status"))) {
                        if (result.has("error")) {
                            try {
                                ret.errorCode = Integer.valueOf(result
                                        .getJSONObject("error").getInt(
                                                "error_code"));
                                ret.errorMsg = result.getJSONObject("error")
                                        .getString("error_message");
                            } catch (Exception e) {

                            }
                        }

                        notifyNetworkResult(msg, callbackName);

                    } else {
                        if (null == result) {
                            ret.errorCode = TBNetworkResult.ERROR;
                            ret.errorMsg = "net exception.";
                            TBLog.e(TAG, "buzz reply message return error.");
                            notifyNetworkResult(ret, callbackName);
                        } else {
                            try {
                                ret.errorCode = Integer.valueOf(result
                                        .getJSONObject("error").getInt(
                                                "error_code"));
                                ret.errorMsg = result.getJSONObject("error")
                                        .getString("error_message");
                            } catch (Exception e) {

                            }
                            TBLog.e(TAG, "buzz reply message return error:"
                                    + ret.errorMsg);
                            notifyNetworkResult(ret, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    TBMessage ret = msg;
                    ret.resetStatus();
                    ret.errorCode = TBNetworkResult.ERROR;
                    ret.errorMsg = e.getMessage();
                    notifyNetworkResult(ret, callbackName);
                }
            }
        }).start();
    }

}
