package com.TruBuzz.TBNetwork;

import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.TruBuzz.TBBeans.TBNoticeList;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;

/**
 * 连接请求池，所有Notice相关的通信全部写在这里
 * 
 * @author jhnie
 * 
 */
public class TBNoticeConnPool extends TBConnection {
    private static String TAG = "TBNoticeConnPool";

    public static void getNotice(final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = TBConnection.sendHttpGetRequest(TBConstDef.GET_NOTICE
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result && "200".equalsIgnoreCase(result.getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get notice is null");
                            notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get notice is null"), callbackName);
                            return;
                        }

                        TBNoticeList noticeList = new TBNoticeList();
                        noticeList.minimumNoticeId = resource.getLong("minimumNoticeId");
                        noticeList.newestNoticeId = resource.getLong("newestNoticeId");
                        noticeList.oldestNoticeId = resource.getLong("oldestNoticeId");
                        noticeList.unread_num = resource.getInt("unread_num");

                        JSONArray notices = resource.getJSONArray("notices");
                        noticeList.setNoticeList(notices);

                        notifyNetworkResult(noticeList, callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "get notice return error.");
                            notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get notice return error."), callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(
                                    result.getJSONObject("error"));
                            TBLog.e(TAG, "get notice return error:" + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                            "get notice is exception" + e.getMessage()), callbackName);
                }
            }
        }).start();
    }

    public static void getNewestNotice(final long newestId, final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();
                    JSONObject result = TBConnection.sendHttpGetRequest(String.format(
                            TBConstDef.GET_NEWEST_NOTICE, newestId)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result && "200".equalsIgnoreCase(result.getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get newest notice is null");
                            notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get newest notice is null"), callbackName);
                            return;
                        }

                        TBNoticeList noticeList = new TBNoticeList();
                        noticeList.newestNoticeId = resource.getLong("newestNoticeId");
     

                        JSONArray notices = resource.getJSONArray("notices");
                        noticeList.setNoticeList(notices);

                        notifyNetworkResult(noticeList, callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "get newest notice return error.");
                            notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get newest notice return error."), callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(
                                    result.getJSONObject("error"));
                            TBLog.e(TAG, "get newest notice return error:" + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                            "get newest notice is exception" + e.getMessage()), callbackName);
                }
            }
        }).start();
    }

    public static void getOldestNotice(final long oldestId, final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = TBConnection.sendHttpGetRequest(String.format(
                            TBConstDef.GET_OLDEST_NOTICE, oldestId)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result && "200".equalsIgnoreCase(result.getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get oldest notice is null");
                            notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get oldest notice is null"), callbackName);
                            return;
                        }

                        TBNoticeList noticeList = new TBNoticeList();
                        noticeList.oldestNoticeId = resource.getLong("oldestNoticeId");

                        JSONArray notices = resource.getJSONArray("notices");
                        noticeList.setNoticeList(notices);

                        notifyNetworkResult(noticeList, callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "get oldest notice return error.");
                            notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get oldest notice return error."), callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(
                                    result.getJSONObject("error"));
                            TBLog.e(TAG, "get oldest notice return error:" + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                            "get oldest notice is exception" + e.getMessage()), callbackName);
                }
            }
        }).start();
    }

    public static void setNoticeRead(final long noticeId, final String callbackName) {

        new Thread(new Runnable() {

            @Override
            public void run() {
                try {

                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = TBConnection.sendHttpGetRequest(String.format(
                            TBConstDef.SET_NOTICE_READ, noticeId)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result && "200".equalsIgnoreCase(result.getString("status"))) {
                        TBLog.e(TAG, "set notice read from server success.");
                        notifyNetworkResult(new TBNetworkResult(TBNetworkResult.SUCCESS,
                                "set notice read from server success."), callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "set notice read from server return error.");
                            notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                                    "set notice read from server return error."), callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(
                                    result.getJSONObject("error"));
                            TBLog.e(TAG, "set notice read from server return error: " + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                            "set notice read is exception" + e.getMessage()), callbackName);
                }
            }
        }).start();
    }
    
    public static void deleteNotice(final long noticeId, final String callbackName) {

        new Thread(new Runnable() {

            @Override
            public void run() {
                try {

                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = TBConnection.sendHttpDeleteRequest(String.format(
                            TBConstDef.DELETE_NOTICE, noticeId)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result && "200".equalsIgnoreCase(result.getString("status"))) {
                        TBLog.e(TAG, "delete notice from server success.");
                        notifyNetworkResult(new TBNetworkResult(TBNetworkResult.SUCCESS,
                                "delete notice from server success."), callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "delete notice from server return error.");
                            notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                                    "delete notice from server return error."), callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(
                                    result.getJSONObject("error"));
                            TBLog.e(TAG, "delete notice from server return error: " + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                            "delete notice is exception" + e.getMessage()), callbackName);
                }
            }
        }).start();
    }
 
}
