package com.TruBuzz.TBNetwork;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.conn.params.ConnRouteParams;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.json.JSONTokener;

import android.content.Intent;

import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;
import com.TruBuzz.TruBuzz.TBApplication;

/**
 * 基础通信类，负责向服务器提交http请求
 * @author jhnie
 *
 */
public class TBConnection {
	private static String TAG = "TBConnection";
	public static int NETWORK_TIMEOUT = 5;
	
    protected static List<NameValuePair> getParamKeyValue() {
        List<NameValuePair> keyValue = new ArrayList<NameValuePair>();
        try {
            keyValue.add(new BasicNameValuePair(TBConstDef.AUTH_KEY, TBApplication.session_key));
        } catch (Exception e) {
            TBLog.e(TAG, e.toString());
        }
        return keyValue;
    }

    protected static void notifyNetworkResult(TBNetworkResult result, String callbackName) {

        Intent intent = new Intent();
        intent.setAction(callbackName);
        intent.putExtra(TBConstDef.NET_RESULT, result);
        TBApplication.mGlobalContext.sendBroadcast(intent);

    }
	 /**
     * 向服务器发送Get请求
     */
    protected static  JSONObject sendHttpGetRequest(String url) {
        
        try {
            HttpGet httpGet = new HttpGet(url);
            TBLog.e(TAG, "post get request: " + url);

            HttpClient httpClient = new DefaultHttpClient();
            httpClient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT,
                    NETWORK_TIMEOUT * 1000);
            httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,
                    NETWORK_TIMEOUT * 1000);
            
            if (TBNetworkUtil.isUsingCmwap(TBApplication.mGlobalContext)){
                String host = android.net.Proxy.getDefaultHost();
                int port = android.net.Proxy.getDefaultPort();
                SocketAddress sa = new InetSocketAddress(host, port);
                Proxy proxy = new Proxy(java.net.Proxy.Type.HTTP, sa);
                httpClient.getParams().setParameter(ConnRouteParams.DEFAULT_PROXY, proxy);
            }

            HttpResponse httpResp = httpClient.execute(httpGet);

            if (httpResp.getStatusLine().getStatusCode() != 200) {
                TBLog.e(TAG, "get request reuslt form server error: "
                        + httpResp.getStatusLine().getStatusCode());
            }

            String resultStr = EntityUtils.toString(httpResp.getEntity(), HTTP.UTF_8);
            TBLog.e(TAG, "get request reuslt from server: " + resultStr);

            JSONTokener jsonParser = new JSONTokener(resultStr);
            JSONObject jsonResult = (JSONObject) jsonParser.nextValue();

            return jsonResult;
        }catch(Exception e){
        	TBLog.e(TAG, e.getMessage());
            return null;
        }
            
    }
    
    /**
    * 向服务器发送POST请求
    */
    protected static JSONObject sendHttpPostRequest(String url, List<NameValuePair> params) {
       
       try {
           HttpPost httpPost = new HttpPost(url);
           httpPost.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));
           TBLog.e(TAG, "post request: " + params.toString());
           
           HttpClient httpClient = new DefaultHttpClient();
           httpClient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT,
                   NETWORK_TIMEOUT * 1000);
           httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,
                   NETWORK_TIMEOUT * 1000);

           if (TBNetworkUtil.isUsingCmwap(TBApplication.mGlobalContext)) {

               String host = android.net.Proxy.getDefaultHost();
               int port = android.net.Proxy.getDefaultPort();
               SocketAddress sa = new InetSocketAddress(host, port);
               Proxy proxy = new Proxy(java.net.Proxy.Type.HTTP, sa);
               httpClient.getParams().setParameter(ConnRouteParams.DEFAULT_PROXY, proxy);
           }

           HttpResponse httpResp = httpClient.execute(httpPost);

           if (httpResp.getStatusLine().getStatusCode() != 200) {
               TBLog.e(TAG, "post request reuslt form server error: "
                       + httpResp.getStatusLine().getStatusCode());
           }

           String resultStr = EntityUtils.toString(httpResp.getEntity(), HTTP.UTF_8);
           TBLog.e(TAG, "post request reuslt form server: " + resultStr);

           JSONTokener jsonParser = new JSONTokener(resultStr);
           JSONObject jsonResult = (JSONObject) jsonParser.nextValue();
           
           return jsonResult;
       }catch(Exception e){
    	   TBLog.e(TAG, e.getMessage());
           return null;
       }     
   }
    /**
    * 向服务器发送Put请求
    */
    protected static JSONObject sendHttpPutRequest(String url, List<NameValuePair> params) {
       
       try {
           HttpPut httpPut = new HttpPut(url);
           httpPut.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));
           TBLog.e(TAG, "put request: " + params.toString());
           
           HttpClient httpClient = new DefaultHttpClient();
           httpClient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT,
                   NETWORK_TIMEOUT * 1000);
           httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,
                   NETWORK_TIMEOUT * 1000);

           if (TBNetworkUtil.isUsingCmwap(TBApplication.mGlobalContext)) {

               String host = android.net.Proxy.getDefaultHost();
               int port = android.net.Proxy.getDefaultPort();
               SocketAddress sa = new InetSocketAddress(host, port);
               Proxy proxy = new Proxy(java.net.Proxy.Type.HTTP, sa);
               httpClient.getParams().setParameter(ConnRouteParams.DEFAULT_PROXY, proxy);
           }

           HttpResponse httpResp = httpClient.execute(httpPut);

           if (httpResp.getStatusLine().getStatusCode() != 200) {
               TBLog.e(TAG, "put request reuslt form server error: "
                       + httpResp.getStatusLine().getStatusCode());
           }

           String resultStr = EntityUtils.toString(httpResp.getEntity(), HTTP.UTF_8);
           TBLog.e(TAG, "put request reuslt form server: " + resultStr);

           JSONTokener jsonParser = new JSONTokener(resultStr);
           JSONObject jsonResult = (JSONObject) jsonParser.nextValue();
           
           return jsonResult;
       }catch(Exception e){
           TBLog.e(TAG, e.getMessage());
           return null;
       }     
   }
   
   /**
   * 向服务器发送Delete请求
   */
  protected static JSONObject sendHttpDeleteRequest(String url) {
      try {
          HttpDelete httpDelete = new HttpDelete(url);
          
          HttpClient httpClient = new DefaultHttpClient();
          httpClient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT,
                  NETWORK_TIMEOUT * 1000);
          httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,
                  NETWORK_TIMEOUT * 1000);
          
          if (TBNetworkUtil.isUsingCmwap(TBApplication.mGlobalContext)){
              String host = android.net.Proxy.getDefaultHost();
              int port = android.net.Proxy.getDefaultPort();
              SocketAddress sa = new InetSocketAddress(host, port);
              Proxy proxy = new Proxy(java.net.Proxy.Type.HTTP, sa);
              httpClient.getParams().setParameter(ConnRouteParams.DEFAULT_PROXY, proxy);
          }

          HttpResponse httpResp = httpClient.execute(httpDelete);

          if (httpResp.getStatusLine().getStatusCode() != 200) {
              TBLog.e(TAG, "delete request reuslt from server error: "
                      + httpResp.getStatusLine().getStatusCode());
              return null;
          }

          String resultStr = EntityUtils.toString(httpResp.getEntity(), HTTP.UTF_8);
          
          JSONTokener jsonParser = new JSONTokener(resultStr);
          JSONObject jsonResult = (JSONObject) jsonParser.nextValue();

          return jsonResult;
      }catch(Exception e){
    	  TBLog.e(TAG, e.getMessage());
          return null;
      }
          
  }
}
