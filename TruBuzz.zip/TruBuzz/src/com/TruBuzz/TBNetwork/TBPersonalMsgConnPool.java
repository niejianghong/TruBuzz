package com.TruBuzz.TBNetwork;

import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.TruBuzz.TBBeans.TBMessageList;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;

/**
 * 连接请求池，所有PersonalMessage相关的通信全部写在这里
 * 
 * @author jhnie
 * 
 */
public class TBPersonalMsgConnPool extends TBConnection {
    private static String TAG = "TBPersonalMsgConnPool";

    public static void getPersonalMessage(final int userId, final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = TBConnection.sendHttpGetRequest(String.format(TBConstDef.GET_PERSONAL_MSG_LIST, userId)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result && "200".equalsIgnoreCase(result.getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get personal message is null");
                            notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get personal message is null"), callbackName);
                            return;
                        }

                        TBMessageList resultMsg = new TBMessageList();
                        resultMsg.minimumMessageId = resource.getLong("minimumMessageId");
                        resultMsg.newestMessageId = resource.getLong("newestMessageId");
                        resultMsg.oldestMessageId = resource.getLong("oldestMessageId");

                        JSONArray messages = resource.getJSONArray("messages");
                        resultMsg.setMsgList(messages);

                        notifyNetworkResult(resultMsg, callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "get personal message return error.");
                            notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get personal message return error."), callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(
                                    result.getJSONObject("error"));
                            TBLog.e(TAG, "get personal message return error:" + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                            "get personal msg is exception" + e.getMessage()), callbackName);
                }
            }
        }).start();
    }

    public static void getPersonalNewestMsg(final long userId, final long newestMsgId, final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();
                    JSONObject result = TBConnection.sendHttpGetRequest(String.format(
                            TBConstDef.GET_NEWEST_PERSONAL_MSG, userId, newestMsgId)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result && "200".equalsIgnoreCase(result.getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get newest personal msg is null");
                            notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get newest personal msg is null"), callbackName);
                            return;
                        }

                        TBMessageList resultMsg = new TBMessageList();
                        resultMsg.newestMessageId = resource.getLong("newestMessageId");

                        JSONArray messages = resource.getJSONArray("messages");
                        resultMsg.setMsgList(messages);

                        notifyNetworkResult(resultMsg, callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "get newest personal msg return error.");
                            notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get newest personal msg return error."), callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(
                                    result.getJSONObject("error"));
                            TBLog.e(TAG, "get newest personal msg return error:" + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                            "get newest personal msg is exception" + e.getMessage()), callbackName);
                }
            }
        }).start();
    }

    public static void getOldestMsg(final long userId, final long oldestMsgId, final String callbackName) {
        new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    List<NameValuePair> params = getParamKeyValue();

                    JSONObject result = TBConnection.sendHttpGetRequest(String.format(
                            TBConstDef.GET_OLDEST_PERSONAL_MSG, userId, oldestMsgId)
                            + URLEncodedUtils.format(params, "UTF-8"));
                    if (null != result && "200".equalsIgnoreCase(result.getString("status"))) {
                        JSONObject resource = result.getJSONObject("resource");
                        if (null == resource) {
                            TBLog.e(TAG, "get oldest personal msg is null");
                            notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get oldest personal msg is null"), callbackName);
                            return;
                        }

                        TBMessageList resultMsg = new TBMessageList();
                        resultMsg.oldestMessageId = resource.getLong("oldestMessageId");

                        JSONArray messages = resource.getJSONArray("messages");
                        resultMsg.setMsgList(messages);

                        notifyNetworkResult(resultMsg, callbackName);

                    } else {
                        if (null == result) {
                            TBLog.e(TAG, "get oldest personal msg return error.");
                            notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                                    "get oldest personal msg return error."), callbackName);
                        } else {
                            TBNetworkResult error = new TBNetworkResult(
                                    result.getJSONObject("error"));
                            TBLog.e(TAG, "get oldest personal msg return error:" + error.errorMsg);
                            notifyNetworkResult(error, callbackName);
                        }
                        return;
                    }

                } catch (JSONException e) {
                    TBLog.e(TAG, e.getMessage());
                    notifyNetworkResult(new TBNetworkResult(TBNetworkResult.ERROR,
                            "get oldest personal msg is exception" + e.getMessage()), callbackName);
                }
            }
        }).start();
    }
}
