package com.TruBuzz.TBDataBase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.TruBuzz.TBBeans.TBCircle;
import com.TruBuzz.TBBeans.TBCircleList;
import com.TruBuzz.TBBeans.TBUserInfo;
import com.TruBuzz.TBBeans.TBUserList;
import com.TruBuzz.TBCommon.TBLog;

public class TBDBUtils {
    private static final String TAG = "TBDBUtils";
    private static SQLiteDatabase mDataBase = null;
    private static TBDBUtils mInstance = null;

    private TBDBUtils(Context c) {
        if (mDataBase == null || !mDataBase.isOpen()) {
            TBDBHelper sqliteopenhelper = new TBDBHelper(c);
            mDataBase = sqliteopenhelper.getWritableDatabase();
        }
    }

    public static TBDBUtils getInstance(Context c) {
        if (null == mInstance) {
            mInstance = new TBDBUtils(c);
        }
        return mInstance;
    }

    public TBCircleList getCircleListFromDB() {

        Cursor cursor = null;
        TBCircleList resultMsg = new TBCircleList();
        try {
            cursor = mDataBase.rawQuery(
                    String.format("SELECT * FROM %s", TBDBHelper.CIRCLE_TAB),
                    null);
            if (null == cursor) {
                TBLog.e(TAG, "get circle from db error");
                return resultMsg;
            }
            if (!cursor.moveToFirst()) {
                TBLog.e(TAG, "get circle cursor move to first error");
                cursor.close();
                cursor = null;
                return resultMsg;
            }

            do {

                String name = cursor.getString(cursor
                        .getColumnIndex(TBDBHelper.CIRCLE_NAME));
                long id = cursor.getLong(cursor
                        .getColumnIndex(TBDBHelper.CIRCLE_ID));
                String type = cursor.getString(cursor
                        .getColumnIndex(TBDBHelper.CIRCLE_TYPE));
                TBCircle circle = new TBCircle(name, type, id);
                resultMsg.circleList.add(circle);
            } while (cursor.moveToNext());
        } catch (Exception e) {
            TBLog.e(TAG, e.toString());
        } finally {
            if (cursor != null) {
                cursor.close();
                cursor = null;
            }
        }
        return resultMsg;
    }

    public void insertCircleList2DB(TBCircleList info) {
        mDataBase.execSQL("DROP TABLE IF EXISTS circle_tab");
        mDataBase
                .execSQL("CREATE TABLE circle_tab (_id INTEGER PRIMARY KEY AUTOINCREMENT,circle_name NTEXT,circle_id LONG,circle_type)");
        for (int i = 0; i < info.circleList.size(); ++i) {

            ContentValues values = new ContentValues();
            TBCircle circle = info.circleList.get(i);

            values.put(TBDBHelper.CIRCLE_ID, circle.id);
            values.put(TBDBHelper.CIRCLE_NAME, circle.name);
            values.put(TBDBHelper.CIRCLE_TYPE, circle.type);
            mDataBase.insert(TBDBHelper.CIRCLE_TAB, null, values);
        }
    }

    public TBCircleList getStockListFromDB() {

        Cursor cursor = null;
        TBCircleList resultMsg = new TBCircleList();
        try {
            cursor = mDataBase.rawQuery(
                    String.format("SELECT * FROM %s", TBDBHelper.CIRCLE_TAB),
                    null);
            if (null == cursor) {
                TBLog.e(TAG, "get circle from db error");
                return resultMsg;
            }
            if (!cursor.moveToFirst()) {
                TBLog.e(TAG, "get circle cursor move to first error");
                cursor.close();
                cursor = null;
                return resultMsg;
            }

            do {

                String name = cursor.getString(cursor
                        .getColumnIndex(TBDBHelper.CIRCLE_NAME));
                long id = cursor.getLong(cursor
                        .getColumnIndex(TBDBHelper.CIRCLE_ID));
                String type = cursor.getString(cursor
                        .getColumnIndex(TBDBHelper.CIRCLE_TYPE));
                TBCircle circle = new TBCircle(name, type, id);
                resultMsg.circleList.add(circle);
            } while (cursor.moveToNext());
        } catch (Exception e) {
            TBLog.e(TAG, e.toString());
        } finally {
            if (cursor != null) {
                cursor.close();
                cursor = null;
            }
        }
        return resultMsg;
    }

    public void insertStockList2DB(TBCircleList info) {
        mDataBase.delete(TBDBHelper.CIRCLE_TAB, "_id = *", null);

        for (int i = 0; i < info.circleList.size(); ++i) {

            ContentValues values = new ContentValues();
            TBCircle circle = info.circleList.get(i);

            values.put(TBDBHelper.CIRCLE_ID, circle.id);
            values.put(TBDBHelper.CIRCLE_NAME, circle.name);
            values.put(TBDBHelper.CIRCLE_TYPE, circle.type);
            mDataBase.insert(TBDBHelper.CIRCLE_TAB, null, values);
        }
    }

    public void insertFriendList2DB(TBUserList list) {
        mDataBase.delete(TBDBHelper.FRIENDS_TAB, "_id = *", null);
        for (int i = 0; i < list.userList.size(); ++i) {

            ContentValues values = new ContentValues();
            TBUserInfo user = list.userList.get(i);

            values.put(TBDBHelper.USER_ID, user.id);
            values.put(TBDBHelper.URL, user.personal_url);
            values.put(TBDBHelper.ACCOUNT, user.account);
            values.put(TBDBHelper.NICK_NAME, user.nickname);
            values.put(TBDBHelper.EMAIL, user.email);
            values.put(TBDBHelper.AVATAR_URL, user.avatar);
            mDataBase.insert(TBDBHelper.FRIENDS_TAB, null, values);
        }
    }
    
    public Cursor getFriendListFromDB(){
        Cursor cursor = null;
        try {
            cursor = mDataBase.rawQuery(
                    String.format("SELECT * FROM %s", TBDBHelper.FRIENDS_TAB),
                    null);
            if (null == cursor) {
                TBLog.e(TAG, "get friends from db error");
                return cursor;
            }
            if (!cursor.moveToFirst()) {
                TBLog.e(TAG, "get friends cursor move to first error");
                cursor.close();
                cursor = null;
                return cursor;
            }

        } catch (Exception e) {
            TBLog.e(TAG, e.toString());
        }
        return cursor;
    }
}
