package com.TruBuzz.TBDataBase;
import com.TruBuzz.TBCommon.TBLog;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class TBDBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "trubuzz.db";
    private static final int DATABASE_VERSION = 1;
    public static final String ID = "_id";
    public static final String DEFAULT_SORT_ORDER = "id DESC";

    public static final String CIRCLE_TAB = "circle_tab";
    public static final String CIRCLE_NAME = "circle_name";
    public static final String CIRCLE_ID = "circle_id";
    public static final String CIRCLE_TYPE = "circle_type";
    
    public static final String FRIENDS_TAB = "friends_tab";
    public static final String USER_ID = "user_id";
    public static final String NICK_NAME = "nickname";
    public static final String ACCOUNT = "account";
    public static final String URL = "personal_url";
    public static final String EMAIL = "email";
    public static final String AVATAR = "avatar";
    public static final String AVATAR_URL = "avatar_url";
    
    public static final String STOCKRIVER_TAB = "stockriver_tab";
    public static final String STOCK_ID = "stock_id";
    public static final String STOCK_NAME = "stock_name";

    public TBDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqlitedatabase) {
        sqlitedatabase
        .execSQL("CREATE TABLE friends_tab (_id INTEGER PRIMARY KEY AUTOINCREMENT,user_id LONG,nickname NTEXT,account NTEXT,personal_url NTEXT,email NTEXT,avatar NTEXT, avatar_url NTEXT)");
        sqlitedatabase
                .execSQL("CREATE TABLE circle_tab (_id INTEGER PRIMARY KEY AUTOINCREMENT,circle_name NTEXT,circle_id LONG,circle_type)");
        sqlitedatabase
        .execSQL("CREATE TABLE stockriver_tab (_id INTEGER PRIMARY KEY AUTOINCREMENT,stock_id LONG,stock_name NTEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqlitedatabase, int oldVersion, int newVersion) {
        String s = (new StringBuilder("Upgrading database from version ")).append(oldVersion)
                .append(" to ").append(newVersion).append(", which will destroy all old data")
                .toString();
        TBLog.e("new TruBuzz DB", s);
        sqlitedatabase.execSQL("DROP TABLE IF EXISTS circle_tab");
        sqlitedatabase.execSQL("DROP TABLE IF EXISTS friends_tab");
        sqlitedatabase.execSQL("DROP TABLE IF EXISTS stockriver_tab");
        onCreate(sqlitedatabase);

    }

}