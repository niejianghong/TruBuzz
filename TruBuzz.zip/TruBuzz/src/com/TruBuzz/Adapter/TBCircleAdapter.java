package com.TruBuzz.Adapter;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.TruBuzz.TBBeans.TBCircle;
import com.TruBuzz.TBBeans.TBCircleList;
import com.TruBuzz.TruBuzz.R;

public class TBCircleAdapter extends BaseAdapter {

    private Activity mActivity = null;
    private TBCircleList circleList = null;
    private int listSize = -1;

    public TBCircleAdapter(Activity activity, TBCircleList circleList) {
        mActivity = activity;
        this.circleList = circleList;
        TBCircle publicWall = new TBCircle(
                mActivity.getString(R.string.public_wall), "public", 0);
        if (!this.circleList.circleList.contains(publicWall)) {
            this.circleList.circleList.add(publicWall);
        }

    }

    public TBCircleList getCircleList() {
        return circleList;
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        listSize = circleList.circleList.size();
        return circleList.circleList.size();
    }

    @Override
    public Object getItem(int arg0) {
        return circleList.circleList.get(listSize - arg0 - 1);
    }

    @Override
    public long getItemId(int arg0) {
        // TODO Auto-generated method stub
        return circleList.circleList.get(listSize - arg0 - 1).id;
    }

    public TBCircleList getSearchResult(String key) {
        TBCircleList result = new TBCircleList();
        for (int i = 0; i < circleList.circleList.size(); ++i) {
            TBCircle circle = circleList.circleList.get(i);
            if (circle.name.contains(key)) {
                TBCircle c = new TBCircle(circle);
                result.circleList.add(c);
            }
        }
        return result;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup container) {
        if (convertView == null) {
            convertView = mActivity.getLayoutInflater().inflate(
                    R.layout.circle_list_item, container, false);
        }
        TBCircle circle = circleList.circleList.get(listSize - position - 1);

        TextView circleName = ((TextView) convertView
                .findViewById(R.id.tv_circlename));
        circleName.setText(circle.name);

        return convertView;
    }

}
