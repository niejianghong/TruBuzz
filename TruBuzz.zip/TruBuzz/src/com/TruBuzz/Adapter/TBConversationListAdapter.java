package com.TruBuzz.Adapter;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.TruBuzz.TBDataBase.TBDBHelper;
import com.TruBuzz.TruBuzz.R;

public class TBConversationListAdapter extends CursorAdapter {

    private Context mContext = null;

    public TBConversationListAdapter(Context context, Cursor c, int flags) {
        super(context, c, flags);
        // TODO Auto-generated constructor stub
        mContext = context;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        LinearLayout item = (LinearLayout) view;

        String nickname = cursor.getString(cursor
                .getColumnIndex(TBDBHelper.NICK_NAME));
        TextView tv = (TextView) item.findViewById(R.id.tv_nickname);
        tv.setText(nickname);

    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        View view = ((Activity) mContext).getLayoutInflater().inflate(
                R.layout.conversation_list_item, parent, false);
        return view;
    }
}
