package com.TruBuzz.Adapter;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

import com.TruBuzz.Activity.ReplyActivity;
import com.TruBuzz.TBBeans.TBMessage;
import com.TruBuzz.TBBeans.TBReplyMessage;
import com.TruBuzz.TBBeans.TBReplyMessageList;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBNetwork.TBReplyConnPool;
import com.TruBuzz.TruBuzz.R;
import com.TruBuzz.TruBuzz.TBApplication;

public class TBReplyMsgAdapter extends BaseAdapter {

    private TBReplyMessageList msgList = null;
    private ReplyActivity mActivity = null;
    private TBReplyMessage replyMsg = null;
    private TBMessage currentMsg = null;
    private int listSize = 0;

    public TBReplyMsgAdapter(ReplyActivity activity,
            TBReplyMessageList msgList, TBMessage currentMsg) {
        this.msgList = msgList;
        this.mActivity = activity;
        this.currentMsg = currentMsg;
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        listSize = msgList.replies.size() + 1;
        return listSize;
    }

    @Override
    public Object getItem(int arg0) {
        // TODO Auto-generated method stub
        if (0 == arg0)
            return null;
        return msgList.replies.get(arg0 - 1);
    }

    @Override
    public long getItemId(int arg0) {
        // TODO Auto-generated method stub
        if (0 == arg0)
            return 0;
        return msgList.replies.get(arg0 - 1).id;
    }

    public void deletedReply(TBReplyMessage msg) {
        int index = msgList.replies.indexOf(msg);
        if (index >= 0) {
            msgList.replies.remove(index);
            this.notifyDataSetChanged();

        }
    }

    @Override
    public View getView(int position, View convertView, ViewGroup container) {
        if (0 != position) {
            convertView = mActivity.getLayoutInflater().inflate(
                    R.layout.reply_list_item, container, false);
        } else {
            convertView = mActivity.getLayoutInflater().inflate(
                    R.layout.msg_list_item, container, false);
        }

        TextView msgContent = ((TextView) convertView
                .findViewById(R.id.tv_content));
        if (0 != position) {
            replyMsg = msgList.replies.get(position - 1);
            ImageView avatar = (ImageView) convertView
                    .findViewById(R.id.img_avatar);
            TextView userName = ((TextView) convertView
                    .findViewById(R.id.tv_username));
            userName.setText(replyMsg.userInfo.nickname);
            TextView postTime = ((TextView) convertView
                    .findViewById(R.id.tv_posttime));
            postTime.setText(replyMsg.create_at);
            msgContent.setText(replyMsg.body);
            final LinearLayout ll_root = (LinearLayout) convertView
                    .findViewById(R.id.ll_root);
            ll_root.setTag(replyMsg);
            ll_root.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View arg0) {
                    TBReplyMessage tempMsg = (TBReplyMessage) ll_root.getTag();
                    final boolean isSelf = (TBApplication.userInfo.id == tempMsg.userInfo.id);

                    AlertDialog.Builder builder = new Builder(mActivity);
                    builder.setMessage(isSelf ? R.string.delete_reply
                            : R.string.accuse_reply);
                    builder.setTitle(android.R.string.dialog_alert_title);
                    builder.setPositiveButton(android.R.string.yes,
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,
                                        int which) {
                                    mActivity.showProgressDialog(
                                            R.string.loading, true);
                                    if (isSelf) {
                                        TBReplyConnPool.deleteReplyMsg(
                                                (TBReplyMessage) ll_root
                                                        .getTag(),
                                                TBConstDef.CB_DELETE_REPLY_MSG
                                                        + "");
                                    } else {
                                        // TODO jhnie add accuse msg at here
                                        TBReplyConnPool.deleteReplyMsg(
                                                (TBReplyMessage) ll_root
                                                        .getTag(),
                                                TBConstDef.CB_DELETE_REPLY_MSG
                                                        + "");
                                    }

                                }
                            });
                    builder.setNegativeButton(android.R.string.cancel,
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,
                                        int which) {
                                    dialog.dismiss();
                                }
                            });
                    builder.create().show();

                }
            });

        } else {

            LayoutParams p = (LayoutParams) msgContent.getLayoutParams();
            p.height = LayoutParams.WRAP_CONTENT;
            msgContent.setLayoutParams(p);
            LinearLayout llTitle = (LinearLayout) convertView
                    .findViewById(R.id.ll_msg_title);
            llTitle.setVisibility(View.GONE);
            LinearLayout llBottom = (LinearLayout) convertView
                    .findViewById(R.id.ll_msg_bottom);
            llBottom.setVisibility(View.GONE);
            ((View) convertView.findViewById(R.id.view1))
                    .setVisibility(View.GONE);

            msgContent.setText(currentMsg.body);
            TextView msgStatus = ((TextView) convertView
                    .findViewById(R.id.tv_buzz_number));
            msgStatus.setText(currentMsg.buzz + " buzz " + currentMsg.share_num
                    + " share" + currentMsg.share_num + " share");

        }

        return convertView;
    }
}
