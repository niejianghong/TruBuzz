package com.TruBuzz.Adapter;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.TruBuzz.Activity.ComposeShareActivity;
import com.TruBuzz.Activity.ReplyActivity;
import com.TruBuzz.Fragments.TBBaseFragment;
import com.TruBuzz.Fragments.TBMsgWallFragment;
import com.TruBuzz.TBBeans.TBMessage;
import com.TruBuzz.TBBeans.TBMessageList;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBNetwork.TBMsgConnPool;
import com.TruBuzz.TBNetwork.TBShareConnPool;
import com.TruBuzz.TruBuzz.R;
import com.TruBuzz.TruBuzz.TBApplication;

public class TBMsgAdapter extends BaseAdapter {

	private TBMessageList msgList = null;
	private TBMsgWallFragment mFragment = null;
	private TBMessage msg = null;
	private int listSize = 0;

	public TBMsgAdapter(TBMsgWallFragment fragment, TBMessageList msgList) {
		this.msgList = msgList;
		this.mFragment = fragment;
	}

	@Override
	public int getCount() {
		listSize = msgList.messages.size();
		return msgList.messages.size();
	}

	@Override
	public Object getItem(int arg0) {
		return msgList.messages.get(listSize - arg0 - 1);
	}

	@Override
	public long getItemId(int arg0) {
		return msgList.messages.get(listSize - arg0 - 1).id;
	}

	public void buzzedMsg(TBMessage msg) {
		int index = msgList.messages.indexOf(msg);
		if (index > 0) {
			msgList.messages.get(index).buzz++;
			this.notifyDataSetChanged();
		}
	}
    public void bullMsg(TBMessage msg) {
        int index = msgList.messages.indexOf(msg);
        if (index > 0) {
            msgList.messages.get(index).bull++;
            this.notifyDataSetChanged();
        }
    }
	    public void bearMsg(TBMessage msg) {
        int index = msgList.messages.indexOf(msg);
        if (index > 0) {
            msgList.messages.get(index).bear++;
            this.notifyDataSetChanged();
        }
    }
	public void setSharedMsgContent(TBMessage msg) {
		int index = msgList.messages.indexOf(msg);
		if (index > 0) {
			msgList.messages.get(index).sharedMsg = msg.sharedMsg;
			this.notifyDataSetChanged();
		}
	}

	public void deletedMsg(TBMessage msg) {
		int index = msgList.messages.indexOf(msg);
		if (index > 0) {
			msgList.messages.remove(index);
			this.notifyDataSetChanged();
		}
	}

	public long getNewstMsgId() {
		return msgList.newestMessageId;
	}

	public long getOldestMsgId() {
		return msgList.oldestMessageId;
	}

	public void addNewstMsg(TBMessageList newList) {
		for (int i = 0; i < newList.messages.size(); i++) {
			msgList.messages.add(newList.messages.get(i));
		}
		msgList.newestMessageId = newList.newestMessageId;
		this.notifyDataSetChanged();
	}

	public void addOldestMsg(TBMessageList oldList) {
		for (int i = 0; i < oldList.messages.size(); i++) {
			msgList.messages.add(0, oldList.messages.get(i));
		}
		msgList.oldestMessageId = oldList.oldestMessageId;
		this.notifyDataSetChanged();
	}

	@Override
	public View getView(int position, View convertView, ViewGroup container) {
		if (convertView == null) {
			convertView = mFragment.mActivity.getLayoutInflater().inflate(
					R.layout.msg_list_item, container, false);
		}
		msg = msgList.messages.get(listSize - position - 1);
		ImageView avatar = (ImageView) convertView
				.findViewById(R.id.img_avatar);
		TextView userName = ((TextView) convertView
				.findViewById(R.id.tv_username));
		userName.setText(msg.userInfo.nickname);
		TextView postTime = ((TextView) convertView
				.findViewById(R.id.tv_posttime));
		postTime.setText(msg.create_at);
		final Button more = (Button) convertView
				.findViewById(R.id.btn_msg_content_more);
		more.setTag(msg);
		more.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				TBMessage tempMsg = (TBMessage) more.getTag();
				final boolean isSelf = (TBApplication.userInfo.id == tempMsg.userInfo.id);

				AlertDialog.Builder builder = new Builder(mFragment.mActivity);
				builder.setMessage(isSelf ? R.string.delete_msg
						: R.string.accuse_msg);
				builder.setTitle(android.R.string.dialog_alert_title);
				builder.setPositiveButton(android.R.string.yes,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								mFragment.showProgressDialog(R.string.loading,
										true);
								if (isSelf) {
									TBMsgConnPool.deleteMsg(
											((TBMessage) more.getTag()),
											TBConstDef.CB_DELETE_MSG + "");
								} else {
									// TODO jhnie add accuse msg at here
									TBMsgConnPool.deleteMsg(
											((TBMessage) more.getTag()),
											TBConstDef.CB_DELETE_MSG + "");
								}

							}
						});
				builder.setNegativeButton(android.R.string.cancel,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int which) {
								dialog.dismiss();
							}
						});
				builder.create().show();

			}
		});

		TextView msgContent = ((TextView) convertView
				.findViewById(R.id.tv_content));
		if (!String.valueOf(TBMessage.SHARED_MSG).equals(msg.type)) {
			msgContent.setText(msg.body);
		} else {
			if (msg.sharedMsg != null) {
				msgContent.setText(msg.body + "\n\n    " + "shared from: "
						+ msg.sharedMsg.name + "\n   " + "正文："
						+ msg.sharedMsg.body);
			}else{
				msgContent.setText(msg.body + "\n\n    " + "shared from: \n\n    loading content, please wait...");
				TBShareConnPool.getShareMessage(msg, msg.share_message_id,
						TBConstDef.CB_GET_SHARE_MSG + "");
			}
		}
		TextView msgStatus = ((TextView) convertView
				.findViewById(R.id.tv_buzz_number));
		msgStatus.setText(msg.buzz + " buzz " + msg.share_num + " share"
				+ msg.share_num + " share");
		Button buzz = (Button) convertView.findViewById(R.id.btn_buzz);
		buzz.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				mFragment.showProgressDialog(R.string.loading, true);
				TBMsgConnPool.postBuzzMessage((TBMessage) more.getTag(),
						TBConstDef.CB_BUZZ_MSG + "");

			}
		});
        Button bull = (Button) convertView.findViewById(R.id.btn_bull);
        bull.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                mFragment.showProgressDialog(R.string.loading, true);
                TBMsgConnPool.postBullMessage((TBMessage) more.getTag(),
                        TBConstDef.CB_BULL_MSG + "");
            }
        });
        Button share_or_bear = (Button) convertView.findViewById(R.id.btn_share_or_bear);
        if(TBBaseFragment.TB_STOCK_MODE != mFragment.listMode){
        	bull.setVisibility(View.GONE);
            msgStatus.setText(msg.buzz + " buzz " + msg.share_num + " share "
                    + msg.share_num + " share");
            share_or_bear.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				Intent i = new Intent(mFragment.mActivity,
						ComposeShareActivity.class);
				Bundle b = new Bundle();
				b.putSerializable(TBMessage.TAG, msg);
				i.putExtras(b);
				mFragment.mActivity.startActivity(i);
			}
		});
        }else{
            msgStatus.setText(msg.buzz + " buzz " + msg.bull + " bull "
                    + msg.bear + " bear");
        	share_or_bear.setText("Bear");
            share_or_bear.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View arg0) {
                    mFragment.showProgressDialog(R.string.loading, true);
                    TBMsgConnPool.postBearMessage((TBMessage) more.getTag(),
                            TBConstDef.CB_BEAR_MSG + "");
                }
            });
        }
		Button reply = (Button) convertView.findViewById(R.id.btn_reply);
		reply.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				Intent i = new Intent(mFragment.mActivity, ReplyActivity.class);
				Bundle b = new Bundle();

				b.putSerializable(TBMessage.TAG, (TBMessage) more.getTag());
				i.putExtras(b);
				mFragment.mActivity.startActivity(i);

			}
		});
		return convertView;
	}

}
