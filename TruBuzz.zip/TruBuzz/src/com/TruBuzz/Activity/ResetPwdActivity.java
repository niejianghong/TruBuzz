package com.TruBuzz.Activity;

import android.content.IntentFilter;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBNetwork.TBNetworkResult;
import com.TruBuzz.TruBuzz.R;

public class ResetPwdActivity extends TBBaseActivity {

    private EditText orgPwdInputText = null;
    private EditText passwordInputText = null;
    private EditText rePwdInputText = null;

    private Button cancelBtn = null;
    private Button okBtn = null;

    private static String TAG = "ResetPwdActivity";

    private void initUi() {

        cancelBtn = (Button) findViewById(R.id.btn_cancel);
        cancelBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                ResetPwdActivity.this.finish();
            }
        });

        orgPwdInputText = (EditText) findViewById(R.id.et_org_pwd);
        passwordInputText = (EditText) findViewById(R.id.et_password);
        rePwdInputText = (EditText) findViewById(R.id.et_re_password);

        okBtn = (Button) findViewById(R.id.btn_ok);
        okBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                login();
            }
        });
    }

    protected void regTBRecver() {
        mReceiver = new TBReciver();
        IntentFilter filter = new IntentFilter();
        filter.addAction(TBConstDef.CB_USER_LOGIN + "");
        filter.addAction(TBConstDef.CB_GET_USER_INFO + "");

        registerReceiver(mReceiver, filter);
    }

    private void login() {
        String orgPwd = orgPwdInputText.getText().toString();
        String rePwd = rePwdInputText.getText().toString();
        String password = passwordInputText.getText().toString();
        // 校验参数
        if (TextUtils.isEmpty(orgPwd) || TextUtils.isEmpty(password)||TextUtils.isEmpty(rePwd)) {
            showToast(R.string.pwd_is_null, Toast.LENGTH_LONG);
            return;
        }
        
        if(!rePwd.equals(password)){
            showToast(R.string.pwd_not_match, Toast.LENGTH_LONG);
            return;
        }

        // TODO jhnie, add reset password communication at here.
        showToast("this api didn't implement. ", Toast.LENGTH_LONG);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.TAG = TAG;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_pwd);

        // 初始化子元素
        initUi();
    }

    @Override
    protected void processBrodcast(int actionID, TBNetworkResult netResult) {

    }

}
