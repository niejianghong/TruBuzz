package com.TruBuzz.Activity;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.TruBuzz.TBBeans.TBUserInfo;
import com.TruBuzz.TBCommon.TBConfigUtils;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;
import com.TruBuzz.TBNetwork.TBNetworkResult;
import com.TruBuzz.TBNetwork.TBUserConnPool;
import com.TruBuzz.TruBuzz.R;
import com.TruBuzz.TruBuzz.TBApplication;

public class LoginActivity extends TBBaseActivity {

    private EditText accountInputText = null;
    private EditText passwordInputText = null;
    private static boolean isLoging = false;

    private Button manaulRegBtn = null;
    private Button loginBtn = null;

    public static boolean isLogining = true;

    private static String TAG = "LoginActivity";

    private void initUi() {

        manaulRegBtn = (Button) findViewById(R.id.btn_new_user);
        manaulRegBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this,
                        CreateNewUserActivity.class);
                startActivity(intent);
            }
        });

        accountInputText = (EditText) findViewById(R.id.et_account);
        passwordInputText = (EditText) findViewById(R.id.et_password);

        loginBtn = (Button) findViewById(R.id.btn_login);
        loginBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                login();
            }
        });
    }

    protected void regTBRecver() {
        mReceiver = new TBReciver();
        IntentFilter filter = new IntentFilter();
        filter.addAction(TBConstDef.CB_USER_LOGIN + "");
        filter.addAction(TBConstDef.CB_GET_USER_INFO + "");
        filter.addAction(TBConstDef.CB_GET_AUTH_KEY + "");
        filter.addAction(TBConstDef.CB_DELETE_AUTH_KEY + "");

        registerReceiver(mReceiver, filter);
    }

    private void login() {
        String account = accountInputText.getText().toString();
        String password = passwordInputText.getText().toString();
        // 校验参数
        if (TextUtils.isEmpty(account) || TextUtils.isEmpty(password)) {
            showToast(R.string.account_pwd_is_null, Toast.LENGTH_LONG);
            return;
        }
        showProgressDialog(R.string.loging_pls_wait, true);

        TBUserConnPool.getSessionKey(TBConstDef.CB_GET_AUTH_KEY + "");

    }

    public void onResume() {
        String accountPassword = "";
        String accountName = TBConfigUtils.getAcountName(this);// 获取默认账号
        if (!TextUtils.isEmpty(accountName)) {
            accountInputText.setText(accountName);
        }
        accountPassword = TBConfigUtils.getAcountPassword(this);// 获取默认密码

        if (!TextUtils.isEmpty(accountPassword)) {
            passwordInputText.setText(accountPassword);
        }
        if (TBConfigUtils.getAutoLoginFlag(this)
                && !TextUtils.isEmpty(accountName)
                && !TextUtils.isEmpty(accountPassword) && !isLoging) {
            login();
            isLoging = true;
        }

        super.onResume();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.TAG = TAG;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // 初始化子元素
        initUi();
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {

        switch (keyCode) {
        case KeyEvent.KEYCODE_BACK:
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void processBrodcast(int actionID, TBNetworkResult netResult) {
        switch (actionID) {
        case TBConstDef.CB_GET_AUTH_KEY:
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                stopProgressDialog();
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                // 发起登录
                TBUserConnPool.login(accountInputText.getText().toString(),
                        passwordInputText.getText().toString(),
                        TBConstDef.CB_USER_LOGIN + "");
            }
            break;
        case TBConstDef.CB_USER_LOGIN:
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                stopProgressDialog();
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                TBConfigUtils.setAutoLoginFlag(this, true);
                TBUserConnPool.getUserInfo(TBConstDef.CB_GET_USER_INFO + "");

                TBConfigUtils.setAccountName(this, accountInputText.getText()
                        .toString());
                TBConfigUtils.setAccountPassword(this, passwordInputText
                        .getText().toString());

            }
            break;
        case TBConstDef.CB_GET_USER_INFO:
            stopProgressDialog();
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {

                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                TBApplication.userInfo = (TBUserInfo) netResult;
                TBUserConnPool.getUserAvatar(TBApplication.userInfo.avatar,
                        TBLog.getSDCardPath(TBApplication.mGlobalContext)
                                + TBLog.logpath + "avatar.png",
                        TBConstDef.CB_GET_USER_AVATAR + "");
                if (!ComposeShareActivity.hasShare) {
//                    Intent intent = new Intent(this, MainUIActivity.class);
//                    startActivity(intent);
//                    Intent intent = new Intent(this, ConversationListActivity.class);
//                    startActivity(intent);
                    Intent intent = new Intent(this, ChatActivity.class);
                    startActivity(intent);
                    
                } else {
                    ComposeShareActivity.hasShare = false;
                }
                isLogining = false;
                synchronized (LaunchActivity.waitObj) {
                    LaunchActivity.waitObj.notifyAll();
                }
                LoginActivity.this.finish();
            }
            break;
        default:
            TBLog.e(TAG, "fatal error: unknown network callback function id: "
                    + actionID);
            break;
        }

    }

}
