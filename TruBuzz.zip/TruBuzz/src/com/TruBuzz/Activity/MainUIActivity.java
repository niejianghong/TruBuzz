package com.TruBuzz.Activity;

import android.app.NotificationManager;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.view.KeyEvent;
import android.view.View;

import com.TruBuzz.Fragments.TBBaseFragment;
import com.TruBuzz.Fragments.TBCircleMenuFragment;
import com.TruBuzz.Fragments.TBMsgWallFragment;
import com.TruBuzz.TBBeans.TBPushMessage;
import com.TruBuzz.TBCommon.TBLog;
import com.TruBuzz.TruBuzz.R;
import com.TruBuzz.TruBuzz.TBApplication;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.jeremyfeinstein.slidingmenu.lib.app.SlidingFragmentActivity;

/**
 * 
 * @author jhnie
 * 
 */
public class MainUIActivity extends SlidingFragmentActivity {

	private TBMsgWallFragment mContent = null;
	private String TAG = "MainUIActivity";

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		TBLog.e(TAG, "activity create:" + TAG);

		setTitle(R.string.app_name);

		setContentView(R.layout.responsive_content_frame);
		TBApplication.addActivity(this);
		if(null == TBApplication.userInfo || null == TBApplication.session_key){
		    TBLog.e(TAG, "the user info or session_key was null, so we should reg again.");
            Intent intent = new Intent(MainUIActivity.this,
                    LaunchActivity.class);
            startActivity(intent);
		    finish();
		    return;
		}

		// check if the content frame contains the menu frame
		if (findViewById(R.id.menu_frame) == null) {
			setBehindContentView(R.layout.menu_frame);
			getSlidingMenu().setSlidingEnabled(true);
			getSlidingMenu()
					.setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);
			// show home as up so we can toggle
			// getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		} else {
			// add a dummy view
			View v = new View(this);
			setBehindContentView(v);
			getSlidingMenu().setSlidingEnabled(false);
			getSlidingMenu().setTouchModeAbove(SlidingMenu.TOUCHMODE_NONE);
		}

		// // set the Above View Fragment
		// if (savedInstanceState != null)
		// mContent = (TBMsgWallFragment) getSupportFragmentManager()
		// .getFragment(savedInstanceState, "mContent");
		// if (mContent == null)

		// mContent = new TBMsgWallFragment(this, TBBaseFragment.TB_MSG_MODE);
		Intent i = getIntent();
		if (null != i) {
			mContent = new TBMsgWallFragment(this,  (TBPushMessage)i.getSerializableExtra("PushData"));
		}
		if (null == mContent) {
			mContent = new TBMsgWallFragment(this, TBBaseFragment.TB_MSG_MODE);
		}
		getSupportFragmentManager().beginTransaction()
				.replace(R.id.content_frame, mContent).commit();

		// set the Behind View Fragment
		getSupportFragmentManager()
				.beginTransaction()
				.replace(
						R.id.menu_frame,
						new TBCircleMenuFragment(this,
								TBBaseFragment.TB_MSG_MODE)).commit();

		// customize the SlidingMenu
		SlidingMenu sm = getSlidingMenu();
		sm.setBehindOffsetRes(R.dimen.slidingmenu_offset);
		sm.setShadowWidthRes(R.dimen.shadow_width);
		sm.setShadowDrawable(R.drawable.shadow);
		sm.setBehindScrollScale(0.25f);
		sm.setFadeDegree(0.25f);
		clearNotification();
	}
	
	@Override
	public void onDestroy(){
	    super.onDestroy();
	    TBLog.e(TAG, "it's horrible, low memory, have to kill Trubuzz");
	}
	
	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		Fragment frg = null;
		if (null != intent) {
			frg = new TBMsgWallFragment(this,  (TBPushMessage)intent.getSerializableExtra("PushData"));
		}
		if (null == frg) {
			frg = new TBMsgWallFragment(this, TBBaseFragment.TB_MSG_MODE);
		}
		switchContent(frg);

	}

	private void clearNotification() {
		// 启动后删除之前我们定义的通知
		NotificationManager notificationManager = (NotificationManager) this
				.getSystemService(NOTIFICATION_SERVICE);
		notificationManager.cancel(13034763);

	}

	public boolean onKeyDown(int keyCode, KeyEvent event) {

		switch (keyCode) {
		case KeyEvent.KEYCODE_BACK:
			Intent intent = new Intent(Intent.ACTION_MAIN);
			intent.addCategory(Intent.CATEGORY_HOME);
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			startActivity(intent);

			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	// @Override
	// public boolean onOptionsItemSelected(MenuItem item) {
	// switch (item.getItemId()) {
	// case android.R.id.home:
	// toggle();
	// }
	// return super.onOptionsItemSelected(item);
	// }
	//
	// @Override
	// public void onSaveInstanceState(Bundle outState) {
	// super.onSaveInstanceState(outState);
	// getSupportFragmentManager().putFragment(outState, "mContent", mContent);
	// }

	// @Override
	// public void onDestroy() {
	//
	// super.onDestroy();
	// }

	public void switchContent(final Fragment fragment) {
		mContent = (TBMsgWallFragment) fragment;
		getSupportFragmentManager().beginTransaction()
				.replace(R.id.content_frame, fragment).commit();
		Handler h = new Handler();
		h.postDelayed(new Runnable() {
			public void run() {
				getSlidingMenu().showContent();
			}
		}, 50);
	}

	public void switchMenu() {
		Handler h = new Handler();
		h.postDelayed(new Runnable() {
			public void run() {
				getSlidingMenu().showMenu();
			}
		}, 50);
	}
}
