package com.TruBuzz.Activity;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.TruBuzz.Adapter.TBReplyMsgAdapter;
import com.TruBuzz.TBBeans.TBMessage;
import com.TruBuzz.TBBeans.TBReplyMessage;
import com.TruBuzz.TBBeans.TBReplyMessageList;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;
import com.TruBuzz.TBNetwork.TBMsgConnPool;
import com.TruBuzz.TBNetwork.TBNetworkResult;
import com.TruBuzz.TBNetwork.TBReplyConnPool;
import com.TruBuzz.TruBuzz.R;

public class ReplyActivity extends TBBaseActivity {

    private EditText msgText = null;
    private Button shareBtn = null;
    private TBMessage msg = null;
    private ListView listView = null;
    private Button buzzBtn = null;
    private Button sendBtn = null;
    private TBReplyMsgAdapter mAdapter = null;

    private static String TAG = "ReplyActivity";

    private void initUi() {

        shareBtn = (Button) findViewById(R.id.btn_share);
        shareBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
               Intent i = new Intent(ReplyActivity.this, ComposeShareActivity.class);
               Bundle b = new Bundle();
               b.putSerializable(TBMessage.TAG, msg);
               i.putExtras(b);
               ReplyActivity.this.startActivity(i);
            }
        });

        msgText = (EditText) findViewById(R.id.et_reply);
        buzzBtn = (Button) findViewById(R.id.btn_buzz);
        buzzBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                showProgressDialog(R.string.loading, true);
                TBMsgConnPool.postBuzzMessage(msg, TBConstDef.CB_BUZZ_MSG + "");

            }
        });

        sendBtn = (Button) findViewById(R.id.btn_send);
        sendBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String content = msgText.getText().toString();
                if (TextUtils.isEmpty(content)) {
                    showToast(R.string.reply_is_null, Toast.LENGTH_LONG);
                    return;
                }
                showProgressDialog(R.string.loading, true);
                TBReplyConnPool.postReplyMessage(msg.id, content,
                        TBConstDef.CB_POST_REPLY_MSG + "");
            }
        });
        listView = (ListView)findViewById(android.R.id.list);
    }

    protected void regTBRecver() {
        mReceiver = new TBReciver();
        IntentFilter filter = new IntentFilter();
        filter.addAction(TBConstDef.CB_BUZZ_MSG + "");
        filter.addAction(TBConstDef.CB_POST_REPLY_MSG + "");
        filter.addAction(TBConstDef.CB_GET_REPLY_MSG + "");
        filter.addAction(TBConstDef.CB_DELETE_REPLY_MSG + "");

        registerReceiver(mReceiver, filter);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.TAG = TAG;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reply);
        Bundle b = getIntent().getExtras();
        msg = (TBMessage) b.getSerializable(TBMessage.TAG);
        // 初始化子元素
        initUi();
        showProgressDialog(R.string.loading_msg, true);
        TBReplyConnPool.getReplyMessageList(msg.id, TBConstDef.CB_GET_REPLY_MSG+"");
    }

    @Override
    protected void processBrodcast(int actionID, TBNetworkResult netResult) {
        switch (actionID) {
        case TBConstDef.CB_BUZZ_MSG:
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                // just stop the progress dialog, bcs the brodcast will be
                // processed by the TBMsgWallFragment.
            }
            stopProgressDialog();
            break;
        case TBConstDef.CB_POST_REPLY_MSG:
            stopProgressDialog();
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                showToast(R.string.reply_sent, Toast.LENGTH_LONG);
                msgText.setText("");
                showProgressDialog(R.string.loading_msg, true);
                TBReplyConnPool.getReplyMessageList(msg.id, TBConstDef.CB_GET_REPLY_MSG+"");
            }

            break;
        case TBConstDef.CB_GET_REPLY_MSG:
            stopProgressDialog();
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(R.string.error_no_reply_msg, Toast.LENGTH_LONG);
                mAdapter = new TBReplyMsgAdapter(ReplyActivity.this, new TBReplyMessageList(), msg);
            } else {
                mAdapter = new TBReplyMsgAdapter(ReplyActivity.this, (TBReplyMessageList)netResult, msg);
            }
            listView.setAdapter(mAdapter);
            break;
        case TBConstDef.CB_DELETE_REPLY_MSG:
            stopProgressDialog();
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                mAdapter.deletedReply((TBReplyMessage)netResult);
            }
            break;

        default:
            TBLog.e(TAG, "fatal error: unknown network callback function id: "
                    + actionID);
            break;
        }

    }

}
