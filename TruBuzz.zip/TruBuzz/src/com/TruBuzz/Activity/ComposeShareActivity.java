package com.TruBuzz.Activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.TruBuzz.TBBeans.TBCircleList;
import com.TruBuzz.TBBeans.TBMessage;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;
import com.TruBuzz.TBDataBase.TBDBUtils;
import com.TruBuzz.TBNetwork.TBCircleConnPool;
import com.TruBuzz.TBNetwork.TBMsgConnPool;
import com.TruBuzz.TBNetwork.TBNetworkResult;
import com.TruBuzz.TBNetwork.TBShareConnPool;
import com.TruBuzz.TruBuzz.R;
import com.TruBuzz.TruBuzz.TBApplication;

public class ComposeShareActivity extends TBBaseActivity {

    private EditText contentText = null;
    private Button sendBtn = null;
    private Button postToBtn = null;

    public static int SHARE_TO_PUBLIC = 1;
    public static int SHARE_TO_FRIENDS = 2;
    public static int SHARE_TO_CIRCLE = 3;
    public static boolean hasShare = false;

    private TBMessage shareMsg = null;
    private String sharedText = null;
    private Uri imageUri = null;
    private TBCircleList circleList = null;
    private int shareType = SHARE_TO_PUBLIC;
    private String circleName = null;
    private String circleId = null;

    private static String TAG = "ComposeShareActivity";

    private void initUi() {

        contentText = (EditText) findViewById(R.id.et_content);
        contentText.requestFocus();

        sendBtn = (Button) findViewById(R.id.btn_send);
        sendBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String content = contentText.getText().toString();
                if (TextUtils.isEmpty(content)) {
                    showToast(R.string.msg_is_null, Toast.LENGTH_LONG);
                    return;
                }
                showProgressDialog(R.string.loading, true);
                if (null != shareMsg) {
                    TBShareConnPool.shareMessage(shareMsg, content, shareType,
                            shareMsg.userInfo.account, circleName,
                            TBConstDef.CB_POST_SHARE_MSG + "");
                    return;
                }
                if (SHARE_TO_PUBLIC == shareType) {
                    TBMsgConnPool.postMessage(content, TBConstDef.CB_POST_MSG
                            + "");
                }else if(SHARE_TO_CIRCLE == shareType){
                    TBCircleConnPool.postCircle(circleId, content, TBConstDef.CB_POST_CIRCLE_MSG+"");
                }else{
                    // TODO jhnie, add share to someone at here.
                }
            }
        });
        postToBtn = (Button) findViewById(R.id.btn_to);
        postToBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                showCircleSel();
            }

        });

        TextView attached = (TextView) findViewById(R.id.tv_attached);
        TextView title = (TextView) findViewById(R.id.tv_title);
        if (null == shareMsg) {
            attached.setVisibility(View.GONE);
            title.setText(R.string.compose_title);
        } else {
            contentText.setText(sharedText);
            hasShare = true;
        }
    }

    private void showCircleSel() {

        List<Map<String, ?>> entries = new ArrayList<Map<String, ?>>();
        HashMap<String, Object> pw_entry = new HashMap<String, Object>();
        pw_entry.put("circle_name",
                ComposeShareActivity.this.getString(R.string.public_wall));
        pw_entry.put("circle_id", 0);
        entries.add(pw_entry);
        for (int i = 0; i < circleList.circleList.size(); ++i) {
            HashMap<String, Object> entry = new HashMap<String, Object>();
            entry.put("circle_name", circleList.circleList.get(i).name);
            entry.put("circle_id", circleList.circleList.get(i).id);
            entries.add(entry);
        }
        final SimpleAdapter qtAdapter = new SimpleAdapter(
                ComposeShareActivity.this, entries,
                R.layout.choose_circle_item, new String[] { "circle_name" },
                new int[] { R.id.item_text });

        AlertDialog.Builder qtBuilder = new AlertDialog.Builder(
                ComposeShareActivity.this);
        qtBuilder.setCancelable(true);
        qtBuilder.setAdapter(qtAdapter, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub
                if (which > 0) {
                    shareType = SHARE_TO_CIRCLE;
                } else {
                    shareType = SHARE_TO_PUBLIC;
                }
                @SuppressWarnings("unchecked")
                HashMap<String, Object> item = (HashMap<String, Object>) qtAdapter
                        .getItem(which);
                circleName = (String) item.get("circle_name");
                circleId = item.get("circle_id")+"";
                postToBtn.setText(circleName);
                dialog.dismiss();
            }
        });
        qtBuilder.create().show();
    }

    protected void regTBRecver() {
        mReceiver = new TBReciver();
        IntentFilter filter = new IntentFilter();
        filter.addAction(TBConstDef.CB_POST_MSG + "");
        filter.addAction(TBConstDef.CB_POST_SHARE_MSG + "");
        filter.addAction(TBConstDef.CB_POST_CIRCLE_MSG + "");
        registerReceiver(mReceiver, filter);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.TAG = TAG;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compose_share);
        Bundle b = getIntent().getExtras();
        try {
            shareMsg = (TBMessage) b.getSerializable(TBMessage.TAG);
        } catch (Exception e) {

        }

        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();

        if (Intent.ACTION_SEND.equals(action) && type != null) {
            if ("text/plain".equals(type)) {
                sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
            } else if (type.startsWith("image/")) {
                imageUri = (Uri) intent.getParcelableExtra(Intent.EXTRA_STREAM);
            }
        }

        initUi();

        if (null != imageUri) {
            // TODO jhnie, add share img function
            hasShare = true;
        }

        if (null == TBApplication.userInfo) {
            Intent i = new Intent(this, LoginActivity.class);
            startActivity(i);
        }
        circleList = TBDBUtils.getInstance(this).getCircleListFromDB();
    }

    @Override
    protected void processBrodcast(int actionID, TBNetworkResult netResult) {
        switch (actionID) {
        case TBConstDef.CB_POST_MSG:
            stopProgressDialog();
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                showToast(R.string.post_msg_ok, Toast.LENGTH_LONG);
                if (hasShare) {
                    Intent intent = new Intent(this, MainUIActivity.class);
                    startActivity(intent);
                }
                ComposeShareActivity.this.finish();
            }
            break;
        case TBConstDef.CB_POST_SHARE_MSG:
            stopProgressDialog();
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                showToast(R.string.share_msg_ok, Toast.LENGTH_LONG);
                if (hasShare) {
                    Intent intent = new Intent(this, MainUIActivity.class);
                    startActivity(intent);
                }
                ComposeShareActivity.this.finish();
            }
            break;
        case TBConstDef.CB_POST_CIRCLE_MSG:
            stopProgressDialog();
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                showToast(R.string.post_msg_ok, Toast.LENGTH_LONG);
                ComposeShareActivity.this.finish();
            }
            break;
        default:
            TBLog.e(TAG, "fatal error: unknown network callback function id: "
                    + actionID);
            break;
        }

    }

}
