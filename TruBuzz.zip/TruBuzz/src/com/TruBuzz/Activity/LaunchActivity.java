package com.TruBuzz.Activity;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.widget.Toast;

import com.TruBuzz.TBBeans.TBPushBase;
import com.TruBuzz.TBBeans.TBPushMessage;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;
import com.TruBuzz.TBNetwork.TBNetworkResult;
import com.TruBuzz.TBNetwork.TBUserConnPool;
import com.TruBuzz.TruBuzz.R;
import com.TruBuzz.TruBuzz.TBApplication;
import com.arellomobile.android.push.BasePushMessageReceiver;
import com.arellomobile.android.push.PushManager;
import com.arellomobile.android.push.utils.RegisterBroadcastReceiver;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;

public class LaunchActivity extends TBBaseActivity {

    private int errorCode = -1;
    private String TAG = "LaunchActivity";

    public static Object waitObj = new Object();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.TAG = TAG;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launch);
        initDeviceInfo();

        errorCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
        if (ConnectionResult.SUCCESS == errorCode) {
            initPushFunction();
        } else {
            showToast(R.string.no_push_service, Toast.LENGTH_LONG);
            GooglePlayServicesUtil.getErrorDialog(errorCode, this, 110).show();
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(3000);
                    Intent intent = new Intent(LaunchActivity.this,
                            LoginActivity.class);
                    startActivity(intent);
                    // this sample for test push data.
                    // doOnMessageReceive("{\"u\":\"{\\\"NotificationType\\\":\\\"Message\\\",\\\"MsgType\\\":\\\"CircleMsg\\\",\\\"ContentType\\\":\\\"Text\\\",\\\"ContentCreator\\\":\\\"Org\\\",\\\"MsgData\\\":{\\\"msgId\\\":673,\\\"subject\\\":\\\"21:43\\\",\\\"nickName\\\":\\\"jhnie\\\",\\\"circleId\\\":36,\\\"circleName\\\":\\\"jhnie_circle_for_test\\\"}}\",\"userdata\":\"{\\\"NotificationType\\\":\\\"Message\\\",\\\"MsgType\\\":\\\"CircleMsg\\\",\\\"ContentType\\\":\\\"Text\\\",\\\"ContentCreator\\\":\\\"Org\\\",\\\"MsgData\\\":{\\\"msgId\\\":673,\\\"subject\\\":\\\"21:43\\\",\\\"nickName\\\":\\\"jhnie\\\",\\\"circleId\\\":36,\\\"circleName\\\":\\\"jhnie_circle_for_test\\\"}}\",\"title\":\"Circle jhnie_circle_for_test has new message\",\"collapse_key\":\"do_not_collapse\",\"p\":\"m\",\"from\":\"56846469641\",\"onStart\":true,\"foreground\":false}");
                    
                    // this sample for test new push token
//                    Intent i = new Intent();
//                    i.putExtra(PushManager.REGISTER_EVENT, "XXXXXXXXXXXX"+System.currentTimeMillis());
//                    checkMessage(i);
                } catch (InterruptedException e) {
                    Intent intent = new Intent(LaunchActivity.this,
                            LoginActivity.class);
                    startActivity(intent);
                }
            }

        }).start();
    }

    private void showNotification(TBPushBase obj, String title, String msg) {
        // 创建一个NotificationManager的引用
        NotificationManager notificationManager = (NotificationManager) this
                .getSystemService(android.content.Context.NOTIFICATION_SERVICE);

        // 定义Notification的各种属性
        Notification notification = new Notification(R.drawable.logo, msg,
                System.currentTimeMillis());

        notification.flags |= Notification.FLAG_AUTO_CANCEL;
        notification.flags |= Notification.FLAG_SHOW_LIGHTS;
        notification.defaults = Notification.DEFAULT_ALL;
        notification.ledARGB = Color.BLUE;
        notification.ledOnMS = 5000; // 闪光时间，毫秒

        // 设置通知的事件消息
        CharSequence contentTitle = title;
        CharSequence contentText = msg; // 通知栏内容
        // TODO jhnie, we should parse the Notification Type at here and choose
        // the Activity we want to launch via the Type value
        Intent notificationIntent = new Intent(this, MainUIActivity.class); // 点击该通知后要跳转的Activity
        notificationIntent.putExtra("PushData", obj);
        PendingIntent contentItent = PendingIntent.getActivity(this, 0,
                notificationIntent, 0);
        notification.setLatestEventInfo(this, contentTitle, contentText,
                contentItent);

        notificationManager.notify(13034763, notification);
    }

    private void initPushFunction() {
        // Register receivers for push notifications
        registerPushReceivers();

        // Create and start push manager
        PushManager pushManager = new PushManager(this,
                TBApplication.mWooshPushAppId, TBApplication.mWosshPushSenderID);
        pushManager.onStartup(this);

        checkMessage(getIntent());
    }

    private void initDeviceInfo() {
        TBApplication.screenSize = getScreenSize(this);
        // 初始化手机号码
        TelephonyManager mTm = (TelephonyManager) getSystemService(Activity.TELEPHONY_SERVICE);
        TBApplication.phoneNumber = mTm.getLine1Number();

        // 初始化IMEI
        TBApplication.imei = mTm.getDeviceId();
        TBLog.e("TruBuzz", "Device infomation: " + TBApplication.phoneNumber
                + ", imei: " + TBApplication.imei);
    }

    // Registration receiver
    BroadcastReceiver mBroadcastPushReceiver = new RegisterBroadcastReceiver() {
        @Override
        public void onRegisterActionReceive(Context context, Intent intent) {
            TBLog.e(TAG, "TruBuzz recv intent: " + intent.toString());
            checkMessage(intent);
        }
    };

    // Push message receiver
    private BroadcastReceiver mPushReceiver = new BasePushMessageReceiver() {
        @Override
        protected void onMessageReceive(Intent intent) {
            // JSON_DATA_KEY contains JSON payload of push notification.
            doOnMessageReceive(intent.getExtras().getString(JSON_DATA_KEY));
        }
    };

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        TBLog.e(TAG, "TruBuzz recv new intent: " + intent.toString());
        if (ConnectionResult.SUCCESS != errorCode) {
            setIntent(intent);
            checkMessage(intent);
            setIntent(new Intent());
        }

    }

    public void doOnMessageReceive(String message) {
        TBLog.e(TAG, "TruBuzz recv push msg: " + message);

        // Parse custom JSON data string.
        // You can set background color with custom JSON data in the following
        // format: { "r" : "10", "g" : "200", "b" : "100" }
        // Or open specific screen of the app with custom page ID (set ID in the
        // { "id" : "2" } format)

        try {
            JSONObject messageJson = new JSONObject(message);
            JSONObject ud = null;

            if (messageJson.has("userdata")) {
                ud = new JSONObject(messageJson.getString("userdata"));
            }
            // this comments wroten by jhnie
            // I don't know why the json data has "u", so I have to double parse
            // to keep the result was right.
            if (messageJson.has("u")) {
                ud = new JSONObject(messageJson.getString("u"));
            }
            if (!ud.has(TBPushBase.PUSH_TYPE)) {
                TBLog.e(TAG,
                        "push data has no notification type, just ignore it.");
                return;
            }
            String notificationStr = "";
            String notificationTitle = "";
            String pushType = ud.getString(TBPushBase.PUSH_TYPE);
            TBPushBase pushObj = null;
            if (TBPushBase.PUSH_TYPE_MESSAGE.equals(pushType)) {
                pushObj = new TBPushMessage(ud);
                if (((TBPushMessage) pushObj).msgId <= 0) {
                    return;
                }
                notificationTitle = ((TBPushMessage) pushObj).fromName
                        + getString(R.string.post_new_msg);
                notificationStr = ((TBPushMessage) pushObj).nickName + ": "
                        + ((TBPushMessage) pushObj).subject;
            } else if (TBPushBase.PUSH_TYPE_CHAT.equals(pushType)) {
                // TODO jhnie, parse CHAT push msg at here
                // pushObj = new TBPushChat(ud);
            } else if (TBPushBase.PUSH_TYPE_UPDATE.equals(pushType)) {
                // TODO jhnie, balabalabala.....
                // pushObj = new TBPushUpdate(ud);
            }
            if (null != pushObj) {
                showNotification(pushObj, notificationTitle, notificationStr);
            } else {
                Toast.makeText(
                        this,
                        "It's horrible, we get some push not correct, pls save the Trubuzz Log as another file and report to jhnie.",
                        Toast.LENGTH_LONG).show();
            }

        } catch (JSONException e) {
            TBLog.e(TAG, e.getMessage());
        }
    }

    private void uploadDeviceInfo() {
            TBUserConnPool.uploadDeviceInfo(
                    TBConstDef.CB_UPLOAD_DEVICE_INFO + "");
    }

    /**
     * Will check PushWoosh extras in this intent, and fire actual method
     * 
     * @param intent
     *            activity intent
     */
    private void checkMessage(Intent intent) {
        if (null != intent) {
            String msg = null;
            if (intent.hasExtra(PushManager.PUSH_RECEIVE_EVENT)) {
                msg = intent.getExtras().getString(
                        PushManager.PUSH_RECEIVE_EVENT);
                doOnMessageReceive(intent.getExtras().getString(
                        PushManager.PUSH_RECEIVE_EVENT));
            } else if (intent.hasExtra(PushManager.REGISTER_EVENT)) {
                msg = intent.getExtras().getString(PushManager.REGISTER_EVENT);

                if (msg.equals(TBApplication.getPushToken())) {
                    TBLog.e(TAG,
                            "new push token same as we cached, so ignore this push token");
                } else {
                    if (LoginActivity.isLogining) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                TBLog.e(TAG,
                                        "shit!! the push_token was arrived late, but it is logining now, we have to wait..");
                                try {
                                    synchronized (waitObj) {
                                        waitObj.wait();
                                    }
                                    uploadDeviceInfo();
                                } catch (InterruptedException e) {
                                    uploadDeviceInfo();
                                }

                            }
                        }).start();
                    } else {
                        TBLog.e(TAG,
                                "client have been reged, so just reg again.");
                        uploadDeviceInfo();
                    }
                }
                TBApplication.setPushToken(msg);
            } else if (intent.hasExtra(PushManager.UNREGISTER_EVENT)) {
                msg = intent.getExtras()
                        .getString(PushManager.UNREGISTER_EVENT);
            } else if (intent.hasExtra(PushManager.REGISTER_ERROR_EVENT)) {
                msg = intent.getExtras().getString(
                        PushManager.REGISTER_ERROR_EVENT);
            } else if (intent.hasExtra(PushManager.UNREGISTER_ERROR_EVENT)) {
                msg = intent.getExtras().getString(
                        PushManager.UNREGISTER_ERROR_EVENT);
            }
            TBLog.e(TAG, "process action in intent from the push manager: "
                    + msg);
            resetIntentValues();
        }
    }

    /**
     * Will check main Activity intent and if it contains any PushWoosh data,
     * will clear it
     */
    private void resetIntentValues() {
        Intent mainAppIntent = getIntent();

        if (mainAppIntent.hasExtra(PushManager.PUSH_RECEIVE_EVENT)) {
            mainAppIntent.removeExtra(PushManager.PUSH_RECEIVE_EVENT);
        } else if (mainAppIntent.hasExtra(PushManager.REGISTER_EVENT)) {
            mainAppIntent.removeExtra(PushManager.REGISTER_EVENT);
        } else if (mainAppIntent.hasExtra(PushManager.UNREGISTER_EVENT)) {
            mainAppIntent.removeExtra(PushManager.UNREGISTER_EVENT);
        } else if (mainAppIntent.hasExtra(PushManager.REGISTER_ERROR_EVENT)) {
            mainAppIntent.removeExtra(PushManager.REGISTER_ERROR_EVENT);
        } else if (mainAppIntent.hasExtra(PushManager.UNREGISTER_ERROR_EVENT)) {
            mainAppIntent.removeExtra(PushManager.UNREGISTER_ERROR_EVENT);
        }

        setIntent(mainAppIntent);
    }

    // Registration of the receivers
    public void registerPushReceivers() {
        IntentFilter intentFilter = new IntentFilter(getPackageName()
                + ".action.PUSH_MESSAGE_RECEIVE");

        // if(broadcastPush)
        registerReceiver(mPushReceiver, intentFilter);

        registerReceiver(mBroadcastPushReceiver,
                new IntentFilter(getPackageName() + "."
                        + PushManager.REGISTER_BROAD_CAST_ACTION));
    }

    public void unregisterPushReceivers() {
        // Unregister receivers on pause
        try {
            unregisterReceiver(mPushReceiver);
        } catch (Exception e) {
            // pass.
        }

        try {
            unregisterReceiver(mBroadcastPushReceiver);
        } catch (Exception e) {
            // pass through
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (ConnectionResult.SUCCESS == errorCode) {
            registerPushReceivers();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        TBLog.e(TAG, "onStop...");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        TBLog.e(TAG, "it's horrible, low memory, have to kill Trubuzz");
        if (ConnectionResult.SUCCESS == errorCode) {
            unregisterPushReceivers();
        }
    }

    @Override
    protected void processBrodcast(int actionID, TBNetworkResult netResult) {
        switch (actionID) {
        case TBConstDef.CB_UPLOAD_DEVICE_INFO:
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                TBLog.e(TAG,
                        "upload the push_token error, we should try again later.");
                new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try {
                            Thread.sleep(600000);
                            uploadDeviceInfo();
                        } catch (InterruptedException e) {
                            uploadDeviceInfo();
                        }
                    }
                }).start();
            } else {
                TBLog.e(TAG,
                        "it seems we upload the push_token success, so the push function will work on.");
                Toast.makeText(this, "The push token has uploaded.", Toast.LENGTH_LONG).show();
            }
            break;
        default:
            TBLog.e(TAG, "fatal error: unknown network callback function id: "
                    + actionID);
            break;
        }
    }

    /**
     * 获取手机屏幕宽*高,注意，传入的context必须是activity
     */
    private String getScreenSize(Activity context) {
        DisplayMetrics metric = new DisplayMetrics();
        context.getWindowManager().getDefaultDisplay().getMetrics(metric);
        int width = metric.widthPixels; // 屏幕宽度（像素）
        int height = metric.heightPixels; // 屏幕高度（像素）

        return width + "*" + height;
    }

    @Override
    protected void regTBRecver() {
        mReceiver = new TBReciver();
        IntentFilter filter = new IntentFilter();
        filter.addAction(TBConstDef.CB_UPLOAD_DEVICE_INFO + "");
        registerReceiver(mReceiver, filter);
    }

}
