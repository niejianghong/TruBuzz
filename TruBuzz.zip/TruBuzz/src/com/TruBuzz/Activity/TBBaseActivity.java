package com.TruBuzz.Activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.widget.Toast;

import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;
import com.TruBuzz.TBNetwork.TBNetworkResult;
import com.TruBuzz.TruBuzz.R;
import com.TruBuzz.TruBuzz.TBApplication;

public abstract class TBBaseActivity extends Activity {
    private ProgressDialog loadingBar = null;
    protected TBReciver mReceiver = null;
    protected String TAG = "";
    
    protected abstract void processBrodcast(int actionID, TBNetworkResult netResult);
    protected abstract void regTBRecver();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        regTBRecver();
        TBApplication.addActivity(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);

        return true;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroy() {
        if (null != mReceiver) {
            unregisterReceiver(mReceiver);
        }
        super.onDestroy();
    }

    public void showProgressDialog(String msg, boolean isCancel) {
        if (loadingBar == null) {
            loadingBar = ProgressDialog.show(this, null, msg);
        } else {
            loadingBar.show();
        }
    }
    public void showProgressDialog(int resId, boolean isCancel) {
        if (loadingBar == null) {
            loadingBar = ProgressDialog.show(this, null, this.getString(resId));
        } else {
            loadingBar.show();
        }
    }

    public void stopProgressDialog() {
        if (loadingBar != null) {
            loadingBar.dismiss();
        }
        loadingBar = null;
    }
    
    public void showToast(String msg, int time){
        Toast.makeText(this, msg, time).show();
    }
    public void showToast(int resId, int time){
        Toast.makeText(this, resId, time).show();
    }

    
    public class TBReciver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            TBLog.d(TAG, "network callback: " + action);
            int actionId = Integer.parseInt(action);
            TBNetworkResult netResult = (TBNetworkResult) intent
                    .getSerializableExtra(TBConstDef.NET_RESULT);
            processBrodcast(actionId, netResult);
        }

    }
}
