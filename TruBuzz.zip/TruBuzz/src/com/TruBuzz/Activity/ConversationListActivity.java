package com.TruBuzz.Activity;

import java.util.ArrayList;
import java.util.List;

import android.content.IntentFilter;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.SearchView;
import android.widget.SearchView.OnQueryTextListener;
import android.widget.Toast;

import com.TruBuzz.Adapter.TBConversationListAdapter;
import com.TruBuzz.TBBeans.TBUserInfo;
import com.TruBuzz.TBBeans.TBUserList;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;
import com.TruBuzz.TBDataBase.TBDBUtils;
import com.TruBuzz.TBNetwork.TBFriendsConnPool;
import com.TruBuzz.TBNetwork.TBNetworkResult;
import com.TruBuzz.TruBuzz.R;
import com.TruBuzz.TruBuzz.TBApplication;
import com.TruBuzz.View.SwipListView;
import com.TruBuzz.View.SwipListView.OnSwipedCallback;

public class ConversationListActivity extends TBBaseActivity implements
        OnQueryTextListener {

    private SwipListView mSwipListView = null;
    private TBConversationListAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conversation_list);
        init();
    }

    private void init() {
        mSwipListView = (SwipListView) findViewById(R.id.swip_listview);
        mAdapter = new TBConversationListAdapter(this, TBDBUtils.getInstance(
                this).getFriendListFromDB(), 0);

        mSwipListView.setAdapter(mAdapter);

        mSwipListView.setOnSwipedCallback(new OnSwipedCallback() {

            @Override
            public void onSwiped(int location) {
                // TODO Auto-generated method stub
            }
        });

        mSwipListView.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                    long arg3) {
                // TODO Auto-generated method stub
                Toast.makeText(TBApplication.mGlobalContext,
                        ((TBUserInfo) mAdapter.getItem(arg2)).nickname,
                        Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.conversation_list_actions, menu);
        SearchView searchView = (SearchView) menu.findItem(R.id.action_search)
                .getActionView();
        searchView.setOnQueryTextListener(this);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        case R.id.action_add_friend:
            TBFriendsConnPool.getFriendsList(TBConstDef.CB_GET_FRIENDS_LIST
                    + "");

            break;
        case R.id.action_new_group:
            break;
        }
        Toast.makeText(this, "Selected Item: " + item.getTitle(),
                Toast.LENGTH_SHORT).show();
        return true;
    }

    // The following callbacks are called for the
    // SearchView.OnQueryChangeListener
    public boolean onQueryTextChange(String newText) {
        newText = newText.isEmpty() ? "" : "Query so far: " + newText;
        return true;
    }

    public boolean onQueryTextSubmit(String query) {
        Toast.makeText(this, "Searching for: " + query + "...",
                Toast.LENGTH_SHORT).show();
        return true;
    }

    @Override
    protected void processBrodcast(int actionID, TBNetworkResult netResult) {
        switch (actionID) {
        case TBConstDef.CB_GET_FRIENDS_LIST:
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                stopProgressDialog();
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                TBUserList userList = (TBUserList) netResult;
                TBLog.e(TAG, userList.toString());
                // we should not save data at here, because maybe ANR
                TBDBUtils.getInstance(this).insertFriendList2DB(userList);
                mAdapter.swapCursor(TBDBUtils.getInstance(this).getFriendListFromDB());
            }
            break;
        default:
            TBLog.e(TAG, "fatal error: unknown network callback function id: "
                    + actionID);
            break;
        }

    }

    @Override
    protected void regTBRecver() {
        mReceiver = new TBReciver();
        IntentFilter filter = new IntentFilter();
        filter.addAction(TBConstDef.CB_GET_FRIENDS_LIST + "");
        registerReceiver(mReceiver, filter);

    }
}
