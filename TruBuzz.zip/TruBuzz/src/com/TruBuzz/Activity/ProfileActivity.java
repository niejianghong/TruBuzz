package com.TruBuzz.Activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.TruBuzz.TBCommon.TBConfigUtils;
import com.TruBuzz.TBCommon.TBLog;
import com.TruBuzz.TBNetwork.TBNetworkResult;
import com.TruBuzz.TruBuzz.R;
import com.TruBuzz.TruBuzz.TBApplication;

public class ProfileActivity extends TBBaseActivity {

    private TextView tvAccount = null;
    private TextView tvNickName = null;
    private TextView tvEmail = null;
    private LinearLayout llLogout = null;
    private LinearLayout llChangePwd = null;
    private ImageView avatar = null;

    private static String TAG = "ProfileActivity";

    private Bitmap getAvatar(String fileName) {

        Bitmap srcAvatar = null;
        if (!TextUtils.isEmpty(fileName)
                && TBConfigUtils.isExistsFile(fileName)) {
            srcAvatar = BitmapFactory.decodeFile(fileName);
        } else {
            srcAvatar = BitmapFactory.decodeResource(this.getResources(),
                    R.drawable.bg_avatar);
        }

        if (null == srcAvatar) {
            return null;
        }

        return srcAvatar;
    }

    private void initUi() {

        tvAccount = (TextView) findViewById(R.id.tv_account);
        avatar = (ImageView) findViewById(R.id.img_avatar);
        avatar.setImageBitmap(getAvatar(TBLog.getSDCardPath(this)
                + TBLog.logpath + "avatar.png"));
        tvAccount.setText(TBApplication.userInfo.account);
        tvNickName = (TextView) findViewById(R.id.tv_nickname);
        tvNickName.setText(TBApplication.userInfo.nickname);
        tvEmail = (TextView) findViewById(R.id.tv_email);
        tvEmail.setText(TBApplication.userInfo.email);

        llLogout = (LinearLayout) findViewById(R.id.ll_logout);
        llLogout.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                TBConfigUtils.setAutoLoginFlag(ProfileActivity.this, false);
                TBApplication.exit();
                // ProfileActivity.this.finish();
                // Intent i = getBaseContext().getPackageManager().
                // getLaunchIntentForPackage(getBaseContext().getPackageName());
                // i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                // startActivity(i);

            }
        });
        llChangePwd = (LinearLayout) findViewById(R.id.ll_pwd);
        llChangePwd.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                Intent i = new Intent(ProfileActivity.this,
                        ResetPwdActivity.class);
                ProfileActivity.this.startActivity(i);

            }
        });
    }

    protected void regTBRecver() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.TAG = TAG;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // 初始化子元素
        initUi();
    }

    @Override
    protected void processBrodcast(int actionID, TBNetworkResult netResult) {
    }

}
