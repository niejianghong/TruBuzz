package com.TruBuzz.Activity;

import android.content.IntentFilter;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.TruBuzz.TBCommon.TBConfigUtils;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;
import com.TruBuzz.TBNetwork.TBNetworkResult;
import com.TruBuzz.TBNetwork.TBUserConnPool;
import com.TruBuzz.TruBuzz.R;

public class CreateNewUserActivity extends TBBaseActivity {

    private EditText accountInputText = null;
    private EditText nicknameInputtext = null;
    private EditText emailInputText = null;
    private EditText passwordInputText = null;
    private EditText rePasswordInputText = null;

    private Button createBtn = null;
    private Button cancelBtn = null;

    private static String TAG = "CreateNewUserActivity";

    private void initUi() {

        createBtn = (Button) findViewById(R.id.btn_create_user);
        createBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String pwd = passwordInputText.getText().toString();
                String rePwd = rePasswordInputText.getText().toString();

                if (TextUtils.isEmpty(accountInputText.getText().toString())) {
                    showToast(R.string.input_account_pls, Toast.LENGTH_LONG);
                    return;
                }
                if (TextUtils.isEmpty(nicknameInputtext.getText().toString())) {
                    showToast(R.string.input_nickname_pls, Toast.LENGTH_LONG);
                    return;
                }
                if (TextUtils.isEmpty(emailInputText.getText().toString())) {
                    showToast(R.string.input_email_pls, Toast.LENGTH_LONG);
                    return;
                }
                if (TextUtils.isEmpty(pwd)) {
                    showToast(R.string.input_pwd_pls, Toast.LENGTH_LONG);
                    return;
                }
                if (TextUtils.isEmpty(rePwd)) {
                    showToast(R.string.re_input_pwd_pls, Toast.LENGTH_LONG);
                    return;
                }
                if (!pwd.equals(rePwd)) {
                    showToast(R.string.pwd_not_match, Toast.LENGTH_LONG);
                    return;
                }
                TBUserConnPool.regNewUser(
                        accountInputText.getText().toString(), pwd,
                        emailInputText.getText().toString(), emailInputText
                                .getText().toString(),
                        TBConstDef.CB_REG_NEW_USER+"");
                showProgressDialog(R.string.reging_pls_wait, true);

            }
        });
        cancelBtn = (Button) findViewById(R.id.btn_cancel);
        cancelBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                CreateNewUserActivity.this.finish();
            }
        });

        accountInputText = (EditText) findViewById(R.id.et_account);
        passwordInputText = (EditText) findViewById(R.id.et_password);
        nicknameInputtext = (EditText) findViewById(R.id.et_nickname);
        rePasswordInputText = (EditText) findViewById(R.id.et_re_password);
        emailInputText = (EditText) findViewById(R.id.et_email);
    }

    protected void regTBRecver() {
        mReceiver = new TBReciver();
        IntentFilter filter = new IntentFilter();

        filter.addAction(TBConstDef.CB_REG_NEW_USER + "");

        registerReceiver(mReceiver, filter);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.TAG = TAG;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg);

        // 初始化子元素
        initUi();
    }

    @Override
    protected void processBrodcast(int actionID, TBNetworkResult netResult) {
        switch (actionID) {
        case TBConstDef.CB_REG_NEW_USER:
            stopProgressDialog();
            if (null == netResult
                    || netResult.errorCode != TBNetworkResult.SUCCESS) {
                showToast(netResult.errorMsg, Toast.LENGTH_LONG);
            } else {
                TBConfigUtils.setAccountName(this, accountInputText.getText()
                        .toString());
                TBConfigUtils.setAccountPassword(this, passwordInputText
                        .getText().toString());
                this.finish();
            }
            break;

        default:
            TBLog.e(TAG, "fatal error: unknown network callback function id: "
                    + actionID);
            break;
        }

    }

}
