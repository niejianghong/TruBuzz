package com.TruBuzz.Activity;

import java.util.ArrayList;
import java.util.EventListener;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.SearchView;
import android.widget.SearchView.OnQueryTextListener;
import android.widget.Toast;

import com.TruBuzz.Adapter.TBConversationListAdapter;
import com.TruBuzz.TBBeans.TBUserInfo;
import com.TruBuzz.TBBeans.TBUserList;
import com.TruBuzz.TBCommon.TBConfigUtils;
import com.TruBuzz.TBCommon.TBConstDef;
import com.TruBuzz.TBCommon.TBLog;
import com.TruBuzz.TBDataBase.TBDBUtils;
import com.TruBuzz.TBNetwork.TBFriendsConnPool;
import com.TruBuzz.TBNetwork.TBNetworkResult;
import com.TruBuzz.TruBuzz.R;
import com.TruBuzz.TruBuzz.TBApplication;
import com.TruBuzz.View.SwipListView;
import com.TruBuzz.View.SwipListView.OnSwipedCallback;
import com.koushikdutta.async.http.socketio.Acknowledge;
import com.koushikdutta.async.http.socketio.ConnectCallback;
import com.koushikdutta.async.http.socketio.DisconnectCallback;
import com.koushikdutta.async.http.socketio.ErrorCallback;
import com.koushikdutta.async.http.socketio.EventCallback;
import com.koushikdutta.async.http.socketio.JSONCallback;
import com.koushikdutta.async.http.socketio.SocketIOClient;
import com.koushikdutta.async.http.socketio.StringCallback;

public class ChatActivity extends TBBaseActivity implements OnQueryTextListener {

    private SwipListView mSwipListView = null;
    private SocketIOClient mSockIOClient = null;
    private TBConversationListAdapter mAdapter;

    private DisconnectCallback mDisConnCallback = new DisconnectCallback() {

        @Override
        public void onDisconnect(Exception e) {
            TBLog.e(TAG, "DisConnect callback: " + e.getMessage());

        }
    };
    private ErrorCallback mErrorCallback = new ErrorCallback() {

        @Override
        public void onError(String error) {
            TBLog.e(TAG, "ErrorCallback: " + error);

        }
    };
    private JSONCallback mJSCallback = new JSONCallback() {

        @Override
        public void onJSON(JSONObject json, Acknowledge acknowledge) {
            TBLog.e(TAG, "JSONCallback " + json.toString());

        }
    };
    private StringCallback mStrCallback = new StringCallback() {

        @Override
        public void onString(String string, Acknowledge acknowledge) {
            TBLog.e(TAG, "StringCallback: " + string + ", acknowledege: "
                    + acknowledge.toString());

        }
    };

    private EventCallback mEventCallback = new EventCallback() {

        @Override
        public void onEvent(String event, JSONArray argument,
                Acknowledge acknowledge) {
            TBLog.e(TAG, "EventCallback: " + event + ", argument: "
                    + (null == argument ? null : argument.toString())
                    + ", Acknowledge: "
                    + (null == acknowledge ? null : acknowledge));
            if("init".equals(event)){
                JSONObject jsObj = new JSONObject();
                JSONArray jsArray = null;
                try {
                    jsObj.put("chat_handle", TBApplication.chat_handle);
                    jsArray = new JSONArray();
                    jsArray.put(jsObj);
                } catch (JSONException e) {
                    TBLog.e(TAG, "fatal error: "+e.getMessage());
                    // TODO jhnie: warning user to hold this error.
                    return;
                }

                mSockIOClient.emit("init", jsArray);
                
            }else if("ask_online_friend_list".equals(event)){
                mSockIOClient.emit("asking_online_friend_list", null, null);
            }else if("ask_cust_room_list".equals(event)){
                
            }

        }
    };
    private ConnectCallback mSockIOCallBack = new ConnectCallback() {

        @Override
        public void onConnectCompleted(Exception ex, SocketIOClient client) {
            // TODO Auto-generated method stub
            if (null != ex) {
                TBLog.e(TAG, ex.getMessage());
                // TODO: jhnie, process the excaption at here and notice the
                // user.
                return;
            }
            mSockIOClient = client;
            // Save the returned SocketIOClient instance into a variable so you
            // can disconnect it later
            mSockIOClient.setDisconnectCallback(mDisConnCallback);
            mSockIOClient.setErrorCallback(mErrorCallback);
            mSockIOClient.setJSONCallback(mJSCallback);
            mSockIOClient.setStringCallback(mStrCallback);

            // You need to explicitly specify which events you are interested in
            // receiving
            mSockIOClient.addListener("init", mEventCallback);
            mSockIOClient.addListener("ask_online_friend_list",
                    mEventCallback);
            mSockIOClient.addListener("ask_cust_room_list", mEventCallback);
            mSockIOClient.addListener("say", mEventCallback);

        }

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conversation_list);
        init();
        SocketIOClient.connect("http://chat.trubuzz.cn", mSockIOCallBack,
                new Handler());
    }

    private void init() {
        mSwipListView = (SwipListView) findViewById(R.id.swip_listview);

        mAdapter = new TBConversationListAdapter(this, TBDBUtils.getInstance(
                this).getFriendListFromDB(), 0);

        mSwipListView.setAdapter(mAdapter);

        mSwipListView.setOnSwipedCallback(new OnSwipedCallback() {

            @Override
            public void onSwiped(int location) {
                // TODO Auto-generated method stub
            }
        });

        mSwipListView.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                    long arg3) {
                // TODO Auto-generated method stub
                Toast.makeText(TBApplication.mGlobalContext,
                        ((TBUserInfo) mAdapter.getItem(arg2)).nickname,
                        Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.conversation_list_actions, menu);
        SearchView searchView = (SearchView) menu.findItem(R.id.action_search)
                .getActionView();
        searchView.setOnQueryTextListener(this);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        case R.id.action_add_friend:
            TBFriendsConnPool.getFriendsList(TBConstDef.CB_GET_FRIENDS_LIST
                    + "");

            break;
        case R.id.action_new_group:
            break;
        }
        Toast.makeText(this, "Selected Item: " + item.getTitle(),
                Toast.LENGTH_SHORT).show();
        return true;
    }

    // The following callbacks are called for the
    // SearchView.OnQueryChangeListener
    public boolean onQueryTextChange(String newText) {
        newText = newText.isEmpty() ? "" : "Query so far: " + newText;
        return true;
    }

    public boolean onQueryTextSubmit(String query) {
        Toast.makeText(this, "Searching for: " + query + "...",
                Toast.LENGTH_SHORT).show();
        return true;
    }

    @Override
    protected void processBrodcast(int actionID, TBNetworkResult netResult) {

    }

    @Override
    protected void regTBRecver() {

    }
}
