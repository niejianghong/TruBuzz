package com.TruBuzz.TBBeans;

import org.json.JSONObject;

import com.TruBuzz.TBNetwork.TBNetworkResult;

public class TBReplyMessage extends TBNetworkResult{

    /**
     * 
     */
    private static final long serialVersionUID = 2830359453742320553L;
    public TBUserInfo userInfo = null;
    public boolean is_buzzed = false;
    public String body = null;
    public String update_at = null;
    public boolean deletable = false;
    public String create_at = null;
    public String avatar = null;
    public long id = -1;
    public long buzz = -1;
    
    public TBReplyMessage(){
        super(TBNetworkResult.SUCCESS, "");
    }
    public TBReplyMessage(int errorCode, String errorMsg){
        super(errorCode, errorMsg);
    }
    
    
    @Override
    public boolean equals(Object msg){
        if(this.id == ((TBReplyMessage)msg).id){
            return true;
        }else{
            return false;
        }
    }
    
    public void resetStatus(){
        errorCode = TBNetworkResult.SUCCESS;
        errorMsg = "";
    }

    public TBReplyMessage(JSONObject obj) {
        super(TBNetworkResult.SUCCESS, "");
        try {
            userInfo = new TBUserInfo(obj.getString("nickname"), obj.getString("personal_url"),
                    obj.getLong("user_id"));
            this.body = obj.getString("body");
            this.update_at = obj.getString("update_at");
            this.deletable = obj.getBoolean("deletable");
            this.create_at = obj.getString("create_at");
            this.id = obj.getInt("id");
            this.buzz = obj.getInt("buzz");
            this.is_buzzed = obj.getBoolean("is_buzzed");

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
