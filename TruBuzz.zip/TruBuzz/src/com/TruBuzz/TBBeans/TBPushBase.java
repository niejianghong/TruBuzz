package com.TruBuzz.TBBeans;

import java.io.Serializable;

public class TBPushBase implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5661596903879172899L;
	public static String TAG = "TBPushBase";
	
	public static final String PUSH_TYPE = "NotificationType";
	public static final String PUSH_TYPE_MESSAGE = "Message";
	public static final String PUSH_TYPE_UPDATE = "Update";
	public static final String PUSH_TYPE_CHAT = "Chat";
	public static final String PUSH_TYPE_ERROR = "ErrorPushType";
	
	public String notifyType = PUSH_TYPE_ERROR;
	public int version = 0;
	
	public TBPushBase(String type){
		notifyType = type;
		this.version = 0;//TODO jhnie, get version via the type
	}
	
	

}
