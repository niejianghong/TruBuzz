package com.TruBuzz.TBBeans;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.TruBuzz.TBCommon.TBLog;
import com.TruBuzz.TBNetwork.TBNetworkResult;

public class TBNoticeList extends TBNetworkResult {
    /**
     * 
     */
    private static final long serialVersionUID = 8138265157925684015L;
    private static final String TAG = "TBNoticeList";
    public long newestNoticeId = -1;
    public long oldestNoticeId = -1;
    public long minimumNoticeId = -1;
    public int unread_num = -1;
    public List<TBNotice> notices = new ArrayList<TBNotice>();
    
    public TBNoticeList(int errorCode, String errorMsg){
        super(errorCode, errorMsg);
    }
    
    public TBNoticeList(){
        super(TBNetworkResult.SUCCESS, "");
    }
    
    public void setNoticeList(JSONArray array){
        for (int i = 0; array != null && i < array.length(); ++i) {
            try {
                notices.add(new TBNotice((JSONObject) array.get(i)));
            } catch (JSONException e) {
                TBLog.e(TAG, e.getMessage());
            }

        }
    }

}
