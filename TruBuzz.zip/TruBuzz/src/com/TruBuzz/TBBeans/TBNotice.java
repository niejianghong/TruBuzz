package com.TruBuzz.TBBeans;

import org.json.JSONObject;

import com.TruBuzz.TBNetwork.TBNetworkResult;

public class TBNotice extends TBNetworkResult {

    /**
     * 
     */
    private static final long serialVersionUID = -5697374137565760560L;
    public String content = null;
    public String nickname = null;
    public String url = null;
    public String create_at = null;
    public String avatar = null;
    public long id = -1;
    public long status = -1;

    public TBNotice(JSONObject obj) {
        try {
            this.content = obj.getString("content");
            this.nickname = obj.getString("nickname");
            this.url = obj.getString("url");
            this.create_at = obj.getString("create_at");
            this.id = obj.getInt("id");
            this.status = obj.getInt("status");
            this.avatar = obj.getString("avatar");

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
