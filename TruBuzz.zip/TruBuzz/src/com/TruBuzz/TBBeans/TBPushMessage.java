package com.TruBuzz.TBBeans;

import org.json.JSONException;
import org.json.JSONObject;

import com.TruBuzz.TBCommon.TBLog;

public class TBPushMessage extends TBPushBase {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7749480070893594686L;
	public static String TAG = "TBPushMessage";

	public static final String MSG_TYPE = "MsgType";
	public static final String MSG_TYPE_PUB_WALL = "PublicWall";
	public static final String MSG_TYPE_CIRCLE = "CircleMsg";
	public static final String MSG_TYPE_STOCK = "StockRiver";
	public static final String MSG_TYPE_ERROR = "ErrorMsgType";

	public static final String CONTENT_TYPE = "ContentType";
	public static final String CONTENT_TYPE_IMG = "Img";
	public static final String CONTENT_TYPE_VIDEO = "Video";
	public static final String CONTENT_TYPE_TEXT = "Text";
	public static final String CONTENT_TYPE_VOICE = "Voice";
	public static final String CONTENT_TYPE_ERROR = "UnknownContentType";
	
	public static final String MSG_ID = "msgId";
	public static final String SUBJECT = "subject";
	public static final String NICKE_NAME = "nickName";

	public String msgType = MSG_TYPE_ERROR;
	public String contentType = CONTENT_TYPE_ERROR;
	public int msgId = 0;
	public String subject = null;
	public String nickName = null;

	// both of fromName and Id have value then the msgType was Circle or Stock
	public String fromName = null;
	public int fromId = 0;

	public TBPushMessage(JSONObject obj) {
		super(PUSH_TYPE_MESSAGE);
		try {
			if (obj.has(MSG_TYPE)) {
				msgType = obj.getString(MSG_TYPE);
			}else{
				TBLog.e(TAG, "json parse error: "+obj.toString());
				return;
			}
			
			if(obj.has(CONTENT_TYPE)){
				contentType = obj.getString(CONTENT_TYPE);
			}
			if(!obj.has("MsgData")){
				TBLog.e(TAG, "json parse error: "+obj.toString());
				return;
			}
			JSONObject msgDataObj = obj.getJSONObject("MsgData");
			if(msgDataObj.has(MSG_ID)){
				msgId = msgDataObj.getInt(MSG_ID);
			}
			if(msgDataObj.has(NICKE_NAME)){
				nickName = msgDataObj.getString(NICKE_NAME);
			}
			if(msgDataObj.has(SUBJECT)){
				subject = msgDataObj.getString(SUBJECT);
			}
			
			if(MSG_TYPE_CIRCLE.equals(msgType)){
				fromName = msgDataObj.getString("circleName");
				fromId = msgDataObj.getInt("circleId");
			}else if(MSG_TYPE_STOCK.equals(msgType)){
				fromName = msgDataObj.getString("stockName");
				fromId = msgDataObj.getInt("stockId");
			}else if(MSG_TYPE_PUB_WALL.equals(msgType)){
				// do nothing
			}
		} catch (JSONException e) {
			TBLog.e(TAG, e.getMessage());
		}
	}

}
