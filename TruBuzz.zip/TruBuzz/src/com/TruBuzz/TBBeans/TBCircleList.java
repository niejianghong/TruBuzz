package com.TruBuzz.TBBeans;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;

import com.TruBuzz.TBCommon.TBLog;
import com.TruBuzz.TBNetwork.TBNetworkResult;

public class TBCircleList extends TBNetworkResult {

    /**
     * 
     */
    private static final long serialVersionUID = 3318866049283134462L;
    private static final String TAG = "TBCircleList";
    public List<TBCircle> circleList = new ArrayList<TBCircle>();
    
    public TBCircleList(int errorCode, String errorMsg){
        super(errorCode, errorMsg);
    }
    
    public TBCircleList(){
        super(TBNetworkResult.SUCCESS, "");
    }
    
    public void setCircleList(JSONArray array){
        for (int i = 0; array != null && i < array.length(); ++i) {
            try {
                circleList.add(new TBCircle(array.getJSONObject(i)));
            } catch (JSONException e) {
                TBLog.e(TAG, e.getMessage());
            }

        }
    }

}
