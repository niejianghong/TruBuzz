package com.TruBuzz.TBBeans;

import org.json.JSONObject;

import com.TruBuzz.TBNetwork.TBNetworkResult;

public class TBSharedMessage extends TBNetworkResult {

    /**
     * 
     */
    private static final long serialVersionUID = 5961826484983160042L;
    public static String TAG = "TBSharedMessage";
    public int share_num = -1;
    public String body = null;
    public String share_to = null;
    public int status = -1;
    public String share_to_url = null;
    public String avatar = null;
    public String name = null;
    public long message_id = -1;

    public TBSharedMessage() {
        super(TBNetworkResult.SUCCESS, "");
    }

    public TBSharedMessage(int errorCode, String errorMsg) {
        super(errorCode, errorMsg);
    }

    @Override
    public boolean equals(Object msg){
        if(this.message_id == ((TBSharedMessage)msg).message_id){
            return true;
        }else{
            return false;
        }
    }

    public TBSharedMessage(JSONObject obj) {
	    super(TBNetworkResult.SUCCESS, "");
		try {

			if (obj.has("share_num")) {
				this.share_num = obj.getInt("share_num");
			}
			if (obj.has("body")) {
				this.body = obj.getString("body");
			}

			if (obj.has("status")) {
				this.status = obj.getInt("status");
			}
			if (obj.has("name")) {
				this.name = obj.getString("name");
			}
			if (obj.has("avatar")) {
				this.avatar = obj.getString("avatar");
			}
			if (obj.has("share_to_url")) {
				this.share_to_url = obj.getString("share_to_url");
			}
	         if (obj.has("share_to_url")) {
	                this.share_to_url = obj.getString("share_to_url");
	            }
			if (obj.has("message_id")) {
				this.message_id = obj.getLong("message_id");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		


	}
}
