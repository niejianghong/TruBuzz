package com.TruBuzz.TBBeans;

import org.json.JSONObject;

import com.TruBuzz.TBNetwork.TBNetworkResult;

public class TBUserInfo extends TBNetworkResult {
    /**
     * 
     */
    private static final long serialVersionUID = 6905486098224085843L;
    public String nickname = null;
    public String personal_url = null;
    public long id = 0;
    public String avatar = null; // this item was avatar on the web
    public String email = null;
    public String account = null;
    public String avatar_path = null;// this item was avatar on the local storage

    public TBUserInfo(String nickname, String personal_url, long id) {
        super(TBNetworkResult.SUCCESS, "");
        this.nickname = nickname;
        this.personal_url = personal_url;
        this.id = id;
    }

    public TBUserInfo(JSONObject obj) {
        super(TBNetworkResult.SUCCESS, "");
        try {
            if (obj.has("nickname")) {
                this.nickname = obj.getString("nickname");
            }
            if (obj.has("personal_url")) {
                this.personal_url = obj.getString("personal_url");
            }
            if (obj.has("email")) {
                this.email = obj.getString("email");
            }
            if (obj.has("account")) {
                this.account = obj.getString("account");
            }
            if (obj.has("id")) {
                this.id = obj.getLong("id");
            }
            if (obj.has("avatar")) {
                this.avatar = obj.getString("avatar");
            }
        } catch (Exception e) {
            e.printStackTrace();

        }
    }

}
