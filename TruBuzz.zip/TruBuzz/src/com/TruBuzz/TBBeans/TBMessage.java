package com.TruBuzz.TBBeans;

import org.json.JSONObject;

import com.TruBuzz.TBNetwork.TBNetworkResult;

public class TBMessage extends TBNetworkResult {

	/**
     * 
     */
	private static final long serialVersionUID = 5961826484983140022L;
	public static String TAG = "TBMessage";
	public TBUserInfo userInfo = null;
	public int bear = -1;
	public int share_num = -1;
	public String body = null;
	public String update_at = null;
	public int status = -1;
	public String stock_id = null;
	public boolean deletable = false;
	public String create_at = null;
	public String stock_code = null;
	public int permission = 0;
	public boolean is_sharable = false;
	public int bull = 0;
	public String avatar = null;
	public String photo = null;
	public String stock_avatar = null;
	public long id = -1;
	public long buzz = -1;
	public boolean is_buzzed = false;
	public String stock_info = null;
	public String type = "0";
	public long share_message_id = 0;
	
	public TBSharedMessage sharedMsg = null;
	
	public final static int SHARED_MSG = 2;
	public final static int NORMARL_MSG = 0;
	
	public TBMessage(){
	    super(TBNetworkResult.SUCCESS, "");
	}
    public TBMessage(int errorCode, String errorMsg){
        super(errorCode, errorMsg);
    }
    @Override
    public boolean equals(Object msg){
        if(this.id == ((TBMessage)msg).id){
            return true;
        }else{
            return false;
        }
    }
    
    public void resetStatus(){
        errorCode = TBNetworkResult.SUCCESS;
        errorMsg = "";
    }

	public TBMessage(JSONObject obj) {
	    super(TBNetworkResult.SUCCESS, "");
		try {
			String nickname = "invalid";
			if (obj.has("nickname")) {
				nickname = obj.getString("nickname");
			}

			String personal_url = "http://invalid";
			if (obj.has("personal_url")) {
				personal_url = obj.getString("personal_url");
			}

			long user_id = 0;
			if (obj.has("user_id")) {
				user_id = obj.getLong("user_id");
			}
			userInfo = new TBUserInfo(nickname, personal_url, user_id);
			if (obj.has("bear")) {
				this.bear = obj.getInt("bear");
			}

			if (obj.has("share_num")) {
				this.share_num = obj.getInt("share_num");
			}
			if (obj.has("type")) {
				this.type = obj.getString("type");
			}
			if (obj.has("body")) {
				this.body = obj.getString("body");
			}
			if (obj.has("update_at")) {
				this.update_at = obj.getString("update_at");
			}
			if (obj.has("status")) {
				this.status = obj.getInt("status");
			}
			if (obj.has("stock_id")) {
				this.stock_id = obj.getString("stock_id");
			}
			if (obj.has("deletable")) {
				this.deletable = obj.getBoolean("deletable");
			}
			if (obj.has("create_at")) {
				this.create_at = obj.getString("create_at");
			}
			if (obj.has("stock_code")) {
				this.stock_code = obj.getString("stock_code");
			}
			if (obj.has("permission")) {
				this.permission = obj.getInt("permission");
			}
			if (obj.has("is_sharable")) {
				this.is_sharable = obj.getBoolean("is_sharable");
			}
			if (obj.has("bull")) {
				this.bull = obj.getInt("bull");
			}
			if (obj.has("stock_avatar")) {
				this.stock_avatar = obj.getString("stock_avatar");
			}
			if (obj.has("id")) {
				this.id = obj.getInt("id");
			}
			if (obj.has("buzz")) {
				this.buzz = obj.getInt("buzz");
			}
			if (obj.has("is_buzzed")) {
				this.is_buzzed = obj.getBoolean("is_buzzed");
			}
			if (obj.has("stock_info")) {
				this.stock_info = obj.getString("stock_info");
			}
			if (obj.has("share_message_id")) {
				this.share_message_id = obj.getInt("share_message_id");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
