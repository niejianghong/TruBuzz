package com.TruBuzz.TBBeans;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.TruBuzz.TBCommon.TBLog;
import com.TruBuzz.TBNetwork.TBNetworkResult;

public class TBMessageList extends TBNetworkResult {

    /**
     * 
     */
    private static final long serialVersionUID = 8954147108140569351L;
    private static final String TAG = "TBMessageList";
    public long newestMessageId = -1;
    public long oldestMessageId = -1;
    public long minimumMessageId = -1;
    public int totalReplies = -1;
    public List<TBMessage> messages = new ArrayList<TBMessage>();
    
    public TBMessageList(int errorCode, String errorMsg){
        super(errorCode, errorMsg);
    }
    
    public TBMessageList(){
        super(TBNetworkResult.SUCCESS, "");
    }
    
    public void setMsgList(JSONArray array){
        for (int i = 0; array != null && i < array.length(); ++i) {
            try {
                messages.add(new TBMessage((JSONObject) array.get(i)));
            } catch (JSONException e) {
                TBLog.e(TAG, e.getMessage());
            }

        }
    }

}
