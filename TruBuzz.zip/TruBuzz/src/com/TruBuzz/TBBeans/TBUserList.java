package com.TruBuzz.TBBeans;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;

import com.TruBuzz.TBCommon.TBLog;
import com.TruBuzz.TBNetwork.TBNetworkResult;

public class TBUserList extends TBNetworkResult {

    /**
     * 
     */
    private static final long serialVersionUID = 5252205234964001137L;
    private static final String TAG = "TBUserList";
    public List<TBUserInfo> userList = new ArrayList<TBUserInfo>();
    
    public TBUserList(int errorCode, String errorMsg){
        super(errorCode, errorMsg);
    }
    
    public TBUserList(){
        super(TBNetworkResult.SUCCESS, "");
    }
    
    public void setUserList(JSONArray array){
        for (int i = 0; array != null && i < array.length(); ++i) {
            try {
                userList.add(new TBUserInfo(array.getJSONObject(i)));
            } catch (JSONException e) {
                TBLog.e(TAG, e.getMessage());
            }

        }
    }

}
