package com.TruBuzz.TBBeans;

import org.json.JSONObject;

import com.TruBuzz.TBNetwork.TBNetworkResult;

public class TBCircle extends TBNetworkResult {

    /**
     * 
     */
    private static final long serialVersionUID = 8580153243029772961L;
    public String name = null;
    public long id = 0;
    public String type = null;
    @Override
    public boolean equals(Object obj){
        if(name.equals(((TBCircle)obj).name) && type.equals(((TBCircle)obj).type) && id == ((TBCircle)obj).id){
            return true;
        }else{
            return false;
        }
    }

    public TBCircle(String name, String type, long id) {
        super(TBNetworkResult.SUCCESS, "");
        this.name = name;
        this.id = id;
        this.type = type;
    }

    public TBCircle(JSONObject obj) {
        super(TBNetworkResult.SUCCESS, "");
        try {
            this.name = obj.getString("name");
            this.id = obj.getLong("id");
            this.type = obj.getString("type");
        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    public TBCircle(TBCircle circle) {
        super(TBNetworkResult.SUCCESS, "");
        this.name = circle.name;
        this.id = circle.id;
        this.type = circle.type;
    }

}
